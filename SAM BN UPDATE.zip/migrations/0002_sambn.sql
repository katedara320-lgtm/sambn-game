create table if not exists profiles (
  user_id text primary key,
  username text not null unique,
  display_name text not null,
  bio text not null default '',
  avatar_hue integer not null default 330,
  level integer not null default 1,
  xp integer not null default 0,
  wins integer not null default 0,
  losses integer not null default 0,
  draws integer not null default 0,
  created_at timestamptz not null default now(),
  last_seen timestamptz not null default now()
);

create table if not exists friendships (
  user_a text not null,
  user_b text not null,
  status text not null,
  requested_by text not null,
  created_at timestamptz not null default now(),
  primary key (user_a, user_b),
  check (user_a < user_b),
  check (status in ('pending', 'accepted'))
);

create index if not exists friendships_b_idx on friendships (user_b);

create table if not exists posts (
  id text primary key,
  user_id text not null,
  body text not null,
  game_slug text,
  score_label text,
  created_at timestamptz not null default now()
);

create index if not exists posts_created_idx on posts (created_at desc);

create table if not exists post_likes (
  post_id text not null references posts (id) on delete cascade,
  user_id text not null,
  primary key (post_id, user_id)
);

create table if not exists post_comments (
  id text primary key,
  post_id text not null references posts (id) on delete cascade,
  user_id text not null,
  body text not null,
  created_at timestamptz not null default now()
);

create table if not exists direct_messages (
  id text primary key,
  sender_id text not null,
  recipient_id text not null,
  body text not null,
  created_at timestamptz not null default now(),
  read_at timestamptz
);

create index if not exists dm_recipient_idx on direct_messages (recipient_id, created_at desc);

create table if not exists rooms (
  code text primary key,
  host_id text not null,
  game_slug text not null,
  max_players integer not null,
  status text not null default 'lobby',
  state_json text not null default '',
  state_version integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (status in ('lobby', 'live', 'done'))
);

create table if not exists room_members (
  code text not null references rooms (code) on delete cascade,
  user_id text not null,
  ready boolean not null default false,
  joined_at timestamptz not null default now(),
  primary key (code, user_id)
);

create table if not exists room_messages (
  id text primary key,
  code text not null references rooms (code) on delete cascade,
  user_id text not null,
  body text not null,
  created_at timestamptz not null default now()
);

create table if not exists room_scores (
  code text not null references rooms (code) on delete cascade,
  user_id text not null,
  score integer not null,
  detail text not null default '',
  primary key (code, user_id)
);

create table if not exists matches (
  id text primary key,
  user_id text not null,
  game_slug text not null,
  result text not null,
  detail text not null default '',
  opponent text not null default '',
  room_code text,
  played_at timestamptz not null default now(),
  check (result in ('win', 'loss', 'draw'))
);

create index if not exists matches_user_idx on matches (user_id, played_at desc);
