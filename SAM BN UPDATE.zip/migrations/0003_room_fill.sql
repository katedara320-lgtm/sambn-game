alter table rooms add column if not exists fill_ai boolean not null default false;
