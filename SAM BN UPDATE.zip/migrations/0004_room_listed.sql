alter table rooms add column if not exists listed boolean not null default true;
