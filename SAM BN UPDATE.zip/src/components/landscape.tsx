import { RotateCw, X } from "lucide-react";
import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

const PlayContext = createContext({ active: true });

export function usePlayActive() {
  return useContext(PlayContext).active;
}

async function tryLandscape() {
  const root = document.documentElement;
  if (!document.fullscreenElement && root.requestFullscreen) {
    await root.requestFullscreen();
  }
  await screen.orientation.lock("landscape");
}

export function LandscapeStage({
  title,
  backTo,
  pause = true,
  children,
}: {
  title: string;
  backTo: string;
  pause?: boolean;
  children: ReactNode;
}) {
  const [portrait, setPortrait] = useState(false);
  const [paused, setPaused] = useState(false);
  const [lockFailed, setLockFailed] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia("(orientation: portrait)");
    const sync = () => setPortrait(mq.matches);
    sync();
    mq.addEventListener("change", sync);
    void tryLandscape().catch(() => setLockFailed(true));
    return () => {
      mq.removeEventListener("change", sync);
      void (async () => {
        try {
          await screen.orientation.lock("portrait");
        } catch {
          /* rotation lock or no fullscreen */
        }
        try {
          screen.orientation.unlock();
        } catch {
          /* ignore */
        }
        if (document.fullscreenElement) await document.exitFullscreen().catch(() => undefined);
      })();
    };
  }, []);

  const active = !portrait && !paused;

  return (
    <PlayContext.Provider value={{ active }}>
      <div className="fixed inset-0 z-50 h-dvh w-dvw overflow-hidden bg-ink text-fg" style={{ touchAction: "none" }}>
        <div className={portrait ? "pointer-events-none h-full w-full opacity-0" : "h-full w-full"}>{children}</div>
        <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex items-center justify-between p-2">
          <a
            href={backTo}
            className="pointer-events-auto grid h-11 w-11 place-items-center rounded-full bg-panel text-fg"
            aria-label="Leave game"
          >
            <X className="h-5 w-5" />
          </a>
          <span className="pointer-events-none rounded-full bg-ink/70 px-3 py-1 font-display text-sm font-bold">{title}</span>
          {pause ? (
            <button
              type="button"
              className="pointer-events-auto h-11 rounded-full bg-panel px-3 text-sm font-semibold"
              onClick={() => setPaused((v) => !v)}
            >
              {paused ? "Resume" : "Pause"}
            </button>
          ) : (
            <span className="h-11 w-11" />
          )}
        </div>
        {portrait ? (
          <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-4 bg-ink px-8 text-center">
            <RotateCw className="h-12 w-12 text-pink" />
            <h1 className="font-display text-2xl font-extrabold">Please rotate your phone to landscape mode</h1>
            <p className="max-w-sm text-sm text-muted">
              SAM BN matches use the whole screen horizontally, like a full-screen video. The dashboard stays portrait. If rotation lock is on, turn it off.
            </p>
            {lockFailed ? (
              <p className="text-sm text-gold">Automatic rotation was blocked by the browser. Rotate the phone yourself, or tap below to try again.</p>
            ) : null}
            <button
              type="button"
              className="min-h-11 rounded-xl bg-pink px-4 py-3 font-bold text-ink"
              onClick={() => {
                void tryLandscape()
                  .then(() => setLockFailed(false))
                  .catch(() => setLockFailed(true));
              }}
            >
              Try landscape again
            </button>
          </div>
        ) : null}
        {paused && !portrait ? (
          <div className="absolute inset-0 z-20 grid place-items-center bg-ink/80">
            <div className="space-y-3 text-center">
              <p className="font-display text-3xl font-extrabold">Paused</p>
              <button type="button" className="min-h-11 rounded-xl bg-pink px-4 py-3 font-bold text-ink" onClick={() => setPaused(false)}>
                Resume
              </button>
            </div>
          </div>
        ) : null}
      </div>
    </PlayContext.Provider>
  );
}
