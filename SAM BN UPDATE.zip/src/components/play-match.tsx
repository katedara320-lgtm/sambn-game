import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AdventureGame, FootballGame, ShooterGame, SnookerGame, ZombieGame, type ActionResult } from "@/components/games/action";
import { DuelMatch } from "@/components/games/duel";
import { ChessTable, SnakesTable, WhotTable, ZonoTable } from "@/components/games/board";
import { SnookerMatch } from "@/components/games/snooker-table";
import { actRoom, claimTurnResult, createRoom, getRoom, saveActionResult, type RoomView } from "@/lib/sambn/api";
import { gameBySlug } from "@/lib/sambn/catalog";
import { matchResultFor, turnSeat } from "@/lib/games/turn";
import { errText } from "@/components/ui";

export function ActionMatch({ slug, code, userId }: { slug: string; code: string; userId: string }) {
  if (code && (slug === "football" || slug === "shooter")) {
    return <DuelMatch slug={slug} code={code} userId={userId} />;
  }
  const [done, setDone] = useState<ActionResult | null>(null);
  const [note, setNote] = useState("");
  async function finish(result: ActionResult) {
    setDone(result);
    try {
      await saveActionResult({
        data: {
          id: crypto.randomUUID(),
          slug,
          result: result.result,
          detail: result.detail,
          opponent: "Computer",
          score: result.score,
          code,
        },
      });
      setNote("Saved to your match history.");
    } catch (error) {
      setNote(errText(error));
    }
  }
  if (done) {
    return (
      <div className="grid h-full place-items-center px-6 text-center">
        <div className="space-y-3">
          <p className="font-display text-4xl font-extrabold capitalize">{done.result}</p>
          <p className="text-lg">{done.detail}</p>
          <p className="text-sm text-muted">{note || "Saving…"}</p>
          <div className="flex justify-center gap-2">
            <a href={code ? `/room/${code}` : `/games/${slug}`} className="rounded-xl bg-pink px-4 py-3 font-bold text-ink">
              Back
            </a>
            <Link to="/community" className="rounded-xl border border-line px-4 py-3">
              Share later
            </Link>
          </div>
        </div>
      </div>
    );
  }
  if (slug === "snooker") return <SnookerGame onResult={finish} />;
  if (slug === "football") return <FootballGame onResult={finish} />;
  if (slug === "zombie") return <ZombieGame onResult={finish} />;
  if (slug === "shooter") return <ShooterGame onResult={finish} />;
  if (slug === "adventure") return <AdventureGame onResult={finish} />;
  return <p className="p-8">This game is not ready.</p>;
}

export function TurnMatch({ slug, code, userId }: { slug: string; code: string; userId: string }) {
  const [room, setRoom] = useState<RoomView | null>(null);
  const [error, setError] = useState("");
  const [starting, setStarting] = useState(false);

  async function refresh() {
    const next = await getRoom({ data: { code } });
    setRoom(next);
    return next;
  }

  useEffect(() => {
    if (!code) return;
    let cancel = false;
    const tick = () => {
      getRoom({ data: { code } })
        .then((next) => {
          if (!cancel) setRoom(next);
        })
        .catch((err) => {
          if (!cancel) setError(errText(err));
        });
    };
    tick();
    const id = window.setInterval(tick, 1200);
    return () => {
      cancel = true;
      window.clearInterval(id);
    };
  }, [code]);

  useEffect(() => {
    if (!room?.state || turnSeat(room.state) !== "ai") return;
    const id = window.setTimeout(() => {
      void actRoom({ data: { code: room.code, action: { type: "ai" } } })
        .then(() => refresh())
        .catch((err) => setError(errText(err)));
    }, 400);
    return () => window.clearTimeout(id);
  }, [room?.code, room?.version]);

  useEffect(() => {
    if (!room?.state) return;
    if (!matchResultFor(room.state, userId)) return;
    void claimTurnResult({ data: { code: room.code } }).catch(() => undefined);
  }, [room?.code, room?.version, userId]);

  if (!code) {
    return (
      <div className="grid h-full place-items-center">
        <button
          type="button"
          disabled={starting}
          className="rounded-xl bg-pink px-4 py-3 font-bold text-ink"
          onClick={() => {
            setStarting(true);
            void createRoom({ data: { slug, withAi: true } })
              .then((res) => {
                window.location.href = `/play/${slug}?room=${res.code}`;
              })
              .catch((err) => {
                setError(errText(err));
                setStarting(false);
              });
          }}
        >
          Play the computer
        </button>
        {error ? <p className="mt-3 text-sm text-pink-2">{error}</p> : null}
      </div>
    );
  }

  if (!room) return <p className="grid h-full place-items-center text-muted">{error || "Opening the table…"}</p>;
  if (!room.state) {
    return (
      <div className="grid h-full place-items-center px-6 text-center">
        <div>
          <p>This room is still in the lobby.</p>
          <a href={`/room/${code}`} className="mt-3 inline-block text-pink">
            Back to the room
          </a>
        </div>
      </div>
    );
  }
  const names: Record<string, string> = { ai: "Computer" };
  for (const member of room.members) names[member.userId] = member.displayName;
  const over = matchResultFor(room.state, userId);
  return (
    <div className="relative h-full">
      {error ? <p className="absolute bottom-2 left-3 z-10 text-xs text-pink-2">{error}</p> : null}
      {over ? (
        <p className="absolute bottom-2 right-3 z-10 rounded-full bg-panel px-3 py-1 text-sm capitalize">
          {over.result} · {over.detail} · saved
        </p>
      ) : null}
      {room.state.game === "chess" ? (
        <ChessTable
          state={room.state.chess}
          me={userId}
          names={names}
          onMove={(from, to) => {
            void actRoom({ data: { code, action: { from, to } } })
              .then(() => refresh())
              .catch((err) => setError(errText(err)));
          }}
        />
      ) : null}
      {room.state.game === "whot" ? (
        <WhotTable
          state={room.state.whot}
          me={userId}
          names={names}
          onPlay={(cardId, call) => {
            void actRoom({ data: { code, action: { type: "play", cardId, call } } })
              .then(() => refresh())
              .catch((err) => setError(errText(err)));
          }}
          onDraw={() => {
            void actRoom({ data: { code, action: { type: "draw" } } })
              .then(() => refresh())
              .catch((err) => setError(errText(err)));
          }}
        />
      ) : null}
      {room.state.game === "snooker" ? (
        <SnookerMatch
          state={room.state.snooker}
          me={userId}
          version={room.version}
          onShot={(shot) => {
            void actRoom({ data: { code, action: shot } })
              .then(() => refresh())
              .catch((err) => setError(errText(err)));
          }}
        />
      ) : null}
      {room.state.game === "snakes" ? (
        <SnakesTable
          state={room.state.snakes}
          me={userId}
          names={names}
          onRoll={() => {
            void actRoom({ data: { code, action: { type: "roll" } } })
              .then(() => refresh())
              .catch((err) => setError(errText(err)));
          }}
        />
      ) : null}
      {room.state.game === "zonopoly" ? (
        <ZonoTable
          state={room.state.zono}
          me={userId}
          names={names}
          onAct={(type) => {
            void actRoom({ data: { code, action: { type } } })
              .then(() => refresh())
              .catch((err) => setError(errText(err)));
          }}
        />
      ) : null}
      {gameBySlug(slug) ? null : null}
    </div>
  );
}
