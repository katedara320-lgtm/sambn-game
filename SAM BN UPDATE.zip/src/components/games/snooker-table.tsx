import { useEffect, useRef, useState } from "react";
import { audioPrefs, setAudioPrefs, sfx, unlockAudio } from "@/lib/audio";
import {
  POCKETS,
  applySnooker,
  placeCue,
  rackSnooker,
  rollShot,
  type SnookerAction,
  type SnookerState,
  type TableBall,
} from "@/lib/games/snooker";
import { usePlayActive } from "@/components/landscape";

export function SnookerPractice({ onResult }: { onResult: (result: { result: "win" | "loss" | "draw"; detail: string; score: number }) => void }) {
  const [state, setState] = useState(() => rackSnooker(["you"]));
  const sent = useRef(false);
  return (
    <SnookerView
      state={state}
      canShoot={state.winner === null}
      onShot={(shot) => {
        const next = applySnooker(state, 0, shot);
        setState(next);
        if (next.winner !== null && !sent.current) {
          sent.current = true;
          onResult({ result: next.winner === 0 ? "win" : "loss", detail: next.log, score: next.scores[0] ?? 0 });
        }
        return next;
      }}
    />
  );
}

export function SnookerMatch({
  state,
  me,
  version,
  onShot,
}: {
  state: SnookerState;
  me: string;
  version: number;
  onShot: (shot: SnookerAction) => SnookerState | void;
}) {
  const mine = state.winner === null && state.seats[state.turn] === me;
  return <SnookerView state={state} version={version} canShoot={mine} viewer={state.seats.indexOf(me)} onShot={onShot} />;
}

function SnookerView({
  state,
  version,
  canShoot,
  viewer = 0,
  onShot,
}: {
  state: SnookerState;
  version?: number;
  canShoot: boolean;
  viewer?: number;
  onShot: (shot: SnookerAction) => SnookerState | void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const active = usePlayActive();
  const balls = useRef<TableBall[]>(state.balls.map((ball) => ({ ...ball })));
  const aim = useRef<{ x: number; y: number } | null>(null);
  const view = useRef({ ox: 0, oy: 0, s: 1 });
  const moving = useRef(false);
  const pending = useRef<SnookerState | null>(null);
  const heading = useRef({ x: 1, y: 0 });
  const powerRef = useRef(0.55);
  const spinRef = useRef({ side: 0, follow: 0 });
  const canRef = useRef(canShoot);
  const handRef = useRef(false);
  const frames = useRef<TableBall[][]>([]);
  const frame = useRef(0);
  const drops = useRef<{ x: number; y: number; color: string; n: number; life: number }[]>([]);
  const latest = useRef(state);
  latest.current = state;
  canRef.current = canShoot;
  handRef.current = Boolean(state.ballInHand);
  const [hud, setHud] = useState(state.log);
  const [muted, setMuted] = useState(false);
  const [volume, setVolume] = useState(0.7);
  const [power, setPower] = useState(0.55);
  const [spin, setSpin] = useState({ side: 0, follow: 0 });
  powerRef.current = power;
  spinRef.current = spin;

  useEffect(() => {
    setMuted(audioPrefs().muted);
    setVolume(audioPrefs().sfx);
  }, []);

  useEffect(() => {
    if (moving.current) return;
    balls.current = state.balls.map((ball) => ({ ...ball }));
    setHud(scoreLine(state));
  }, [version, state.log, state.turn, state.winner]);

  useEffect(() => {
    if (!active) return;
    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.033, (now - last) / 1000);
      last = now;
      if (moving.current && frames.current.length) {
        const prev = balls.current;
        frame.current = Math.min(frames.current.length - 1, frame.current + 1);
        const next = frames.current[frame.current];
        for (let i = 0; i < next.length; i++) {
          const ball = next[i];
          const old = prev.find((item) => item.id === ball.id);
          if (old && !old.pocketed && ball.pocketed) {
            sfx("pocket", 0.9);
            drops.current.push({ x: old.x, y: old.y, color: old.color, n: old.n, life: 1 });
          } else if (old && !ball.pocketed) {
            const bounced = (old.vx > 40 && ball.vx < 0) || (old.vx < -40 && ball.vx > 0) || (old.vy > 40 && ball.vy < 0) || (old.vy < -40 && ball.vy > 0);
            if (bounced) sfx("cushion", 0.75);
            else if (Math.hypot(ball.vx - old.vx, ball.vy - old.vy) > 80) sfx("collide", 0.7);
          }
        }
        balls.current = next.map((ball) => ({ ...ball }));
        if (frame.current >= frames.current.length - 1) {
          moving.current = false;
          frames.current = [];
          if (pending.current) setHud(scoreLine(pending.current));
        }
      }
      drops.current = drops.current.filter((drop) => {
        drop.life -= dt * 1.8;
        return drop.life > 0;
      });
      const canvas = canvasRef.current;
      if (canvas) {
        const rect = canvas.getBoundingClientRect();
        const dpr = Math.min(2, window.devicePixelRatio || 1);
        const w = Math.max(1, Math.floor(rect.width * dpr));
        const h = Math.max(1, Math.floor(rect.height * dpr));
        if (canvas.width !== w || canvas.height !== h) {
          canvas.width = w;
          canvas.height = h;
        }
        const ctx = canvas.getContext("2d");
        if (ctx) {
          const s = Math.min(w / 920, h / 480);
          const ox = (w - 900 * s) / 2;
          const oy = (h - 450 * s) / 2;
          view.current = { ox, oy, s };
          draw(ctx, ox, oy, s, balls.current, heading.current, aim.current, moving.current, canRef.current && !handRef.current, drops.current);
        }
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [active]);

  function toTable(event: React.PointerEvent) {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return null;
    const { ox, oy, s } = view.current;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    return {
      x: ((event.clientX - rect.left) * dpr - ox) / s,
      y: ((event.clientY - rect.top) * dpr - oy) / s,
    };
  }

  function shoot(powered: number) {
    if (!canShoot || moving.current || state.ballInHand || state.winner !== null) return;
    const cue = state.balls.find((ball) => ball.kind === "cue" && !ball.pocketed);
    if (!cue) return;
    unlockAudio();
    const dx = heading.current.x;
    const dy = heading.current.y;
    const powerValue = Math.min(1, Math.max(0.15, powered));
    const action = { type: "shot" as const, dx, dy, power: powerValue, side: spin.side, follow: spin.follow };
    const roll = rollShot(state, action);
    frames.current = roll.frames;
    frame.current = 0;
    balls.current = roll.frames[0].map((ball) => ({ ...ball }));
    moving.current = true;
    pending.current = roll.result;
    sfx("cue", 0.55 + powerValue * 0.45);
    if (powerValue > 0.82) sfx("crash", 0.35);
    onShot(action);
    if (roll.result.log.startsWith("Foul") || roll.result.log.startsWith("Lost")) sfx("error");
    else if (roll.result.winner != null) sfx(roll.result.winner === viewer ? "win" : "lose");
  }

  return (
    <div className="relative h-full w-full overflow-hidden pr-20 pb-2 pt-16" style={{ touchAction: "none" }}>
      <div className="pointer-events-none absolute inset-x-16 top-12 z-10 flex justify-center px-2">
        <div className="max-w-full rounded-full border border-white/15 bg-black/70 px-4 py-1.5 text-center text-xs font-bold text-white">
          {hud}
        </div>
      </div>
      <canvas
        ref={canvasRef}
        className="h-full w-full touch-none"
        style={{ touchAction: "none" }}
        onPointerDown={(event) => {
          event.preventDefault();
          unlockAudio();
          if (!canShoot || moving.current) return;
          const point = toTable(event);
          if (!point) return;
          if (state.ballInHand) {
            try {
              const preview = placeCue(state, point.x, point.y);
              balls.current = preview.balls.map((ball) => ({ ...ball }));
              setHud(scoreLine(preview));
              onShot({ type: "place", x: point.x, y: point.y });
            } catch (err) {
              setHud(err instanceof Error ? err.message : "Place the cue ball on the cloth.");
              sfx("error");
            }
            return;
          }
          event.currentTarget.setPointerCapture(event.pointerId);
          aim.current = point;
        }}
        onPointerMove={(event) => {
          if (!aim.current) return;
          event.preventDefault();
          const point = toTable(event);
          const cue = balls.current.find((ball) => ball.kind === "cue" && !ball.pocketed);
          if (!point || !cue) return;
          aim.current = point;
          const fx = point.x - cue.x;
          const fy = point.y - cue.y;
          const len = Math.hypot(fx, fy) || 1;
          const behind = fx * heading.current.x + fy * heading.current.y < 0;
          if (behind) setPower(Math.min(1, Math.max(0.15, len / 180)));
          else heading.current = { x: fx / len, y: fy / len };
        }}
        onPointerUp={() => {
          const pull = aim.current;
          aim.current = null;
          const cue = balls.current.find((ball) => ball.kind === "cue" && !ball.pocketed);
          if (!pull || !cue) return;
          const fx = pull.x - cue.x;
          const fy = pull.y - cue.y;
          const len = Math.hypot(fx, fy);
          const behind = fx * heading.current.x + fy * heading.current.y < -8;
          if (behind && len > 36) shoot(Math.min(1, Math.max(0.15, len / 180)));
        }}
      />
      <div className="absolute bottom-2 right-1 top-16 z-10 flex w-16 flex-col items-center justify-end gap-2 text-white">
        <div
          className="relative h-16 w-16 shrink-0 rounded-full border-2 border-white/70 bg-[radial-gradient(circle_at_35%_30%,#fff,#d9d4cf_55%,#9a9590)] shadow"
          style={{ touchAction: "none" }}
          onPointerDown={(event) => {
            event.preventDefault();
            event.currentTarget.setPointerCapture(event.pointerId);
            setSpin(spinFrom(event));
          }}
          onPointerMove={(event) => {
            if (event.currentTarget.hasPointerCapture(event.pointerId)) setSpin(spinFrom(event));
          }}
        >
          <span
            className="absolute h-3.5 w-3.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#e10600] shadow"
            style={{ left: `${50 + spin.side * 34}%`, top: `${50 - spin.follow * 34}%` }}
          />
        </div>
        <label className="text-[10px] font-bold">Power {Math.round(power * 100)}</label>
        <input
          aria-label="Shot power"
          type="range"
          min={0.15}
          max={1}
          step={0.01}
          value={power}
          className="h-28 w-8"
          style={{ writingMode: "vertical-lr", direction: "rtl" }}
          onChange={(event) => setPower(Number(event.target.value))}
        />
        <button
          type="button"
          className="min-h-10 w-16 rounded-xl border border-white/20 px-1 text-[10px] font-bold"
          onClick={() => {
            unlockAudio();
            const next = !audioPrefs().muted;
            setAudioPrefs({ muted: next });
            setMuted(next);
            if (!next) sfx("click");
          }}
        >
          {muted ? "Sound off" : "Sound"}
        </button>
        <button
          type="button"
          disabled={!canShoot || Boolean(state.ballInHand)}
          className="min-h-11 w-16 rounded-xl bg-pink text-sm font-bold text-ink disabled:opacity-40"
          onClick={() => shoot(power)}
        >
          Shoot
        </button>
      </div>
    </div>
  );
}

function spinFrom(event: React.PointerEvent<HTMLDivElement>) {
  const rect = event.currentTarget.getBoundingClientRect();
  const x = (event.clientX - rect.left) / rect.width - 0.5;
  const y = (event.clientY - rect.top) / rect.height - 0.5;
  return {
    side: Math.max(-1, Math.min(1, x * 2)),
    follow: Math.max(-1, Math.min(1, -y * 2)),
  };
}

function scoreLine(state: SnookerState) {
  const groups = state.groups ?? [null, null];
  const bits = state.seats.map((_, index) => {
    const group = groups[index];
    const name = group === "solid" ? "Solids" : group === "stripe" ? "Stripes" : "Open";
    return `${index === state.turn ? "• " : ""}${name} ${state.scores[index] ?? 7}`;
  });
  return `${bits.join(" · ")} · ${state.log}`;
}

function draw(
  ctx: CanvasRenderingContext2D,
  ox: number,
  oy: number,
  s: number,
  balls: TableBall[],
  heading: { x: number; y: number },
  aim: { x: number; y: number } | null,
  moving: boolean,
  showCue: boolean,
  drops: { x: number; y: number; color: string; n: number; life: number }[],
) {
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
  ctx.save();
  ctx.translate(ox, oy);
  ctx.scale(s, s);

  const wood = ctx.createLinearGradient(0, 0, 0, 450);
  wood.addColorStop(0, "#8a5a32");
  wood.addColorStop(0.2, "#4a2a16");
  wood.addColorStop(0.5, "#6b3e22");
  wood.addColorStop(1, "#2c180e");
  ctx.fillStyle = wood;
  round(ctx, 6, 6, 888, 438, 26);
  ctx.fill();
  ctx.save();
  ctx.beginPath();
  round(ctx, 6, 6, 888, 438, 26);
  ctx.clip();
  ctx.strokeStyle = "rgba(255,220,170,0.08)";
  ctx.lineWidth = 2;
  for (let y = 16; y < 440; y += 9) {
    ctx.beginPath();
    ctx.moveTo(10, y);
    ctx.bezierCurveTo(220, y + 3, 640, y - 3, 890, y + 1);
    ctx.stroke();
  }
  ctx.restore();

  ctx.fillStyle = "#24140d";
  round(ctx, 22, 22, 856, 406, 16);
  ctx.fill();

  ctx.save();
  ctx.beginPath();
  round(ctx, 40, 40, 820, 370, 6);
  ctx.clip();
  const felt = ctx.createLinearGradient(40, 40, 860, 410);
  felt.addColorStop(0, "#16824c");
  felt.addColorStop(0.45, "#0c6a3c");
  felt.addColorStop(1, "#084e2c");
  ctx.fillStyle = felt;
  ctx.fillRect(40, 40, 820, 370);
  const pattern = clothPattern(ctx);
  if (pattern) {
    ctx.globalAlpha = 0.55;
    ctx.fillStyle = pattern;
    ctx.fillRect(40, 40, 820, 370);
    ctx.globalAlpha = 1;
  }
  const shine = ctx.createRadialGradient(280, 120, 20, 450, 220, 420);
  shine.addColorStop(0, "rgba(255,255,255,0.08)");
  shine.addColorStop(1, "rgba(0,0,0,0.18)");
  ctx.fillStyle = shine;
  ctx.fillRect(40, 40, 820, 370);
  ctx.restore();

  ctx.strokeStyle = "#0a3d24";
  ctx.lineWidth = 10;
  round(ctx, 46, 46, 808, 358, 4);
  ctx.stroke();
  ctx.strokeStyle = "rgba(255,255,255,0.45)";
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(250, 52);
  ctx.lineTo(250, 398);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(250, 225, 58, Math.PI * 0.5, Math.PI * 1.5);
  ctx.stroke();

  for (const pocket of POCKETS) {
    ctx.fillStyle = "#050308";
    ctx.beginPath();
    ctx.arc(pocket.x, pocket.y, 22, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#d7b07a";
    ctx.lineWidth = 4;
    ctx.stroke();
    ctx.strokeStyle = "#1a100c";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(pocket.x, pocket.y, 16, 0.2, Math.PI * 1.4);
    ctx.stroke();
  }

  const cue = balls.find((ball) => ball.kind === "cue" && !ball.pocketed);
  if (cue && showCue && !moving) {
    const ux = heading.x;
    const uy = heading.y;
    const pull = aim ? Math.min(150, Math.hypot(cue.x - aim.x, cue.y - aim.y)) : 28;
    ctx.strokeStyle = "rgba(255,255,255,0.9)";
    ctx.lineWidth = 1.25;
    ctx.setLineDash([5, 6]);
    ctx.beginPath();
    ctx.moveTo(cue.x, cue.y);
    ctx.lineTo(cue.x + ux * 280, cue.y + uy * 280);
    ctx.stroke();
    ctx.setLineDash([]);
    drawCue(ctx, cue.x, cue.y, ux, uy, Math.max(24, pull * 0.45));
  }

  const ordered = [...balls].filter((ball) => !ball.pocketed).sort((a, b) => a.y - b.y);
  for (const ball of ordered) drawBall(ctx, ball);
  for (const drop of drops) {
    ctx.globalAlpha = Math.max(0, drop.life);
    ctx.fillStyle = drop.color;
    ctx.beginPath();
    ctx.arc(drop.x, drop.y, 12 * drop.life, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;
  }
  ctx.restore();
}

function drawCue(ctx: CanvasRenderingContext2D, x: number, y: number, ux: number, uy: number, pull: number) {
  const px = -uy;
  const py = ux;
  const start = pull + 18;
  const end = start + 210;
  const tipX = x - ux * start;
  const tipY = y - uy * start;
  const buttX = x - ux * end;
  const buttY = y - uy * end;
  ctx.lineCap = "round";
  ctx.strokeStyle = "#c9854a";
  ctx.lineWidth = 7;
  ctx.beginPath();
  ctx.moveTo(buttX, buttY);
  ctx.lineTo(tipX, tipY);
  ctx.stroke();
  ctx.strokeStyle = "#f3efe6";
  ctx.lineWidth = 5;
  ctx.beginPath();
  ctx.moveTo(tipX + ux * 16, tipY + uy * 16);
  ctx.lineTo(tipX, tipY);
  ctx.stroke();
  ctx.strokeStyle = "#2f6ea8";
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(tipX, tipY);
  ctx.lineTo(tipX + ux * 5, tipY + uy * 5);
  ctx.stroke();
  ctx.fillStyle = "rgba(0,0,0,0.2)";
  ctx.beginPath();
  ctx.ellipse(x - ux * (start + 40) + px * 3, y - uy * (start + 40) + py * 3, 46, 3, Math.atan2(uy, ux), 0, Math.PI * 2);
  ctx.fill();
}

function drawBall(ctx: CanvasRenderingContext2D, ball: TableBall) {
  const speed = Math.hypot(ball.vx, ball.vy);
  const hx = speed > 8 ? (-ball.vx / speed) * 3 : -4;
  const hy = speed > 8 ? (-ball.vy / speed) * 3 : -5;
  ctx.fillStyle = "rgba(0,0,0,0.4)";
  ctx.beginPath();
  ctx.ellipse(ball.x + 2, ball.y + 9, 11, 4.2, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.save();
  ctx.beginPath();
  ctx.arc(ball.x, ball.y, 12, 0, Math.PI * 2);
  ctx.clip();
  if (ball.kind === "stripe") {
    ctx.fillStyle = "#f7f4ef";
    ctx.fillRect(ball.x - 14, ball.y - 14, 28, 28);
    ctx.fillStyle = ball.color;
    ctx.fillRect(ball.x - 14, ball.y - 5, 28, 10);
  } else if (ball.kind === "cue") {
    const gloss = ctx.createRadialGradient(ball.x + hx, ball.y + hy, 1, ball.x, ball.y, 12);
    gloss.addColorStop(0, "#ffffff");
    gloss.addColorStop(0.55, "#f4efe8");
    gloss.addColorStop(1, "#b9b3aa");
    ctx.fillStyle = gloss;
    ctx.fillRect(ball.x - 14, ball.y - 14, 28, 28);
  } else {
    const gloss = ctx.createRadialGradient(ball.x + hx, ball.y + hy, 1, ball.x, ball.y, 12);
    gloss.addColorStop(0, mix(ball.color, "#ffffff", 0.55));
    gloss.addColorStop(0.45, ball.color);
    gloss.addColorStop(1, mix(ball.color, "#000000", 0.55));
    ctx.fillStyle = gloss;
    ctx.fillRect(ball.x - 14, ball.y - 14, 28, 28);
  }
  ctx.restore();
  if (ball.n > 0) {
    ctx.fillStyle = "#f7f4ef";
    ctx.beginPath();
    ctx.arc(ball.x, ball.y, 5.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#16120f";
    ctx.font = "700 7px sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(String(ball.n), ball.x, ball.y + 0.4);
  }
  ctx.fillStyle = "rgba(255,255,255,0.8)";
  ctx.beginPath();
  ctx.ellipse(ball.x + hx, ball.y + hy, 3, 1.7, -0.5, 0, Math.PI * 2);
  ctx.fill();
}

function mix(hex: string, other: string, t: number) {
  const a = rgb(hex);
  const b = rgb(other);
  const n = (i: number) => Math.round(a[i] + (b[i] - a[i]) * t);
  return `rgb(${n(0)}, ${n(1)}, ${n(2)})`;
}

function rgb(hex: string): [number, number, number] {
  const h = hex.replace("#", "");
  if (h.length < 6) return [200, 200, 200];
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}

let cloth: CanvasPattern | null = null;
let clothCanvas: HTMLCanvasElement | null = null;

function clothPattern(ctx: CanvasRenderingContext2D) {
  if (!clothCanvas) {
    clothCanvas = document.createElement("canvas");
    clothCanvas.width = 80;
    clothCanvas.height = 80;
    const g = clothCanvas.getContext("2d");
    if (!g) return null;
    for (let i = 0; i < 280; i++) {
      g.fillStyle = i % 3 === 0 ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.06)";
      g.fillRect((i * 17) % 80, (i * 29) % 80, 1, i % 2 ? 3 : 1);
    }
  }
  cloth ??= ctx.createPattern(clothCanvas, "repeat");
  return cloth;
}

function round(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}
