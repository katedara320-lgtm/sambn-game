import { useCallback, useEffect, useRef, useState, type ReactNode, type RefObject } from "react";
import { usePlayActive } from "@/components/landscape";
import { Hold, Stick, axes, fitCanvas, useKeys } from "@/components/games/input";
import { createArena, stepArena, BLOCKS, WEAPONS, type Arena } from "@/lib/games/arena";
import { freshPad, livePad, type Pad } from "@/lib/games/pad";
import { createPitch, stepPitch, type Pitch } from "@/lib/games/pitch";
import { sfx } from "@/lib/audio";

export { SnookerPractice as SnookerGame } from "@/components/games/snooker-table";

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      getX?: () => number;
      setKeys?: (codes: string[]) => void;
      setSteer?: (v: number) => void;
    };
  }
}

export type ActionResult = { result: "win" | "loss" | "draw"; detail: string; score: number };

export type DuelLink = {
  role: "host" | "guest";
  opponent: string;
  connected: boolean;
  failed: boolean;
  remotePad: RefObject<Pad>;
  localPad: RefObject<Pad>;
  pitch: RefObject<Pitch | null>;
  arena: RefObject<Arena | null>;
};

function useOnce(onResult: (result: ActionResult) => void) {
  const sent = useRef(false);
  const cb = useRef(onResult);
  cb.current = onResult;
  return useCallback((result: ActionResult) => {
    if (sent.current) return;
    sent.current = true;
    cb.current(result);
  }, []);
}

function Stage({
  left,
  right,
  hud,
  canvasRef,
}: {
  left?: ReactNode;
  right?: ReactNode;
  hud: string;
  canvasRef: RefObject<HTMLCanvasElement | null>;
}) {
  return (
    <div className="flex h-full w-full items-stretch gap-2 px-2 pb-2 pt-14">
      <div className="flex w-36 shrink-0 items-end justify-center pb-2">{left}</div>
      <div className="relative min-w-0 flex-1">
        <canvas ref={canvasRef} className="h-full w-full rounded-2xl bg-panel" />
        <p className="pointer-events-none absolute left-3 top-3 rounded-full bg-ink/75 px-3 py-1 text-sm font-semibold">{hud}</p>
      </div>
      <div className="flex w-36 shrink-0 items-end justify-center pb-2">{right}</div>
    </div>
  );
}

type Ball = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  color: string;
  value: number;
  pocketed: boolean;
  cue: boolean;
};

const POCKETS = [
  { x: 46, y: 46 },
  { x: 450, y: 34 },
  { x: 854, y: 46 },
  { x: 46, y: 404 },
  { x: 450, y: 416 },
  { x: 854, y: 404 },
];

function rack(): Ball[] {
  const balls: Ball[] = [
    { x: 230, y: 225, vx: 0, vy: 0, r: 12, color: "#f4efe8", value: 0, pocketed: false, cue: true },
  ];
  let n = 0;
  for (let row = 0; row < 3; row++) {
    for (let col = 0; col <= row; col++) {
      balls.push({
        x: 640 + row * 26,
        y: 225 - row * 14 + col * 28,
        vx: 0,
        vy: 0,
        r: 12,
        color: "#d1263a",
        value: 1,
        pocketed: false,
        cue: false,
      });
      n += 1;
    }
  }
  const spots = [
    ["#f5c16c", 2, 300, 140],
    ["#3dffb0", 3, 300, 310],
    ["#c47a4a", 4, 300, 225],
    ["#7eb6ff", 5, 470, 225],
    ["#ff2d8a", 6, 590, 225],
    ["#141414", 7, 780, 225],
  ] as const;
  for (const [color, value, x, y] of spots) {
    balls.push({ x, y, vx: 0, vy: 0, r: 12, color, value, pocketed: false, cue: false });
  }
  void n;
  return balls;
}

function LegacySnookerGame({ onResult }: { onResult: (result: ActionResult) => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const active = usePlayActive();
  const finish = useOnce(onResult);
  const balls = useRef<Ball[]>(rack());
  const aim = useRef<{ x: number; y: number } | null>(null);
  const breakScore = useRef(0);
  const [hud, setHud] = useState("Break 0");
  const view = useRef({ ox: 0, oy: 0, s: 1 });

  useEffect(() => {
    if (!active) return;
    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.033, (now - last) / 1000);
      last = now;
      const canvas = canvasRef.current;
      if (!canvas) {
        raf = requestAnimationFrame(loop);
        return;
      }
      const fit = fitCanvas(canvas);
      if (!fit) return;
      const { ctx, w, h } = fit;
      const s = Math.min(w / 920, h / 480);
      const ox = (w - 900 * s) / 2;
      const oy = (h - 450 * s) / 2;
      view.current = { ox, oy, s };
      stepSnooker(balls.current, dt, breakScore, (score) => setHud(`Break ${score}`), finish);
      drawTable(ctx, ox, oy, s, balls.current, aim.current);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [active, finish]);

  function toTable(event: React.PointerEvent) {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return null;
    const { ox, oy, s } = view.current;
    return { x: (event.clientX - rect.left - ox) / s, y: (event.clientY - rect.top - oy) / s };
  }

  return (
    <div className="h-full w-full px-3 pb-3 pt-14">
      <canvas
        ref={canvasRef}
        className="h-full w-full"
        style={{ touchAction: "none" }}
        onPointerDown={(event) => {
          if (moving(balls.current)) return;
          event.currentTarget.setPointerCapture(event.pointerId);
          aim.current = toTable(event);
        }}
        onPointerMove={(event) => {
          if (aim.current) aim.current = toTable(event);
        }}
        onPointerUp={(event) => {
          const pull = aim.current;
          aim.current = null;
          const cue = balls.current.find((b) => b.cue && !b.pocketed);
          if (!cue || !pull || moving(balls.current)) return;
          const dx = cue.x - pull.x;
          const dy = cue.y - pull.y;
          const power = Math.min(520, Math.hypot(dx, dy) * 3.2);
          if (power < 20) return;
          const len = Math.hypot(dx, dy) || 1;
          cue.vx = (dx / len) * power;
          cue.vy = (dy / len) * power;
        }}
      />
      <p className="pointer-events-none absolute bottom-3 left-1/2 -translate-x-1/2 text-xs text-muted">{hud} · drag back from the cue ball, release to strike</p>
    </div>
  );
}

function moving(balls: Ball[]) {
  return balls.some((b) => !b.pocketed && Math.hypot(b.vx, b.vy) > 4);
}

function stepSnooker(
  balls: Ball[],
  dt: number,
  breakScore: { current: number },
  setHud: (score: number) => void,
  finish: (result: ActionResult) => void,
) {
  const sub = 4;
  const h = dt / sub;
  for (let s = 0; s < sub; s++) {
    for (const b of balls) {
      if (b.pocketed) continue;
      b.x += b.vx * h;
      b.y += b.vy * h;
      const damp = Math.exp(-1.15 * h);
      b.vx *= damp;
      b.vy *= damp;
      if (Math.hypot(b.vx, b.vy) < 6) {
        b.vx = 0;
        b.vy = 0;
      }
      for (const p of POCKETS) {
        if (Math.hypot(b.x - p.x, b.y - p.y) < 20) {
          b.pocketed = true;
          b.vx = 0;
          b.vy = 0;
          if (b.cue) {
            b.pocketed = false;
            b.x = 230;
            b.y = 225;
          } else {
            breakScore.current += b.value;
            setHud(breakScore.current);
          }
        }
      }
      const close = POCKETS.some((p) => Math.hypot(b.x - p.x, b.y - p.y) < 36);
      if (!b.pocketed && !close) {
        if (b.x < 48) {
          b.x = 48;
          b.vx = Math.abs(b.vx) * 0.82;
        }
        if (b.x > 852) {
          b.x = 852;
          b.vx = -Math.abs(b.vx) * 0.82;
        }
        if (b.y < 48) {
          b.y = 48;
          b.vy = Math.abs(b.vy) * 0.82;
        }
        if (b.y > 402) {
          b.y = 402;
          b.vy = -Math.abs(b.vy) * 0.82;
        }
      }
    }
    for (let i = 0; i < balls.length; i++) {
      for (let j = i + 1; j < balls.length; j++) collide(balls[i], balls[j]);
    }
  }
  if (balls.filter((b) => !b.cue).every((b) => b.pocketed)) {
    finish({ result: "win", detail: `Break ${breakScore.current}`, score: breakScore.current });
  }
}

function collide(a: Ball, b: Ball) {
  if (a.pocketed || b.pocketed) return;
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const dist = Math.hypot(dx, dy) || 0.001;
  const min = a.r + b.r;
  if (dist >= min) return;
  const nx = dx / dist;
  const ny = dy / dist;
  const overlap = min - dist;
  a.x -= nx * overlap * 0.5;
  a.y -= ny * overlap * 0.5;
  b.x += nx * overlap * 0.5;
  b.y += ny * overlap * 0.5;
  const rel = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny;
  if (rel > 0) return;
  const j = (-1.86 * rel) / 2;
  a.vx -= j * nx;
  a.vy -= j * ny;
  b.vx += j * nx;
  b.vy += j * ny;
}

function drawTable(
  ctx: CanvasRenderingContext2D,
  ox: number,
  oy: number,
  s: number,
  balls: Ball[],
  aim: { x: number; y: number } | null,
) {
  ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
  ctx.save();
  ctx.translate(ox, oy);
  ctx.scale(s, s);
  ctx.fillStyle = "#2a140c";
  ctx.fillRect(0, 0, 900, 450);
  ctx.fillStyle = "#0d6b45";
  ctx.fillRect(28, 28, 844, 394);
  ctx.strokeStyle = "#f6f2f8";
  ctx.lineWidth = 2;
  ctx.strokeRect(70, 70, 760, 310);
  ctx.beginPath();
  ctx.arc(250, 225, 58, 0, Math.PI * 2);
  ctx.stroke();
  for (const p of POCKETS) {
    ctx.fillStyle = "#07060b";
    ctx.beginPath();
    ctx.arc(p.x, p.y, 18, 0, Math.PI * 2);
    ctx.fill();
  }
  const cue = balls.find((b) => b.cue && !b.pocketed);
  if (cue && aim && !moving(balls)) {
    ctx.strokeStyle = "#ff2d8a";
    ctx.beginPath();
    ctx.moveTo(cue.x, cue.y);
    ctx.lineTo(aim.x, aim.y);
    ctx.stroke();
  }
  for (const b of balls) {
    if (b.pocketed) continue;
    ctx.fillStyle = b.color;
    ctx.beginPath();
    ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "rgba(255,255,255,0.35)";
    ctx.stroke();
  }
  ctx.restore();
}

export function FootballGame({ onResult, link }: { onResult: (result: ActionResult) => void; link?: DuelLink }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const active = usePlayActive();
  const keys = useKeys();
  const stick = useRef({ x: 0, y: 0 });
  const shoot = useRef(false);
  const finish = useOnce(onResult);
  const linkRef = useRef(link);
  linkRef.current = link;
  const sim = useRef(createPitch());
  const scores = useRef({ me: 0, opp: 0 });
  const [hud, setHud] = useState("0 – 0");

  useEffect(() => {
    window.__controlsTest = {
      getYaw: () => 0,
      getSpeed: () => Math.hypot(sim.current.me.vx, sim.current.me.vy),
      getX: () => sim.current.me.x,
      setKeys: (codes: string[]) => keys.setForced(codes),
    };
    return () => {
      delete window.__controlsTest;
    };
  }, [keys]);

  useEffect(() => {
    if (!active) return;
    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.033, (now - last) / 1000);
      last = now;
      const s = sim.current;
      const net = linkRef.current;
      const move = axes(keys.get(), stick.current);
      const local: Pad = {
        x: move.x,
        y: move.y,
        shoot: shoot.current || keys.get().has("Space"),
        aimX: 0,
        aimY: 0,
        fire: false,
        at: now,
      };
      if (net?.role === "guest") {
        net.localPad.current = local;
        const snap = net.pitch.current;
        if (snap) {
          s.me = snap.me;
          s.opp = snap.opp;
          s.ball = snap.ball;
          s.meScore = snap.meScore;
          s.oppScore = snap.oppScore;
          s.time = snap.time;
          s.over = snap.over;
        }
        if (s.over) {
          const mine = s.oppScore;
          const theirs = s.meScore;
          const result = mine === theirs ? "draw" : mine > theirs ? "win" : "loss";
          finish({ result, detail: `${mine}-${theirs}`, score: mine * 10 });
        }
        if (s.meScore !== scores.current.me || s.oppScore !== scores.current.opp) {
          if (s.meScore + s.oppScore > scores.current.me + scores.current.opp) sfx("goal");
          scores.current = { me: s.meScore, opp: s.oppScore };
        }
        setHud(net.connected ? `You ${s.oppScore} – ${net.opponent} ${s.meScore}` : net.failed ? "Direct connection failed" : `Waiting for ${net.opponent}…`);
      } else if (!s.over) {
        if (net && !net.connected) {
          setHud(net.failed ? "Direct connection failed" : `Waiting for ${net.opponent}…`);
        } else {
          const opp = net ? livePad(net.remotePad.current ?? freshPad(), now) : "ai";
          const beforeKick = Math.hypot(s.ball.vx, s.ball.vy);
          stepPitch(s, dt, local, opp);
          if (Math.hypot(s.ball.vx, s.ball.vy) > beforeKick + 50) sfx("kick", 0.75);
          if (s.meScore !== scores.current.me || s.oppScore !== scores.current.opp) {
            if (s.meScore + s.oppScore > scores.current.me + scores.current.opp) sfx("goal");
            scores.current = { me: s.meScore, opp: s.oppScore };
          }
          if (net) net.pitch.current = { ...s, me: { ...s.me }, opp: { ...s.opp }, ball: { ...s.ball } };
          if (s.over) {
            const result = s.meScore === s.oppScore ? "draw" : s.meScore > s.oppScore ? "win" : "loss";
            finish({ result, detail: `${s.meScore}-${s.oppScore}`, score: s.meScore * 10 });
          }
          setHud(
            net
              ? `You ${s.meScore} – ${net.opponent} ${s.oppScore} · ${Math.max(0, Math.ceil(s.time))}s`
              : `${s.meScore} – ${s.oppScore} · ${Math.max(0, Math.ceil(s.time))}s`,
          );
        }
      }
      const canvas = canvasRef.current;
      if (canvas) {
        const fit = fitCanvas(canvas);
        if (fit) drawPitch(fit.ctx, fit.w, fit.h, s);
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [active, finish, keys]);

  return (
    <Stage
      canvasRef={canvasRef}
      hud={hud}
      left={<Stick target={stick} label="Move" />}
      right={<Hold label="SHOOT" down={shoot} />}
    />
  );
}

function drawPitch(ctx: CanvasRenderingContext2D, w: number, h: number, s: Pitch) {
  const sx = w / 960;
  const sy = h / 480;
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = "#0c3d2e";
  ctx.fillRect(0, 0, w, h);
  ctx.save();
  ctx.scale(sx, sy);
  ctx.strokeStyle = "rgba(246,242,248,0.8)";
  ctx.lineWidth = 3;
  ctx.strokeRect(20, 20, 920, 440);
  ctx.beginPath();
  ctx.moveTo(480, 20);
  ctx.lineTo(480, 460);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(480, 240, 60, 0, Math.PI * 2);
  ctx.stroke();
  ctx.strokeRect(20, 160, 90, 160);
  ctx.strokeRect(850, 160, 90, 160);
  const dot = (p: { x: number; y: number }, color: string) => {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, 16, 0, Math.PI * 2);
    ctx.fill();
  };
  dot(s.opp, "#1a1020");
  dot(s.me, "#ff2d8a");
  ctx.fillStyle = "#f6f2f8";
  ctx.beginPath();
  ctx.arc(s.ball.x, s.ball.y, 8, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

type Zed = { x: number; y: number; hp: number };

function clamp(n: number, a: number, b: number) {
  return Math.max(a, Math.min(b, n));
}

export function ZombieGame({ onResult }: { onResult: (result: ActionResult) => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const active = usePlayActive();
  const keys = useKeys();
  const move = useRef({ x: 0, y: 0 });
  const aim = useRef({ x: 0, y: 0 });
  const fire = useRef(false);
  const finish = useOnce(onResult);
  const sim = useRef({
    x: 480,
    y: 240,
    facing: 0,
    hp: 100,
    cool: 0,
    hurt: 0,
    kills: 0,
    time: 0,
    spawn: 0,
    wave: 1,
    bullets: [] as { x: number; y: number; vx: number; vy: number }[],
    zeds: [] as Zed[],
    over: false,
  });
  const [hud, setHud] = useState("HP 100");

  useEffect(() => {
    if (!active) return;
    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.033, (now - last) / 1000);
      last = now;
      const s = sim.current;
      if (!s.over) {
        const mv = axes(keys.get(), move.current);
        s.x = clamp(s.x + mv.x * 210 * dt, 30, 930);
        s.y = clamp(s.y + mv.y * 210 * dt, 30, 450);
        if (Math.hypot(mv.x, mv.y) > 0.2) s.facing = Math.atan2(mv.y, mv.x);
        const aimVec = Math.hypot(aim.current.x, aim.current.y) > 0.2 ? aim.current : { x: Math.cos(s.facing), y: Math.sin(s.facing) };
        if (Math.hypot(aim.current.x, aim.current.y) > 0.2) s.facing = Math.atan2(aim.current.y, aim.current.x);
        s.cool -= dt;
        s.hurt -= dt;
        const shooting = fire.current || keys.get().has("Space") || Math.hypot(aim.current.x, aim.current.y) > 0.55;
        if (shooting && s.cool <= 0) {
          s.cool = 0.16;
          const len = Math.hypot(aimVec.x, aimVec.y) || 1;
          s.bullets.push({ x: s.x, y: s.y, vx: (aimVec.x / len) * 560, vy: (aimVec.y / len) * 560 });
        }
        s.spawn -= dt;
        if (s.spawn <= 0) {
          s.spawn = Math.max(0.35, 1.15 - s.wave * 0.08);
          const edge = Math.floor(Math.random() * 4);
          const z = { x: 480, y: 20, hp: 2 + Math.floor(s.wave / 2) };
          if (edge === 0) z.y = 20;
          if (edge === 1) z.y = 460;
          if (edge === 2) z.x = 20;
          if (edge === 3) z.x = 940;
          if (edge < 2) z.x = 40 + Math.random() * 880;
          else z.y = 40 + Math.random() * 400;
          s.zeds.push(z);
        }
        s.time += dt;
        s.wave = 1 + Math.floor(s.time / 18);
        const speed = 55 + s.wave * 9;
        for (const z of s.zeds) {
          const dx = s.x - z.x;
          const dy = s.y - z.y;
          const m = Math.hypot(dx, dy) || 1;
          z.x += (dx / m) * speed * dt;
          z.y += (dy / m) * speed * dt;
          if (m < 26 && s.hurt <= 0) {
            s.hp -= 12;
            s.hurt = 0.55;
          }
        }
        s.bullets.forEach((b) => {
          b.x += b.vx * dt;
          b.y += b.vy * dt;
        });
        s.bullets = s.bullets.filter((b) => b.x > 0 && b.x < 960 && b.y > 0 && b.y < 480);
        for (const b of s.bullets) {
          for (const z of s.zeds) {
            if (z.hp <= 0) continue;
            if (Math.hypot(b.x - z.x, b.y - z.y) < 18) {
              z.hp -= 1;
              b.x = -999;
              if (z.hp <= 0) s.kills += 1;
            }
          }
        }
        s.zeds = s.zeds.filter((z) => z.hp > 0);
        if (s.hp <= 0) {
          s.over = true;
          const win = s.time >= 75;
          finish({
            result: win ? "win" : "loss",
            detail: `${s.kills} kills · ${Math.floor(s.time)}s`,
            score: s.kills * 10 + Math.floor(s.time),
          });
        } else if (s.time >= 75) {
          s.over = true;
          finish({ result: "win", detail: `${s.kills} kills · survived`, score: s.kills * 10 + 75 });
        }
        setHud(`HP ${Math.max(0, Math.ceil(s.hp))} · ${s.kills} kills · wave ${s.wave}`);
      }
      const canvas = canvasRef.current;
      if (canvas) {
        const fit = fitCanvas(canvas);
        if (fit) drawZed(fit.ctx, fit.w, fit.h, s);
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [active, finish, keys]);

  return (
    <Stage
      canvasRef={canvasRef}
      hud={hud}
      left={<Stick target={move} label="Move" />}
      right={
        <div className="flex flex-col items-center gap-3">
          <Stick target={aim} label="Aim" />
          <Hold label="FIRE" down={fire} />
        </div>
      }
    />
  );
}

function drawZed(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  s: { x: number; y: number; facing: number; bullets: { x: number; y: number }[]; zeds: Zed[] },
) {
  const sx = w / 960;
  const sy = h / 480;
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = "#12080f";
  ctx.fillRect(0, 0, w, h);
  ctx.save();
  ctx.scale(sx, sy);
  ctx.strokeStyle = "#3a1228";
  for (let i = 0; i < 8; i++) {
    ctx.strokeRect(40 + i * 110, 30, 80, 420);
  }
  for (const z of s.zeds) {
    ctx.fillStyle = "#6cff9a";
    ctx.beginPath();
    ctx.arc(z.x, z.y, 14, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.fillStyle = "#ff2d8a";
  for (const b of s.bullets) {
    ctx.fillRect(b.x - 3, b.y - 3, 6, 6);
  }
  ctx.fillStyle = "#f6f2f8";
  ctx.beginPath();
  ctx.arc(s.x, s.y, 15, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#ff2d8a";
  ctx.beginPath();
  ctx.moveTo(s.x, s.y);
  ctx.lineTo(s.x + Math.cos(s.facing) * 26, s.y + Math.sin(s.facing) * 26);
  ctx.stroke();
  ctx.restore();
}

function rayHit(ox: number, oy: number, angle: number) {
  const dx = Math.cos(angle);
  const dy = Math.sin(angle);
  let best = 1200;
  const boxes = [
    ...BLOCKS,
    { x: -40, y: -40, w: 1040, h: 40 },
    { x: -40, y: 480, w: 1040, h: 40 },
    { x: -40, y: 0, w: 40, h: 480 },
    { x: 960, y: 0, w: 40, h: 480 },
  ];
  for (const b of boxes) {
    let tmin = 0;
    let tmax = 1200;
    const axes = [
      [dx, ox, b.x, b.x + b.w],
      [dy, oy, b.y, b.y + b.h],
    ] as const;
    let miss = false;
    for (const [d, o, min, max] of axes) {
      if (Math.abs(d) < 1e-8) {
        if (o < min || o > max) miss = true;
        continue;
      }
      let t1 = (min - o) / d;
      let t2 = (max - o) / d;
      if (t1 > t2) {
        const swap = t1;
        t1 = t2;
        t2 = swap;
      }
      tmin = Math.max(tmin, t1);
      tmax = Math.min(tmax, t2);
      if (tmin > tmax) miss = true;
    }
    if (!miss && tmin > 0.02 && tmin < best) best = tmin;
  }
  return best;
}

function paintFps(ctx: CanvasRenderingContext2D, w: number, h: number, s: Arena, guest: boolean, flash: number) {
  const cam = guest ? s.bot : s;
  const foe = guest ? { x: s.x, y: s.y, hp: s.hp, hop: s.hop, crouch: s.crouch } : s.bot;
  const horizon = h * (0.46 + (cam.crouch > 0 ? 0.06 : 0) - (cam.hop > 0 ? 0.05 : 0));
  const sky = ctx.createLinearGradient(0, 0, 0, horizon);
  sky.addColorStop(0, "#140812");
  sky.addColorStop(1, "#3a1830");
  ctx.fillStyle = sky;
  ctx.fillRect(0, 0, w, horizon);
  const floor = ctx.createLinearGradient(0, horizon, 0, h);
  floor.addColorStop(0, "#2a1a22");
  floor.addColorStop(1, "#09070b");
  ctx.fillStyle = floor;
  ctx.fillRect(0, horizon, w, h - horizon);
  const fov = Math.PI / 2.4;
  const step = Math.max(2, Math.floor(w / 220));
  for (let x = 0; x < w; x += step) {
    const angle = cam.facing - fov / 2 + (x / w) * fov;
    const dist = rayHit(cam.x, cam.y, angle);
    const size = Math.min(h * 0.92, (h * 420) / dist);
    const top = horizon - size / 2;
    const shade = Math.max(18, 150 - dist * 0.12);
    ctx.fillStyle = `rgb(${shade * 0.45}, ${shade * 0.2}, ${shade * 0.35})`;
    ctx.fillRect(x, top, step + 1, size);
    ctx.fillStyle = "rgba(255,45,138,0.18)";
    ctx.fillRect(x, top, step + 1, 3);
  }
  const dx = foe.x - cam.x;
  const dy = foe.y - cam.y;
  const dist = Math.hypot(dx, dy) || 1;
  let ang = Math.atan2(dy, dx) - cam.facing;
  while (ang > Math.PI) ang -= Math.PI * 2;
  while (ang < -Math.PI) ang += Math.PI * 2;
  if (Math.abs(ang) < fov / 2 && dist < 900 && rayHit(cam.x, cam.y, Math.atan2(dy, dx)) > dist - 16) {
    const sx = w / 2 + (ang / (fov / 2)) * (w / 2);
    const body = Math.min(h * 0.8, (h * 260) / dist);
    ctx.fillStyle = "#f5c16c";
    ctx.fillRect(sx - body * 0.16, horizon - body * 0.72, body * 0.32, body * 0.72);
    ctx.fillStyle = "#1a1014";
    ctx.fillRect(sx - body * 0.08, horizon - body * 0.62, body * 0.16, body * 0.08);
  }
  const gun = WEAPONS[cam.slot] ?? WEAPONS[0];
  const kick = cam.cool > gun.rate * 0.6 ? 18 : 0;
  ctx.fillStyle = "#1c1418";
  ctx.fillRect(w * 0.46, h * 0.62 + kick, w * 0.08, h * 0.4);
  ctx.fillStyle = gun.id === "shotgun" ? "#6b4226" : gun.id === "sniper" ? "#8a93a0" : "#2a2a30";
  ctx.fillRect(w * 0.48, h * 0.58 + kick, w * 0.22, h * 0.08);
  if (flash > 0) {
    ctx.fillStyle = `rgba(255,220,140,${flash})`;
    ctx.beginPath();
    ctx.arc(w * 0.7, h * 0.58 + kick, 16 + flash * 20, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.strokeStyle = "rgba(246,242,248,0.7)";
  ctx.strokeRect(w / 2 - 8, h / 2 - 8, 16, 16);
}

export function ShooterGame({ onResult, link }: { onResult: (result: ActionResult) => void; link?: DuelLink }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const active = usePlayActive();
  const keys = useKeys();
  const move = useRef({ x: 0, y: 0 });
  const aim = useRef({ x: 0, y: 0 });
  const fire = useRef(false);
  const reload = useRef(false);
  const crouch = useRef(false);
  const jump = useRef(false);
  const slot = useRef(0);
  const mouseTurn = useRef(0);
  const finish = useOnce(onResult);
  const linkRef = useRef(link);
  linkRef.current = link;
  const sim = useRef(createArena());
  const [hud, setHud] = useState("Rifle · 30/90 · HP 100");

  useEffect(() => {
    if (!active) return;
    const look = (event: MouseEvent) => {
      if (document.pointerLockElement) mouseTurn.current += event.movementX * 0.0035;
    };
    const down = (event: MouseEvent) => {
      if (event.button !== 0) return;
      const canvas = canvasRef.current;
      if (!canvas || !canvas.contains(event.target as Node)) return;
      fire.current = true;
      if (canvas.requestPointerLock) void canvas.requestPointerLock();
    };
    const up = (event: MouseEvent) => {
      if (event.button === 0) fire.current = false;
    };
    const key = (event: KeyboardEvent) => {
      const tag = (event.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if (event.code === "KeyR") reload.current = true;
      if (event.code === "KeyC") crouch.current = true;
      if (event.code === "Space") jump.current = true;
      const n = ["Digit1", "Digit2", "Digit3", "Digit4", "Digit5"].indexOf(event.code);
      if (n >= 0) slot.current = n;
    };
    const keyup = (event: KeyboardEvent) => {
      if (event.code === "KeyR") reload.current = false;
      if (event.code === "KeyC") crouch.current = false;
      if (event.code === "Space") jump.current = false;
    };
    window.addEventListener("mousemove", look);
    window.addEventListener("mousedown", down);
    window.addEventListener("mouseup", up);
    window.addEventListener("keydown", key);
    window.addEventListener("keyup", keyup);
    return () => {
      window.removeEventListener("mousemove", look);
      window.removeEventListener("mousedown", down);
      window.removeEventListener("mouseup", up);
      window.removeEventListener("keydown", key);
      window.removeEventListener("keyup", keyup);
    };
  }, [active]);

  useEffect(() => {
    if (!active) return;
    let raf = 0;
    let last = performance.now();
    let lastHp = sim.current.hp;
    let flash = 0;
    const loop = (now: number) => {
      const dt = Math.min(0.033, (now - last) / 1000);
      last = now;
      const s = sim.current;
      const net = linkRef.current;
      const mv = axes(keys.get(), move.current);
      const held = keys.get();
      if (held.has("KeyR")) reload.current = true;
      const n = ["Digit1", "Digit2", "Digit3", "Digit4", "Digit5"].findIndex((code) => held.has(code));
      if (n >= 0) slot.current = n;
      const local: Pad = {
        x: mv.x,
        y: mv.y,
        shoot: false,
        aimX: aim.current.x,
        aimY: aim.current.y,
        fire: fire.current,
        at: now,
        turn: aim.current.x * 2.4 + mouseTurn.current / Math.max(dt, 0.001),
        reload: reload.current,
        crouch: crouch.current || held.has("KeyC"),
        jump: jump.current,
        slot: slot.current,
      };
      mouseTurn.current = 0;
      jump.current = false;
      const meView = net?.role === "guest" ? s.bot : s;
      const paint = () => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const fit = fitCanvas(canvas);
        if (!fit) return;
        flash = Math.max(0, flash - dt * 6);
        if (meView.cool > (WEAPONS[meView.slot]?.rate ?? 0.2) * 0.7) flash = 1;
        paintFps(fit.ctx, fit.w, fit.h, s, net?.role === "guest", flash);
      };
      if (net?.role === "guest") {
        net.localPad.current = local;
        const snap = net.arena.current;
        if (snap) {
          sim.current = snap;
        }
        const view = sim.current.bot;
        if (sim.current.over) {
          const mine = view.stocks;
          const theirs = sim.current.stocks;
          const result = mine === theirs ? "draw" : mine > theirs ? "win" : "loss";
          finish({ result, detail: `Stocks ${mine}-${theirs}`, score: mine * 20 });
        }
        const gun = WEAPONS[view.slot] ?? WEAPONS[0];
        setHud(
          net.connected
            ? `${gun.name} ${view.mag}/${view.reserve} · HP ${Math.max(0, Math.ceil(view.hp))} · You ${view.stocks} · ${net.opponent} ${sim.current.stocks} · ${Math.ceil(sim.current.clock)}s`
            : net.failed
              ? "Direct connection failed"
              : `Waiting for ${net.opponent}…`,
        );
        paint();
        raf = requestAnimationFrame(loop);
        return;
      }
      if (!s.over) {
        if (net && !net.connected) {
          setHud(net.failed ? "Direct connection failed" : `Waiting for ${net.opponent}…`);
        } else {
          const before = s.cool;
          stepArena(s, dt, local, net ? livePad(net.remotePad.current ?? freshPad(), now) : "ai");
          if (s.cool > before) sfx(WEAPONS[s.slot]?.id === "shotgun" ? "crash" : "kick", 0.45);
          if (s.hp < lastHp - 0.4) sfx("collide", 0.55);
          lastHp = s.hp;
          if (net) net.arena.current = s;
          if (s.over) {
            const timed = s.clock <= 0 && s.stocks > 0 && s.bot.stocks > 0;
            const result = s.stocks === s.bot.stocks ? "draw" : s.stocks > s.bot.stocks ? "win" : "loss";
            finish({ result, detail: timed ? `Time · ${s.stocks}-${s.bot.stocks}` : `Stocks ${s.stocks}-${s.bot.stocks}`, score: s.stocks * 20 });
          }
          const gun = WEAPONS[s.slot] ?? WEAPONS[0];
          setHud(
            net
              ? `${gun.name} ${s.mag}/${s.reserve} · HP ${Math.max(0, Math.ceil(s.hp))} · You ${s.stocks} · ${net.opponent} ${s.bot.stocks} · ${Math.ceil(s.clock)}s`
              : `${gun.name} ${s.mag}/${s.reserve} · HP ${Math.max(0, Math.ceil(s.hp))} · You ${s.stocks} · Computer ${s.bot.stocks} · ${Math.ceil(s.clock)}s`,
          );
        }
      }
      paint();
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [active, finish, keys]);

  return (
    <Stage
      canvasRef={canvasRef}
      hud={hud}
      left={<Stick target={move} label="Move" />}
      right={
        <div className="flex flex-col items-end gap-2">
          <Stick target={aim} label="Look" />
          <div className="flex gap-2">
            <Hold label="FIRE" down={fire} />
            <div className="flex flex-col gap-2">
              <Hold label="RELOAD" down={reload} />
              <button type="button" className="h-11 rounded-xl bg-panel px-2 text-xs font-bold" onClick={() => (crouch.current = !crouch.current)}>
                Crouch
              </button>
              <button type="button" className="h-11 rounded-xl bg-panel px-2 text-xs font-bold" onClick={() => (jump.current = true)}>
                Jump
              </button>
              <button
                type="button"
                className="h-11 rounded-xl bg-panel px-2 text-xs font-bold"
                onClick={() => {
                  slot.current = (slot.current + 1) % WEAPONS.length;
                }}
              >
                Weapon
              </button>
            </div>
          </div>
        </div>
      }
    />
  );
}

const MAP = [
  "####################",
  "#S....T......~~..R.#",
  "#..##......~~~~....#",
  "#......N..T..~~....#",
  "#..##......R.~~..H.#",
  "#....R...~~~~......#",
  "#..........~~..T...#",
  "#..##.............E#",
  "####################",
];

export function AdventureGame({ onResult }: { onResult: (result: ActionResult) => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const active = usePlayActive();
  const keys = useKeys();
  const stick = useRef({ x: 0, y: 0 });
  const finish = useOnce(onResult);
  const relics = useRef(new Set<string>());
  const sim = useRef({ x: 72, y: 72, talk: "" });
  const [hud, setHud] = useState("Relics 0/3");
  const [talk, setTalk] = useState("");

  useEffect(() => {
    if (!active) return;
    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.033, (now - last) / 1000);
      last = now;
      const mv = axes(keys.get(), stick.current);
      const speed = 150 * dt;
      tryMove(sim.current, mv.x * speed, 0);
      tryMove(sim.current, 0, mv.y * speed);
      const cell = tileAt(sim.current.x, sim.current.y);
      if (cell === "R") {
        const key = `${Math.floor(sim.current.x / 48)},${Math.floor(sim.current.y / 48)}`;
        relics.current.add(key);
      }
      let nextTalk = "";
      if (cell === "N") nextTalk = "The river only looks deep. The relics shine gold.";
      else if (cell === "E") {
        nextTalk = relics.current.size >= 3 ? "The elder nods. The savanna remembers you." : "Three relics, then come back.";
        if (relics.current.size >= 3) finish({ result: "win", detail: "Relics returned", score: 100 });
      } else if (cell === "H") nextTalk = "A quiet hut. Nobody is home.";
      if (nextTalk !== sim.current.talk) {
        sim.current.talk = nextTalk;
        setTalk(nextTalk);
      }
      setHud(`Relics ${Math.min(3, relics.current.size)}/3`);
      const canvas = canvasRef.current;
      if (canvas) {
        const fit = fitCanvas(canvas);
        if (fit) drawWorld(fit.ctx, fit.w, fit.h, sim.current, relics.current);
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [active, finish, keys]);

  return (
    <div className="flex h-full w-full gap-3 px-3 pb-3 pt-14">
      <div className="flex w-36 items-end justify-center">
        <Stick target={stick} label="Walk" />
      </div>
      <div className="relative min-w-0 flex-1">
        <canvas ref={canvasRef} className="h-full w-full rounded-2xl" />
        <p className="absolute left-3 top-3 rounded-full bg-ink/80 px-3 py-1 text-sm">{hud}</p>
        {talk ? (
          <p className="absolute inset-x-4 bottom-3 rounded-xl bg-panel/95 px-3 py-2 text-sm">{talk}</p>
        ) : null}
      </div>
      <div className="hidden w-28 sm:block" />
    </div>
  );
}

function tileAt(x: number, y: number) {
  const c = Math.floor(x / 48);
  const r = Math.floor(y / 48);
  return MAP[r]?.[c] ?? "#";
}

function blocked(x: number, y: number) {
  const ch = tileAt(x, y);
  return ch === "#" || ch === "T" || ch === "~";
}

function tryMove(p: { x: number; y: number }, dx: number, dy: number) {
  const nx = p.x + dx;
  const ny = p.y + dy;
  if (!blocked(nx, p.y)) p.x = nx;
  if (!blocked(p.x, ny)) p.y = ny;
}

function drawWorld(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  p: { x: number; y: number },
  relics: Set<string>,
) {
  const scale = Math.max(w / (MAP[0].length * 48), h / (MAP.length * 48));
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = "#102418";
  ctx.fillRect(0, 0, w, h);
  ctx.save();
  ctx.translate(w / 2, h / 2);
  ctx.scale(scale, scale);
  ctx.translate(-p.x, -p.y);
  for (let r = 0; r < MAP.length; r++) {
    for (let c = 0; c < MAP[r].length; c++) {
      const ch = MAP[r][c];
      const x = c * 48;
      const y = r * 48;
      ctx.fillStyle = ch === "~" ? "#16324a" : ch === "#" ? "#07060b" : "#1d4a32";
      ctx.fillRect(x, y, 48, 48);
      if (ch === "T") {
        ctx.fillStyle = "#0d2416";
        ctx.beginPath();
        ctx.moveTo(x + 24, y + 6);
        ctx.lineTo(x + 40, y + 40);
        ctx.lineTo(x + 8, y + 40);
        ctx.fill();
      }
      if (ch === "H") {
        ctx.fillStyle = "#3a1228";
        ctx.fillRect(x + 8, y + 16, 32, 24);
      }
      if (ch === "R" && !relics.has(`${c},${r}`)) {
        ctx.fillStyle = "#f5c16c";
        ctx.beginPath();
        ctx.arc(x + 24, y + 24, 8, 0, Math.PI * 2);
        ctx.fill();
      }
      if (ch === "N" || ch === "E") {
        ctx.fillStyle = ch === "E" ? "#f5c16c" : "#f6f2f8";
        ctx.beginPath();
        ctx.arc(x + 24, y + 24, 12, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }
  ctx.fillStyle = "#ff2d8a";
  ctx.beginPath();
  ctx.arc(p.x, p.y, 12, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}
