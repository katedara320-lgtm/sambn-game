import { useEffect, useRef } from "react";

export function useKeys() {
  const held = useRef(new Set<string>());
  const forced = useRef<string[] | null>(null);
  useEffect(() => {
    const down = (event: KeyboardEvent) => {
      const tag = (event.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      held.current.add(event.code);
      if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Space"].includes(event.code)) event.preventDefault();
    };
    const up = (event: KeyboardEvent) => held.current.delete(event.code);
    const blur = () => held.current.clear();
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    window.addEventListener("blur", blur);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
      window.removeEventListener("blur", blur);
    };
  }, []);
  const api = useRef({
    get(): Set<string> {
      return forced.current ? new Set(forced.current) : held.current;
    },
    setForced(codes: string[]) {
      forced.current = codes;
    },
  });
  return api.current;
}

export function axes(keys: Set<string>, stick: { x: number; y: number }) {
  let x = 0;
  let y = 0;
  if (keys.has("KeyA") || keys.has("ArrowLeft")) x -= 1;
  if (keys.has("KeyD") || keys.has("ArrowRight")) x += 1;
  if (keys.has("KeyW") || keys.has("ArrowUp")) y -= 1;
  if (keys.has("KeyS") || keys.has("ArrowDown")) y += 1;
  if (Math.hypot(stick.x, stick.y) > 0.18) {
    x = stick.x;
    y = stick.y;
  }
  const m = Math.hypot(x, y);
  if (m > 1) {
    x /= m;
    y /= m;
  }
  return { x, y };
}

export function Stick({
  target,
  label,
}: {
  target: { current: { x: number; y: number } };
  label: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const knob = useRef<HTMLSpanElement>(null);
  function place(clientX: number, clientY: number) {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    let x = (clientX - (r.left + r.width / 2)) / (r.width / 2);
    let y = (clientY - (r.top + r.height / 2)) / (r.height / 2);
    const m = Math.hypot(x, y);
    if (m > 1) {
      x /= m;
      y /= m;
    }
    target.current = { x, y };
    if (knob.current) knob.current.style.transform = `translate(${x * 36}px, ${y * 36}px)`;
  }
  function release() {
    target.current = { x: 0, y: 0 };
    if (knob.current) knob.current.style.transform = "translate(0px, 0px)";
  }
  return (
    <div className="flex flex-col items-center gap-2">
      <div
        ref={ref}
        role="application"
        aria-label={label}
        className="relative grid h-28 w-28 place-items-center rounded-full border border-line bg-panel/90"
        style={{ touchAction: "none" }}
        onPointerDown={(event) => {
          event.currentTarget.setPointerCapture(event.pointerId);
          place(event.clientX, event.clientY);
        }}
        onPointerMove={(event) => {
          if (event.currentTarget.hasPointerCapture(event.pointerId)) place(event.clientX, event.clientY);
        }}
        onPointerUp={release}
        onPointerCancel={release}
      >
        <span ref={knob} className="h-12 w-12 rounded-full bg-pink" />
      </div>
      <span className="text-xs text-muted">{label}</span>
    </div>
  );
}

export function Hold({
  label,
  down,
}: {
  label: string;
  down: { current: boolean };
}) {
  return (
    <button
      type="button"
      className="h-24 w-24 rounded-full bg-pink font-display text-sm font-extrabold text-ink"
      style={{ touchAction: "none" }}
      onPointerDown={(event) => {
        event.preventDefault();
        down.current = true;
      }}
      onPointerUp={() => {
        down.current = false;
      }}
      onPointerCancel={() => {
        down.current = false;
      }}
      onPointerLeave={() => {
        down.current = false;
      }}
    >
      {label}
    </button>
  );
}

export function fitCanvas(canvas: HTMLCanvasElement) {
  const rect = canvas.getBoundingClientRect();
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  const w = Math.max(2, Math.floor(rect.width * dpr));
  const h = Math.max(2, Math.floor(rect.height * dpr));
  if (canvas.width !== w || canvas.height !== h) {
    canvas.width = w;
    canvas.height = h;
  }
  const ctx = canvas.getContext("2d");
  if (!ctx) return null;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  return { ctx, w: rect.width, h: rect.height };
}
