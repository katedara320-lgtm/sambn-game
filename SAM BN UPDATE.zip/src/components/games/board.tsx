import { useEffect, useRef, useState, type ReactNode } from "react";
import { legalMoves, type ChessState } from "@/lib/games/chess";
import { LADDERS, SNAKES, type SnakesState } from "@/lib/games/snakes";
import { playable, WHOT_RULES, type Shape, type WhotState } from "@/lib/games/whot";
import { sfx } from "@/lib/audio";
import { TILES, rentOf, type ZonoState } from "@/lib/games/zonopoly";

function Side({ children }: { children: ReactNode }) {
  return <aside className="flex w-28 shrink-0 flex-col justify-between gap-3 sm:w-44">{children}</aside>;
}

function Seat({ name, active, detail }: { name: string; active?: boolean; detail: string }) {
  return (
    <div className={`rounded-xl border px-3 py-2 ${active ? "border-pink bg-pink-dim" : "border-line bg-panel"}`}>
      <p className="truncate text-sm font-bold">{name}</p>
      <p className="text-xs text-muted">{detail}</p>
    </div>
  );
}

export function ChessTable({
  state,
  me,
  names,
  onMove,
}: {
  state: ChessState;
  me: string;
  names: Record<string, string>;
  onMove: (from: number, to: number) => void;
}) {
  const mine = !state.winner && (state.turn === "w" ? state.seats[0] === me : state.seats[1] === me);
  const moves = mine ? legalMoves(state) : [];
  const pick = useChessPick(moves, onMove);
  return (
    <div className="flex h-full w-full gap-3 px-3 pb-3 pt-14">
      <Side>
        <Seat name={names[state.seats[1]] ?? "Black"} active={state.turn === "b"} detail="Black" />
        <Seat name={names[state.seats[0]] ?? "White"} active={state.turn === "w"} detail="White" />
      </Side>
      <div className="grid min-w-0 flex-1 place-items-center">
        <div className="grid aspect-square h-[min(100%,70vw)] max-h-full grid-cols-8 overflow-hidden rounded-xl border border-line">
          {Array.from({ length: 64 }, (_, i) => {
            const p = state.board[i];
            const dark = (Math.floor(i / 8) + (i % 8)) % 2 === 1;
            const from = pick.from === i;
            const target = pick.from !== null && moves.some((m) => m.from === pick.from && m.to === i);
            const whitePiece = p !== "." && p === p.toUpperCase();
            return (
              <button
                key={i}
                type="button"
                onClick={() => pick.tap(i)}
                className={`grid place-items-center font-display text-lg font-extrabold sm:text-2xl ${dark ? "bg-panel-2" : "bg-pink-dim"} ${from ? "ring-2 ring-pink ring-inset" : ""}`}
              >
                <span className={p === "." ? "text-pink" : whitePiece ? "text-fg" : "text-pink"}>
                  {p === "." ? (target ? "•" : "") : p.toUpperCase()}
                </span>
              </button>
            );
          })}
        </div>
      </div>
      <Side>
        <p className="text-sm text-muted">{state.winner ? state.reason || "Game over" : mine ? "Your move" : "Waiting"}</p>
        <p className="text-xs text-muted">Tap a piece, then a square. Promotion is always a queen.</p>
      </Side>
    </div>
  );
}

function useChessPick(moves: { from: number; to: number }[], onMove: (from: number, to: number) => void) {
  const [from, setFrom] = useState<number | null>(null);
  return {
    from,
    tap(i: number) {
      if (from !== null && moves.some((m) => m.from === from && m.to === i)) {
        onMove(from, i);
        setFrom(null);
        return;
      }
      if (moves.some((m) => m.from === i)) setFrom(i);
      else setFrom(null);
    },
  };
}

export function WhotTable({
  state,
  me,
  names,
  onPlay,
  onDraw,
}: {
  state: WhotState;
  me: string;
  names: Record<string, string>;
  onPlay: (cardId: string, call?: Shape) => void;
  onDraw: () => void;
}) {
  const seat = state.seats.indexOf(me);
  const hand = state.hands[seat] ?? [];
  const mine = state.seats[state.turn] === me && state.winner === null;
  const [callFor, setCallFor] = useState<string | null>(null);
  const top = state.discard[state.discard.length - 1];
  const heard = useRef(state.winner);
  useEffect(() => {
    if (state.winner === null) {
      heard.current = null;
      return;
    }
    if (heard.current === state.winner) return;
    heard.current = state.winner;
    const won = typeof state.winner === "number" && state.seats[state.winner] === me;
    sfx(state.winner === "draw" ? "draw" : won ? "win" : "lose");
  }, [state.winner, me, state.seats]);
  return (
    <div className="flex h-full w-full flex-col gap-2 bg-[#146b3a] px-3 pb-3 pt-14">
      <div className="flex gap-2 overflow-x-auto">
        {state.seats.map((id, i) => (
          <Seat
            key={id + i}
            name={names[id] ?? "Player"}
            active={state.turn === i}
            detail={i === seat ? "You" : `${state.hands[i]?.length ?? 0} cards`}
          />
        ))}
      </div>
      <div className="grid flex-1 place-items-center">
        <div className="text-center">
          <div className="flex items-end justify-center gap-3">
            <CardView card={{ shape: "whot", n: 20 }} faceDown />
            {top ? <CardView card={top} /> : null}
          </div>
          <p className="mt-2 text-sm text-white/80">
            Shape: {state.shape}
            {state.pending ? ` · ${pickLabel(state.pending, state.demand)}` : ""} · {state.log}
          </p>
        </div>
      </div>
      <div className="flex items-end gap-2 overflow-x-auto pb-1">
        {hand.map((card) => {
          const ok = mine && playable(state, card);
          return (
            <button
              key={card.id}
              type="button"
              disabled={!ok}
              onClick={() => {
                sfx("card");
                if (card.shape === "whot") setCallFor(card.id);
                else onPlay(card.id);
              }}
              className={ok ? "" : "opacity-50"}
            >
              <CardView card={card} />
            </button>
          );
        })}
        <button
          type="button"
          disabled={!mine}
          onClick={() => {
            sfx("card");
            onDraw();
          }}
          className="min-h-11 rounded-xl bg-pink px-4 py-3 text-sm font-bold text-ink disabled:opacity-40"
        >
          {pickLabel(state.pending, state.demand)}
        </button>
      </div>
      <p className="text-center text-[11px] leading-snug text-white/70">{WHOT_RULES}</p>
      {callFor ? (
        <div className="absolute inset-x-0 bottom-24 z-10 mx-auto flex max-w-lg flex-wrap justify-center gap-2">
          {(["circle", "triangle", "cross", "square", "star"] as Shape[]).map((shape) => (
            <button
              key={shape}
              type="button"
              className="min-h-11 rounded-xl border border-white/30 bg-white px-3 py-2 text-sm capitalize text-ink"
              onClick={() => {
                onPlay(callFor, shape);
                setCallFor(null);
              }}
            >
              {shape}
            </button>
          ))}
        </div>
      ) : null}
    </div>
  );
}

const SUIT: Record<Shape, string> = {
  circle: "#c0392b",
  triangle: "#1d4e89",
  cross: "#d35400",
  square: "#1e7a46",
  star: "#1a1a1a",
  whot: "#9a1c1c",
};

function pickLabel(pending: number, demand: 0 | 2 | 5) {
  if (!pending) return "Draw";
  if (demand === 2) return pending === 2 ? "Pick two" : `Pick ${pending}`;
  if (demand === 5) return pending === 3 ? "Pick three" : `Pick ${pending}`;
  return "Draw";
}

function SuitMark({ shape, size }: { shape: Shape; size: number }) {
  const color = SUIT[shape];
  if (shape === "circle") {
    return (
      <svg width={size} height={size} viewBox="0 0 40 40" aria-hidden>
        <circle cx="20" cy="20" r="14" fill="none" stroke={color} strokeWidth="5" />
      </svg>
    );
  }
  if (shape === "triangle") {
    return (
      <svg width={size} height={size} viewBox="0 0 40 40" aria-hidden>
        <polygon points="20,5 36,34 4,34" fill="none" stroke={color} strokeWidth="4" />
      </svg>
    );
  }
  if (shape === "cross") {
    return (
      <svg width={size} height={size} viewBox="0 0 40 40" aria-hidden>
        <rect x="16" y="4" width="8" height="32" rx="2" fill={color} />
        <rect x="4" y="16" width="32" height="8" rx="2" fill={color} />
      </svg>
    );
  }
  if (shape === "square") {
    return (
      <svg width={size} height={size} viewBox="0 0 40 40" aria-hidden>
        <rect x="7" y="7" width="26" height="26" fill="none" stroke={color} strokeWidth="4" />
      </svg>
    );
  }
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" aria-hidden>
      <polygon points="20,3 25,15 38,15 27,23 31,36 20,28 9,36 13,23 2,15 15,15" fill={color} />
    </svg>
  );
}

function CardView({ card, faceDown }: { card: { id?: string; shape: Shape; n: number }; faceDown?: boolean }) {
  if (faceDown || card.id?.startsWith("hid-") || card.id?.startsWith("pile-")) {
    return (
      <span className="grid h-24 w-16 place-items-center rounded-lg border-2 border-[#0b3d38] bg-[#128f8a] text-center text-[11px] font-black tracking-wide text-white shadow">
        WHOT
      </span>
    );
  }
  const color = SUIT[card.shape];
  const special = card.shape === "whot" ? "WHOT" : card.n === 1 ? "Hold" : card.n === 2 ? "Pick 2" : card.n === 5 ? "Pick 3" : card.n === 8 ? "Hold" : card.n === 14 ? "Market" : "";
  return (
    <span className="relative grid h-28 w-[4.6rem] place-items-center rounded-lg border border-[#d7d0c8] bg-white shadow">
      <span className="absolute left-1 top-0.5 text-xs font-black" style={{ color }}>
        {card.shape === "whot" ? 20 : card.n}
      </span>
      <SuitMark shape={card.shape} size={card.shape === "whot" ? 28 : 36} />
      {card.shape === "whot" ? <span className="font-display text-sm font-black" style={{ color }}>WHOT</span> : null}
      {special && card.shape !== "whot" ? (
        <span className="absolute bottom-1 text-[9px] font-bold uppercase" style={{ color }}>
          {special}
        </span>
      ) : null}
      <span className="absolute bottom-0.5 right-1 rotate-180 text-xs font-black" style={{ color }}>
        {card.shape === "whot" ? 20 : card.n}
      </span>
    </span>
  );
}

export function SnakesTable({
  state,
  me,
  names,
  onRoll,
}: {
  state: SnakesState;
  me: string;
  names: Record<string, string>;
  onRoll: () => void;
}) {
  const mine = state.seats[state.turn] === me && state.winner === null;
  return (
    <div className="flex h-full w-full gap-3 px-3 pb-3 pt-14">
      <Side>
        {state.seats.map((id, i) => (
          <Seat key={id + i} name={names[id] ?? "Player"} active={state.turn === i} detail={`Square ${state.pos[i]}`} />
        ))}
      </Side>
      <div className="grid min-w-0 flex-1 place-items-center">
        <SnakeCanvas state={state} />
      </div>
      <Side>
        <p className="text-sm">{state.log}</p>
        <button
          type="button"
          disabled={!mine}
          onClick={onRoll}
          className="min-h-16 rounded-2xl bg-pink font-display text-xl font-extrabold text-ink disabled:opacity-40"
        >
          {state.dice ? `Dice ${state.dice}` : "Roll"}
        </button>
      </Side>
    </div>
  );
}

function SnakeCanvas({ state }: { state: SnakesState }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const size = Math.min(canvas.clientWidth, canvas.clientHeight);
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    canvas.width = Math.floor(size * dpr);
    canvas.height = Math.floor(size * dpr);
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const cell = size / 10;
    ctx.fillStyle = "#121018";
    ctx.fillRect(0, 0, size, size);
    for (let n = 1; n <= 100; n++) {
      const { x, y } = center(n, cell);
      const row = Math.floor((n - 1) / 10);
      ctx.fillStyle = row % 2 === 0 ? "#1c1724" : "#241828";
      ctx.fillRect(x - cell / 2 + 1, y - cell / 2 + 1, cell - 2, cell - 2);
      ctx.fillStyle = "#a398ad";
      ctx.font = `${Math.max(9, cell * 0.22)}px sans-serif`;
      ctx.fillText(String(n), x - cell / 2 + 3, y - cell / 2 + 12);
    }
    ctx.strokeStyle = "#f5c16c";
    ctx.lineWidth = 3;
    for (const [from, to] of Object.entries(LADDERS)) {
      const a = center(Number(from), cell);
      const b = center(to, cell);
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
    }
    ctx.strokeStyle = "#ff2d8a";
    for (const [from, to] of Object.entries(SNAKES)) {
      const a = center(Number(from), cell);
      const b = center(to, cell);
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
    }
    const colors = ["#ff2d8a", "#f5c16c", "#3dffb0", "#f6f2f8"];
    state.pos.forEach((pos, i) => {
      if (pos <= 0) return;
      const c = center(pos, cell);
      ctx.fillStyle = colors[i % colors.length];
      ctx.beginPath();
      ctx.arc(c.x + i * 3 - 4, c.y, cell * 0.18, 0, Math.PI * 2);
      ctx.fill();
    });
  }, [state]);
  return <canvas ref={ref} className="h-full max-h-full w-full" />;
}

function center(n: number, cell: number) {
  const i = n - 1;
  const row = Math.floor(i / 10);
  const colIn = i % 10;
  const col = row % 2 === 0 ? colIn : 9 - colIn;
  return { x: (col + 0.5) * cell, y: (9 - row + 0.5) * cell };
}

export function ZonoTable({
  state,
  me,
  names,
  onAct,
}: {
  state: ZonoState;
  me: string;
  names: Record<string, string>;
  onAct: (type: "roll" | "buy" | "pass" | "upgrade" | "end") => void;
}) {
  const seat = Math.max(0, state.seats.indexOf(me));
  const mine = state.seats[state.turn] === me && state.phase !== "done";
  const tile = TILES[state.pos[state.turn]];
  return (
    <div className="flex h-full w-full gap-3 px-3 pb-3 pt-14">
      <Side>
        {state.seats.map((id, i) => (
          <Seat
            key={id + i}
            name={names[id] ?? "Player"}
            active={state.turn === i}
            detail={state.out[i] ? "Out" : `${state.money[i]} · tile ${state.pos[i]}`}
          />
        ))}
      </Side>
      <div className="flex min-w-0 flex-1 flex-col justify-center gap-3">
        <p className="font-display text-3xl font-extrabold">{tile?.name}</p>
        <p className="text-sm text-muted">{state.log}</p>
        <div className="flex flex-wrap gap-1">
          {TILES.map((item, i) => (
            <span
              key={item.name + i}
              className={`rounded-lg px-2 py-1 text-xs ${state.pos[state.turn] === i ? "bg-pink text-ink" : "bg-panel text-muted"}`}
            >
              {i}
              {state.owner[i] !== null ? " •" : ""}
            </span>
          ))}
        </div>
        <p className="text-sm">
          You have {state.money[seat]}.{" "}
          {tile?.kind === "city" && state.owner[state.pos[state.turn]] !== null
            ? `Rent ${rentOf(state, state.pos[state.turn])}.`
            : null}
        </p>
      </div>
      <Side>
        <button type="button" disabled={!mine || state.phase !== "roll"} onClick={() => onAct("roll")} className="min-h-14 rounded-xl bg-pink font-bold text-ink disabled:opacity-40">
          Roll {state.dice[0] ? `${state.dice[0]}+${state.dice[1]}` : ""}
        </button>
        <button type="button" disabled={!mine || state.phase !== "buy"} onClick={() => onAct("buy")} className="min-h-11 rounded-xl border border-line disabled:opacity-40">
          Buy / upgrade
        </button>
        <button type="button" disabled={!mine || state.phase !== "buy"} onClick={() => onAct("pass")} className="min-h-11 rounded-xl border border-line disabled:opacity-40">
          Pass
        </button>
        <button type="button" disabled={!mine || state.phase !== "end"} onClick={() => onAct("end")} className="min-h-11 rounded-xl border border-pink text-pink disabled:opacity-40">
          End turn
        </button>
      </Side>
    </div>
  );
}
