import { useEffect, useRef, useState } from "react";
import { FootballGame, ShooterGame, type ActionResult, type DuelLink } from "@/components/games/action";
import { saveActionResult, getRoom, type RoomView } from "@/lib/sambn/api";
import { createArena, type Arena } from "@/lib/games/arena";
import { freshPad, type Pad } from "@/lib/games/pad";
import { createPitch, type Pitch } from "@/lib/games/pitch";
import { useP2PRoom } from "@/lib/multiplayer/use-p2p-room";
import { errText } from "@/components/ui";

export function DuelMatch({ slug, code, userId }: { slug: "football" | "shooter"; code: string; userId: string }) {
  const [room, setRoom] = useState<RoomView | null>(null);
  const [error, setError] = useState("");
  const sawPair = useRef(false);

  useEffect(() => {
    let cancel = false;
    const tick = () => {
      getRoom({ data: { code } })
        .then((next) => {
          if (!cancel) setRoom(next);
        })
        .catch((err) => {
          if (!cancel) setError(errText(err));
        });
    };
    tick();
    const id = window.setInterval(tick, 1200);
    return () => {
      cancel = true;
      window.clearInterval(id);
    };
  }, [code]);

  if (!room) return <p className="grid h-full place-items-center text-muted">{error || "Opening the match…"}</p>;
  if (room.status !== "live") {
    return (
      <div className="grid h-full place-items-center px-6 text-center">
        <div>
          <p>This room is still in the lobby.</p>
          <a href={`/room/${code}`} className="mt-3 inline-block text-pink">
            Back to the room
          </a>
        </div>
      </div>
    );
  }
  const me = room.members.find((member) => member.userId === userId);
  if (!me) {
    return (
      <div className="grid h-full place-items-center px-6 text-center">
        <p>Join this room from the lobby before the match starts.</p>
      </div>
    );
  }
  if (room.members.length >= 2) sawPair.current = true;
  if (sawPair.current && room.members.length < 2) {
    return (
      <div className="grid h-full place-items-center px-6 text-center">
        <div>
          <p>The other player left. This match was not handed to a computer.</p>
          <a href={`/room/${code}`} className="mt-3 inline-block text-pink">
            Back to the room
          </a>
        </div>
      </div>
    );
  }
  if (room.members.length < 2) {
    return <p className="grid h-full place-items-center">Waiting for the other player…</p>;
  }
  const opponent = room.members.find((member) => member.userId !== userId);
  return (
    <DuelMesh
      key={`${code}-${userId}`}
      slug={slug}
      code={code}
      role={room.hostId === userId ? "host" : "guest"}
      myName={me.displayName}
      opponent={opponent?.displayName ?? "Opponent"}
    />
  );
}

function DuelMesh({
  slug,
  code,
  role,
  myName,
  opponent,
}: {
  slug: "football" | "shooter";
  code: string;
  role: "host" | "guest";
  myName: string;
  opponent: string;
}) {
  const p2p = useP2PRoom({ room: `m${code}`, name: myName });
  const remotePad = useRef<Pad>(freshPad());
  const localPad = useRef<Pad>(freshPad());
  const pitch = useRef<Pitch | null>(createPitch());
  const arena = useRef<Arena | null>(createArena());
  const [note, setNote] = useState("");
  const connected = p2p.peers.some((peer) => peer.connectionState === "connected");
  const failed = p2p.joined && !connected && p2p.peers.some((peer) => peer.connectionState === "failed");

  useEffect(() => {
    return p2p.onMessage((_from, data) => {
      if (!data || typeof data !== "object") return;
      const msg = data as { kind?: string; pad?: Pad; pitch?: Pitch; arena?: Arena };
      if (msg.kind === "pad" && msg.pad) remotePad.current = msg.pad;
      if (msg.kind === "pitch" && msg.pitch) pitch.current = msg.pitch;
      if (msg.kind === "arena" && msg.arena) arena.current = msg.arena;
    });
  }, [p2p.onMessage]);

  useEffect(() => {
    let timer = 0;
    const tick = () => {
      if (role === "host") {
        if (slug === "football" && pitch.current) p2p.broadcast({ kind: "pitch", pitch: pitch.current });
        if (slug === "shooter" && arena.current) p2p.broadcast({ kind: "arena", arena: arena.current });
      } else {
        p2p.broadcast({ kind: "pad", pad: localPad.current });
      }
      timer = window.setTimeout(tick, 50);
    };
    timer = window.setTimeout(tick, 50);
    return () => window.clearTimeout(timer);
  }, [p2p.broadcast, role, slug]);

  const link: DuelLink = {
    role,
    opponent,
    connected,
    failed,
    remotePad,
    localPad,
    pitch,
    arena,
  };

  async function finish(result: ActionResult) {
    try {
      await saveActionResult({
        data: {
          id: crypto.randomUUID(),
          slug,
          result: result.result,
          detail: result.detail,
          opponent,
          score: result.score,
          code,
        },
      });
      setNote("Saved to your match history.");
    } catch (error) {
      setNote(errText(error));
    }
  }

  return (
    <div className="relative h-full">
      {note ? <p className="absolute bottom-2 left-3 z-10 text-xs text-muted">{note}</p> : null}
      {slug === "football" ? <FootballGame link={link} onResult={(result) => void finish(result)} /> : <ShooterGame link={link} onResult={(result) => void finish(result)} />}
    </div>
  );
}
