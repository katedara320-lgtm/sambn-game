import { useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { gameBySlug } from "@/lib/sambn/catalog";
import { joinRoom, listOpenRooms, type OpenRoom } from "@/lib/sambn/api";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { errText } from "@/components/ui";

export function OpenRooms({ slug }: { slug?: string }) {
  const navigate = useNavigate();
  const { user, isPending } = useCurrentUserState();
  const [rooms, setRooms] = useState<OpenRoom[] | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState("");

  useEffect(() => {
    if (!user) return;
    let cancel = false;
    const tick = () => {
      listOpenRooms({ data: { slug: slug ?? "" } })
        .then((rows) => {
          if (!cancel) setRooms(rows);
        })
        .catch((err) => {
          if (!cancel) setError(errText(err));
        });
    };
    tick();
    const id = window.setInterval(tick, 4000);
    return () => {
      cancel = true;
      window.clearInterval(id);
    };
  }, [user?.id, slug]);

  if (!user) return <p className="text-sm text-muted">Sign in to see public rooms.</p>;
  if (!rooms) return <p className="text-sm text-muted">{error || "Looking for open rooms…"}</p>;
  if (!rooms.length) return <p className="text-sm text-muted">No public rooms waiting. Host one and it will show up here.</p>;

  return (
    <ul className="space-y-2">
      {rooms.map((room) => {
        const game = gameBySlug(room.gameSlug);
        const full = room.players >= room.maxPlayers;
        return (
          <li key={room.code} className="flex items-center gap-3 rounded-2xl border border-line bg-ink px-3 py-3">
            <div className="min-w-0 flex-1">
              <p className="truncate font-bold">{game?.name ?? room.gameSlug}</p>
              <p className="text-xs text-muted">
                {room.hostName} · {room.players}/{room.maxPlayers} · {room.code}
              </p>
            </div>
            <button
              type="button"
              disabled={full || busy === room.code || isPending}
              className="min-h-11 rounded-xl bg-pink px-4 text-sm font-bold text-ink disabled:opacity-40"
              onClick={() => {
                setBusy(room.code);
                setError("");
                void joinRoom({ data: { code: room.code } })
                  .then((res) => navigate({ to: "/room/$code", params: { code: res.code } }))
                  .catch((err) => {
                    setError(errText(err));
                    setBusy("");
                  });
              }}
            >
              {full ? "Full" : busy === room.code ? "Joining…" : "Join"}
            </button>
          </li>
        );
      })}
      {error ? <p className="text-sm text-pink-2">{error}</p> : null}
    </ul>
  );
}
