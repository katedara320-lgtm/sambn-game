import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { GAMES, gameBySlug, isRealtimeDuel } from "@/lib/sambn/catalog";
import { createRoom } from "@/lib/sambn/api";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { errText } from "@/components/ui";

export function HostGame({ initialSlug }: { initialSlug?: string }) {
  const navigate = useNavigate();
  const { user, isPending } = useCurrentUserState();
  const choices = GAMES.filter((game) => game.slug !== "adventure");
  const [slug, setSlug] = useState(initialSlug && gameBySlug(initialSlug) ? initialSlug : "football");
  const game = gameBySlug(slug) ?? choices[0];
  const [seats, setSeats] = useState(game.max);
  const [fillAi, setFillAi] = useState(false);
  const [listed, setListed] = useState(true);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const duel = isRealtimeDuel(game.slug);
  const table = game.slug === "snooker";
  const turn = game.mode === "turn" || table;
  const seatCount = duel || table ? 2 : Math.min(game.max, Math.max(game.min, seats));

  function pick(next: string) {
    const found = gameBySlug(next);
    setSlug(next);
    if (found) setSeats(isRealtimeDuel(found.slug) ? 2 : found.max);
    setFillAi(false);
  }

  async function host() {
    if (isPending) return;
    if (!user) {
      void navigate({ to: "/login", search: { redirect: "/games" } });
      return;
    }
    setBusy(true);
    setError("");
    try {
      const room = await createRoom({ data: { slug: game.slug, seats: seatCount, fillAi: turn && !duel && fillAi, listed } });
      void navigate({ to: "/room/$code", params: { code: room.code } });
    } catch (err) {
      setError(errText(err));
      setBusy(false);
    }
  }

  return (
    <div className="space-y-3 rounded-3xl border border-line bg-panel p-4">
      <p className="font-display text-xl font-extrabold">Host a room</p>
      <label className="block text-sm text-muted">
        Game
        <select
          value={game.slug}
          onChange={(event) => pick(event.target.value)}
          className="mt-1 min-h-11 w-full rounded-xl border border-line bg-ink px-3 text-fg"
        >
          {choices.map((item) => (
            <option key={item.slug} value={item.slug}>
              {item.name}
            </option>
          ))}
        </select>
      </label>
      {duel ? (
        <p className="text-sm text-muted">2 players. Your friend joins with the room code and controls the other side. The computer is not in this room.</p>
      ) : turn ? (
        <div className="space-y-2">
          <label className="block text-sm text-muted">
            Players
            <select
              value={seatCount}
              onChange={(event) => setSeats(Number(event.target.value))}
              className="mt-1 min-h-11 w-full rounded-xl border border-line bg-ink px-3 text-fg"
            >
              {Array.from({ length: game.max - game.min + 1 }, (_, index) => game.min + index).map((n) => (
                <option key={n} value={n}>
                  {n} players
                </option>
              ))}
            </select>
          </label>
          <label className="flex items-start gap-2 text-sm">
            <input type="checkbox" checked={fillAi} onChange={(event) => setFillAi(event.target.checked)} className="mt-1" />
            <span>Let the computer fill empty seats. Those seats are labeled Computer, not as people.</span>
          </label>
        </div>
      ) : table ? (
        <div className="space-y-2">
          <p className="text-sm text-muted">2 players. Both phones play the same frame. Shots are checked on the server.</p>
          <label className="flex items-start gap-2 text-sm">
            <input type="checkbox" checked={fillAi} onChange={(event) => setFillAi(event.target.checked)} className="mt-1" />
            <span>Play the computer instead of waiting for a person. The seat is labeled Computer.</span>
          </label>
        </div>
      ) : (
        <p className="text-sm text-muted">
          {game.name} is still one screen each. A room compares scores. It does not put two phones on the same table.
        </p>
      )}
      {error ? <p className="text-sm text-pink-2">{error}</p> : null}
      <label className="flex items-start gap-2 text-sm">
        <input type="checkbox" checked={listed} onChange={(event) => setListed(event.target.checked)} className="mt-1" />
        <span>Show this room in Play Online so people can join without a code. Turn it off for a private code.</span>
      </label>
      <button type="button" disabled={busy} onClick={() => void host()} className="min-h-11 rounded-xl bg-pink px-4 font-bold text-ink disabled:opacity-50">
        {busy ? "Creating…" : "Create room"}
      </button>
    </div>
  );
}
