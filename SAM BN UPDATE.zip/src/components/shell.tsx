import { Link, useRouterState } from "@tanstack/react-router";
import { Bell, Gamepad2, Home, MessageCircle, Newspaper, Search, User, Users, Volume2, VolumeX } from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { getAlerts, type Profile } from "@/lib/sambn/api";
import { Avatar } from "@/components/ui";
import { audioPrefs, setAudioPrefs, sfx, unlockAudio } from "@/lib/audio";

const NAV = [
  { to: "/", label: "Home", icon: Home },
  { to: "/games", label: "Games", icon: Gamepad2 },
  { to: "/friends", label: "Friends", icon: Users },
  { to: "/chat", label: "Chat", icon: MessageCircle },
  { to: "/community", label: "Community", icon: Newspaper },
  { to: "/profile", label: "Profile", icon: User },
] as const;

function active(path: string, to: string) {
  if (to === "/") return path === "/";
  return path === to || path.startsWith(`${to}/`);
}

export function Shell({ children }: { children: ReactNode }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const { user, isPending } = useCurrentUserState();
  const [me, setMe] = useState<Profile | null>(null);
  const [online, setOnline] = useState<number | null>(null);
  const [unread, setUnread] = useState(0);
  const [requests, setRequests] = useState(0);
  const [muted, setMuted] = useState(false);

  useEffect(() => {
    setMuted(audioPrefs().muted);
    const unlock = () => unlockAudio();
    const click = (event: Event) => {
      const target = event.target as HTMLElement | null;
      if (target?.closest("button, a")) sfx("click");
    };
    window.addEventListener("pointerdown", unlock);
    window.addEventListener("click", click);
    return () => {
      window.removeEventListener("pointerdown", unlock);
      window.removeEventListener("click", click);
    };
  }, []);

  useEffect(() => {
    if (isPending || !user) {
      setMe(null);
      return;
    }
    let cancel = false;
    const tick = () => {
      getAlerts({ data: { displayName: user.displayName ?? "" } })
        .then((alerts) => {
          if (cancel) return;
          setMe(alerts.me);
          setOnline(alerts.online);
          setUnread(alerts.unread);
          setRequests(alerts.requests);
        })
        .catch(() => undefined);
    };
    tick();
    const id = window.setInterval(tick, 20000);
    return () => {
      cancel = true;
      window.clearInterval(id);
    };
  }, [isPending, user?.id, user?.displayName]);

  return (
    <div className="min-h-dvh bg-ink text-fg">
      <header className="sticky top-0 z-30 border-b border-line bg-ink/90 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center gap-3 px-3 py-3">
          <Link to="/" className="flex items-center gap-2">
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-pink text-ink">
              <Gamepad2 className="h-5 w-5" />
            </span>
            <span className="leading-tight">
              <span className="block font-display text-lg font-extrabold tracking-wide">
                SAM <span className="text-pink">BN</span>
              </span>
              <span className="block text-xs font-semibold uppercase tracking-widest text-gold">Africa's Finest</span>
            </span>
          </Link>
          <form action="/games" className="mx-auto hidden max-w-md flex-1 lg:block">
            <label className="relative block">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
              <input
                name="q"
                placeholder="Search games"
                className="w-full rounded-full border border-line bg-panel py-2.5 pl-10 pr-3 text-sm outline-none ring-pink focus:ring-2"
              />
            </label>
          </form>
          <div className="ml-auto flex items-center gap-2">
            <button
              type="button"
              aria-label={muted ? "Unmute" : "Mute"}
              className="grid h-11 w-11 place-items-center rounded-full border border-line bg-panel"
              onClick={() => {
                const next = !audioPrefs().muted;
                setAudioPrefs({ muted: next });
                setMuted(next);
              }}
            >
              {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </button>
            <span className="hidden items-center gap-2 rounded-full border border-line bg-panel px-3 py-2 text-xs sm:flex">
              <span className="live-dot h-2 w-2 rounded-full bg-good" />
              <span className="text-muted">Online</span>
              <span className="font-bold">{online ?? "—"}</span>
            </span>
            <Link to="/friends" className="relative grid h-11 w-11 place-items-center rounded-full border border-line bg-panel" aria-label="Alerts">
              <Bell className="h-4 w-4" />
              {requests + unread > 0 ? (
                <span className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-pink px-1 text-xs font-bold text-ink">
                  {requests + unread}
                </span>
              ) : null}
            </Link>
            {isPending ? <span className="h-11 w-11 animate-pulse rounded-full bg-panel-2" /> : null}
            {!isPending && user && me ? (
              <Link to="/profile" className="flex items-center gap-2 rounded-full border border-line bg-panel py-1 pl-1 pr-3">
                <Avatar name={me.displayName} hue={me.avatarHue} size="sm" online />
                <span className="hidden text-sm font-semibold sm:block">{me.displayName}</span>
              </Link>
            ) : null}
            {!isPending && !user ? (
              <Link to="/login" className="rounded-full bg-pink px-4 py-2.5 text-sm font-bold text-ink">
                Sign in
              </Link>
            ) : null}
          </div>
        </div>
      </header>
      <div className="mx-auto grid max-w-7xl lg:grid-cols-[220px_minmax(0,1fr)]">
        <aside className="hidden px-3 py-4 lg:block">
          <nav className="space-y-1">
            {NAV.map((item) => {
              const Icon = item.icon;
              const on = active(path, item.to);
              const badge = item.to === "/chat" ? unread : item.to === "/friends" ? requests : 0;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={`flex min-h-11 items-center gap-3 rounded-xl px-3 py-2 text-sm font-semibold ${on ? "bg-pink text-ink" : "text-fg hover:bg-panel"}`}
                >
                  <Icon className="h-4 w-4" />
                  {item.label}
                  {badge > 0 ? <span className="ml-auto rounded-full bg-ink px-2 text-xs text-pink">{badge}</span> : null}
                </Link>
              );
            })}
          </nav>
          <div className="mt-4 overflow-hidden rounded-2xl border border-pink bg-pink-dim p-4">
            <p className="font-display text-lg font-bold">Play together. Win together.</p>
            <p className="mt-1 text-sm text-muted">Rooms, friends, and a feed that remembers the match.</p>
          </div>
        </aside>
        <div className="min-w-0 px-3 py-4 pb-28 lg:pb-8">{children}</div>
      </div>
      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-panel/95 backdrop-blur lg:hidden">
        <div className="grid grid-cols-6">
          {NAV.map((item) => {
            const Icon = item.icon;
            const on = active(path, item.to);
            return (
              <Link key={item.to} to={item.to} className={`flex min-h-16 flex-col items-center justify-center gap-1 text-xs ${on ? "text-pink" : "text-muted"}`}>
                <Icon className="h-5 w-5" />
                {item.label === "Community" ? "Feed" : item.label}
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
