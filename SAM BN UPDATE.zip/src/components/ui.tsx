import { Link } from "@tanstack/react-router";
import { formatDistanceToNow } from "date-fns";
import type { ReactNode } from "react";
import { gameBySlug, type GameInfo } from "@/lib/sambn/catalog";

export function ago(iso: string): string {
  const t = new Date(iso).getTime();
  if (!Number.isFinite(t)) return "";
  return formatDistanceToNow(t, { addSuffix: true });
}

export function errText(error: unknown): string {
  if (error instanceof Error && error.message) return error.message;
  return "Something went wrong.";
}

export function Avatar({
  name,
  hue,
  online,
  size = "md",
}: {
  name: string;
  hue: number;
  online?: boolean;
  size?: "sm" | "md" | "lg";
}) {
  const dim = size === "sm" ? "h-9 w-9 text-xs" : size === "lg" ? "h-16 w-16 text-xl" : "h-11 w-11 text-sm";
  return (
    <span className="relative inline-grid shrink-0">
      <span className={`grid place-items-center rounded-full bg-pink p-0.5 ${size === "lg" ? "h-[4.4rem] w-[4.4rem]" : size === "sm" ? "h-10 w-10" : "h-12 w-12"}`}>
        <span
          className={`grid place-items-center rounded-full font-display font-bold text-fg ${dim}`}
          style={{ background: `hsl(${hue} 62% 38%)` }}
        >
          {(name || "?").slice(0, 1).toUpperCase()}
        </span>
      </span>
      {online ? (
        <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-ink bg-good" />
      ) : null}
    </span>
  );
}

export function GameCard({ game }: { game: GameInfo }) {
  return (
    <Link
      to="/games/$slug"
      params={{ slug: game.slug }}
      className="group block overflow-hidden rounded-2xl border border-line bg-panel transition duration-200 hover:-translate-y-0.5 hover:border-pink"
    >
      <span className="relative block aspect-video overflow-hidden">
        <img src={game.image} alt="" className="h-full w-full object-cover transition duration-300 group-hover:scale-105" />
        <span className="absolute left-2 top-2 rounded-full bg-ink/80 px-2 py-1 text-xs font-semibold text-pink">{game.tag}</span>
      </span>
      <span className="flex items-center justify-between gap-2 px-3 py-3">
        <span>
          <span className="block font-display text-base font-bold">{game.name}</span>
          <span className="block text-xs text-muted">{game.players}</span>
        </span>
        <span className="grid h-9 w-9 place-items-center rounded-full bg-pink text-sm font-bold text-ink">→</span>
      </span>
    </Link>
  );
}

export function ScoreCard({ slug, label }: { slug: string | null; label: string | null }) {
  if (!slug && !label) return null;
  const game = slug ? gameBySlug(slug) : undefined;
  return (
    <span className="mt-3 flex items-center gap-3 overflow-hidden rounded-xl border border-line bg-ink">
      {game ? <img src={game.image} alt="" className="h-16 w-24 object-cover" /> : null}
      <span>
        <span className="block text-xs uppercase tracking-widest text-pink">{game?.name ?? "Result"}</span>
        <span className="block font-display text-lg font-bold">{label || "Shared a match"}</span>
      </span>
    </span>
  );
}

export function Panel({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <section className={`rounded-2xl border border-line bg-panel ${className}`}>{children}</section>;
}

export function Field({
  label,
  value,
  onChange,
  type = "text",
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
  placeholder?: string;
}) {
  return (
    <label className="block space-y-1.5 text-sm">
      <span className="text-muted">{label}</span>
      <input
        type={type}
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-xl border border-line bg-ink px-3 py-3 text-fg outline-none ring-pink focus:ring-2"
      />
    </label>
  );
}

export function PrimaryButton({
  children,
  onClick,
  type = "button",
  disabled,
}: {
  children: ReactNode;
  onClick?: () => void;
  type?: "button" | "submit";
  disabled?: boolean;
}) {
  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-pink px-4 py-3 font-display text-sm font-bold text-ink disabled:opacity-50"
    >
      {children}
    </button>
  );
}

export function GhostButton({
  children,
  onClick,
  type = "button",
  disabled,
}: {
  children: ReactNode;
  onClick?: () => void;
  type?: "button" | "submit";
  disabled?: boolean;
}) {
  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-line bg-panel-2 px-4 py-3 text-sm font-semibold text-fg disabled:opacity-50"
    >
      {children}
    </button>
  );
}
