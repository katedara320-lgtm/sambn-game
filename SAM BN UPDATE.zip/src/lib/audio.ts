/** Original tones from the Web Audio API. No recorded assets, so nothing here is copied audio. */

export type Sfx =
  | "click"
  | "error"
  | "join"
  | "start"
  | "win"
  | "lose"
  | "draw"
  | "dice"
  | "card"
  | "pocket"
  | "cushion"
  | "cue"
  | "collide"
  | "goal"
  | "kick"
  | "crash"
  | "finish";

type Prefs = { muted: boolean; sfx: number; music: number };

const KEY = "sambn-audio";
const DEFAULTS: Prefs = { muted: false, sfx: 0.7, music: 0 };

let ctx: AudioContext | null = null;
let prefs: Prefs = load();
let musicNodes: { osc: OscillatorNode; gain: GainNode } | null = null;
let engine: { osc: OscillatorNode; gain: GainNode } | null = null;
const last = new Map<string, number>();

function load(): Prefs {
  if (typeof localStorage === "undefined") return { ...DEFAULTS };
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) || "");
    return {
      muted: Boolean(raw.muted),
      sfx: clamp(Number(raw.sfx), 0, 1, DEFAULTS.sfx),
      music: clamp(Number(raw.music), 0, 1, DEFAULTS.music),
    };
  } catch {
    return { ...DEFAULTS };
  }
}

function clamp(n: number, a: number, b: number, fallback: number) {
  if (!Number.isFinite(n)) return fallback;
  return Math.max(a, Math.min(b, n));
}

export function audioPrefs(): Prefs {
  return { ...prefs };
}

export function setAudioPrefs(next: Partial<Prefs>) {
  prefs = {
    muted: next.muted ?? prefs.muted,
    sfx: next.sfx === undefined ? prefs.sfx : clamp(next.sfx, 0, 1, prefs.sfx),
    music: next.music === undefined ? prefs.music : clamp(next.music, 0, 1, prefs.music),
  };
  if (typeof localStorage !== "undefined") localStorage.setItem(KEY, JSON.stringify(prefs));
  syncMusic();
  if (prefs.muted || prefs.sfx === 0) setEngine(0);
}

export function unlockAudio() {
  const audio = context();
  if (!audio) return;
  if (audio.state === "suspended") void audio.resume();
  syncMusic();
}

function context() {
  if (typeof window === "undefined") return null;
  const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctx) return null;
  ctx ??= new Ctx();
  return ctx;
}

function syncMusic() {
  const audio = ctx;
  if (!audio) return;
  const on = !prefs.muted && prefs.music > 0.01 && audio.state === "running";
  if (!on) {
    musicNodes?.gain.gain.setTargetAtTime(0, audio.currentTime, 0.05);
    return;
  }
  if (!musicNodes) {
    const osc = audio.createOscillator();
    const gain = audio.createGain();
    osc.type = "triangle";
    osc.frequency.value = 98;
    gain.gain.value = 0;
    osc.connect(gain);
    gain.connect(audio.destination);
    osc.start();
    musicNodes = { osc, gain };
  }
  musicNodes.gain.gain.setTargetAtTime(prefs.music * 0.03, audio.currentTime, 0.08);
}

/** Looping engine tone for the race. Pass 0 to stop. Speed is 0–1. */
export function setEngine(speed: number) {
  const audio = ctx;
  if (!audio || prefs.muted || prefs.sfx === 0 || speed <= 0.02) {
    if (engine && audio) engine.gain.gain.setTargetAtTime(0, audio.currentTime, 0.05);
    return;
  }
  if (audio.state !== "running") return;
  if (!engine) {
    const osc = audio.createOscillator();
    const gain = audio.createGain();
    osc.type = "sawtooth";
    gain.gain.value = 0;
    osc.connect(gain);
    gain.connect(audio.destination);
    osc.start();
    engine = { osc, gain };
  }
  engine.osc.frequency.setTargetAtTime(70 + speed * 180, audio.currentTime, 0.05);
  engine.gain.gain.setTargetAtTime(prefs.sfx * 0.04, audio.currentTime, 0.05);
}

export function sfx(name: Sfx, amount = 1) {
  const audio = context();
  if (!audio || prefs.muted || prefs.sfx <= 0) return;
  const play = () => {
    if (audio.state !== "running") return;
    const now = audio.currentTime;
    const wall = performance.now();
    const gap = name === "collide" || name === "click" || name === "cushion" ? 70 : 40;
    if (wall - (last.get(name) ?? 0) < gap) return;
    last.set(name, wall);
    const master = audio.createGain();
    master.gain.value = prefs.sfx * Math.max(0.35, Math.min(1, amount));
    master.connect(audio.destination);
    tone(audio, master, now, name);
  };
  if (audio.state === "suspended") {
    void audio.resume().then(play);
    return;
  }
  play();
}

function noise(audio: AudioContext, master: GainNode, now: number, dur: number, vol: number, freq: number) {
  const len = Math.max(1, Math.floor(audio.sampleRate * dur));
  const buf = audio.createBuffer(1, len, audio.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < len; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / len);
  const src = audio.createBufferSource();
  src.buffer = buf;
  const filter = audio.createBiquadFilter();
  filter.type = "bandpass";
  filter.frequency.value = freq;
  filter.Q.value = 0.7;
  const gain = audio.createGain();
  gain.gain.setValueAtTime(vol, now);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + dur);
  src.connect(filter);
  filter.connect(gain);
  gain.connect(master);
  src.start(now);
  src.stop(now + dur + 0.02);
}
function tone(audio: AudioContext, master: GainNode, now: number, name: Sfx) {
  const beep = (freq: number, at: number, dur: number, type: OscillatorType, vol: number) => {
    const osc = audio.createOscillator();
    const gain = audio.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now + at);
    gain.gain.setValueAtTime(0.0001, now + at);
    gain.gain.exponentialRampToValueAtTime(vol, now + at + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + at + dur);
    osc.connect(gain);
    gain.connect(master);
    osc.start(now + at);
    osc.stop(now + at + dur + 0.02);
  };
  if (name === "click") beep(520, 0, 0.05, "square", 0.05);
  else if (name === "error") beep(180, 0, 0.12, "sawtooth", 0.06);
  else if (name === "join") beep(440, 0, 0.08, "triangle", 0.06);
  else if (name === "start") {
    beep(523, 0, 0.1, "square", 0.06);
    beep(659, 0.12, 0.12, "square", 0.06);
  }
  else if (name === "win") {
    beep(523, 0, 0.1, "triangle", 0.07);
    beep(659, 0.1, 0.1, "triangle", 0.07);
    beep(784, 0.2, 0.18, "triangle", 0.07);
  }
  else if (name === "lose") beep(196, 0, 0.22, "sawtooth", 0.05);
  else if (name === "draw") beep(392, 0, 0.12, "triangle", 0.05);
  else if (name === "dice") {
    beep(300, 0, 0.04, "square", 0.04);
    beep(420, 0.05, 0.04, "square", 0.04);
    beep(360, 0.1, 0.05, "square", 0.04);
  }
  else if (name === "card") beep(880, 0, 0.06, "triangle", 0.05);
  else if (name === "pocket") {
    noise(audio, master, now, 0.12, 0.2, 180);
    beep(220, 0.02, 0.14, "sine", 0.12);
  }
  else if (name === "cushion") noise(audio, master, now, 0.05, 0.16, 240);
  else if (name === "cue") {
    noise(audio, master, now, 0.06, 0.28, 140);
    beep(110, 0, 0.05, "triangle", 0.14);
  }
  else if (name === "collide") noise(audio, master, now, 0.04, 0.22, 900);
  else if (name === "goal") {
    beep(494, 0, 0.1, "square", 0.07);
    beep(659, 0.1, 0.16, "square", 0.07);
  }
  else if (name === "kick") beep(180, 0, 0.06, "sine", 0.06);
  else if (name === "crash") beep(90, 0, 0.16, "sawtooth", 0.08);
  else if (name === "finish") beep(784, 0, 0.2, "triangle", 0.07);
}
