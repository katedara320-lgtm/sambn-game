export type GameMode = "action" | "turn";

export type GameInfo = {
  slug: string;
  name: string;
  tag: string;
  players: string;
  mode: GameMode;
  blurb: string;
  honest: string;
  max: number;
  min: number;
  image: string;
};

export const GAMES: GameInfo[] = [
  {
    slug: "snooker",
    name: "8-Ball",
    tag: "Table",
    players: "Practice, computer, or 2 online",
    mode: "action",
    blurb: "Solids, stripes, and the 8-ball.",
    honest:
      "Practice on your own table, play a labeled computer, or host a public room so another person takes the other cue. Both phones see the same balls, groups, and turn. You cannot shoot out of turn. Pocketing the 8-ball early loses. A private room stays off the list and needs the code.",
    max: 2,
    min: 2,
    image: "/art/snooker.jpg",
  },
  {
    slug: "football",
    name: "Football",
    tag: "Arcade",
    players: "1 vs player or computer",
    mode: "action",
    blurb: "Street pitch. First to three.",
    honest:
      "Play the computer on your own, or host a private room so a friend on another phone controls the other side of the same pitch. The computer is never added to a player match.",
    max: 4,
    min: 1,
    image: "/art/football.jpg",
  },
  {
    slug: "chess",
    name: "Chess",
    tag: "Board",
    players: "2",
    mode: "turn",
    blurb: "Slow hands. Sharp minds.",
    honest:
      "Full rules: castling, en passant, promotion to a queen, check, checkmate, stalemate, and draws. Play the computer, or open a room so a friend moves on the same board.",
    max: 2,
    min: 2,
    image: "/art/chess.jpg",
  },
  {
    slug: "whot",
    name: "Whot",
    tag: "Cards",
    players: "2–4",
    mode: "turn",
    blurb: "Match shape or number.",
    honest:
      "SAM BN Lagos table, not a copy of any branded app. Five suits — Circle, Triangle, Cross, Square, and Star — plus Whot 20. Match shape or number. 1 and 8 sit the next player out, 2 is pick two, 5 is pick three, 14 is general market, and only Whot 20 calls the next shape. Open the rules from the table. Rooms share one deck. The computer plays only if you ask for it.",
    max: 4,
    min: 2,
    image: "/art/whot.jpg",
  },
  {
    slug: "snakes",
    name: "Snakes & Ladders",
    tag: "Dice",
    players: "2–4",
    mode: "turn",
    blurb: "Climb fast. Slide carefully.",
    honest:
      "A shared 100-square board. You must roll the exact number to finish. Ladders climb, snakes slide. The computer can fill an empty seat, or friends take turns in a room.",
    max: 4,
    min: 2,
    image: "/art/snakes.jpg",
  },
  {
    slug: "zonopoly",
    name: "Zonopoly",
    tag: "Cities",
    players: "2–4",
    mode: "turn",
    blurb: "Own the continent.",
    honest:
      "An original city-trading game, not a copy of any boxed property set. Buy African cities, pay rent, upgrade once, and reach 2500 or outlast everyone. Rooms share one board.",
    max: 4,
    min: 2,
    image: "/art/zonopoly.jpg",
  },
  {
    slug: "zombie",
    name: "Zombie Survival",
    tag: "Arcade",
    players: "1",
    mode: "action",
    blurb: "Hold the alley.",
    honest:
      "Survive waves on your own. Left stick moves, right stick aims and fires. Your time and kills are saved. Friends in a room each run their own alley and post a score.",
    max: 4,
    min: 1,
    image: "/art/zombie.jpg",
  },
  {
    slug: "adventure",
    name: "Open World Adventure",
    tag: "Explore",
    players: "1",
    mode: "action",
    blurb: "Three relics. One elder.",
    honest:
      "A short savanna you can actually walk. Collect three relics and return to the elder. It is a small hand-made region, not an endless open world. Progress is saved when you finish.",
    max: 1,
    min: 1,
    image: "/art/adventure.svg",
  },
  {
    slug: "shooter",
    name: "1v1 Shooter",
    tag: "Arena",
    players: "1 vs player or computer",
    mode: "action",
    blurb: "One pit. Three stocks.",
    honest:
      "Play the computer, or host a private room and share the code. In a player match both phones share one pit: the host runs the arena and the guest's stick is applied live. A failed direct connection is shown — it is not replaced by a computer.",
    max: 4,
    min: 1,
    image: "/art/shooter.svg",
  },
];

export function gameBySlug(slug: string): GameInfo | undefined {
  return GAMES.find((g) => g.slug === slug);
}

export function isRealtimeDuel(slug: string): boolean {
  return slug === "football" || slug === "shooter";
}

export const TURN_SLUGS = new Set(GAMES.filter((g) => g.mode === "turn").map((g) => g.slug));
