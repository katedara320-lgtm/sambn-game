import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { gameBySlug } from "@/lib/sambn/catalog";
import {
  applyTurn,
  initialTurn,
  isTurnGame,
  matchResultFor,
  stepAi,
  turnSeat,
  type TurnState,
} from "@/lib/games/turn";

export type Profile = {
  userId: string;
  username: string;
  displayName: string;
  bio: string;
  avatarHue: number;
  level: number;
  xp: number;
  wins: number;
  losses: number;
  draws: number;
  lastSeen: string;
};

type ProfileRow = {
  user_id: string;
  username: string;
  display_name: string;
  bio: string;
  avatar_hue: number;
  level: number;
  xp: number;
  wins: number;
  losses: number;
  draws: number;
  last_seen: unknown;
};

function stamp(v: unknown): string {
  if (v instanceof Date) return v.toISOString();
  return String(v ?? "");
}

function mapProfile(r: ProfileRow): Profile {
  return {
    userId: r.user_id,
    username: r.username,
    displayName: r.display_name,
    bio: r.bio ?? "",
    avatarHue: Number(r.avatar_hue) || 330,
    level: Number(r.level) || 1,
    xp: Number(r.xp) || 0,
    wins: Number(r.wins) || 0,
    losses: Number(r.losses) || 0,
    draws: Number(r.draws) || 0,
    lastSeen: stamp(r.last_seen),
  };
}

function cleanName(value: string, max: number): string {
  return value.replace(/\s+/g, " ").trim().slice(0, max);
}

function usernameOf(seed: string): string {
  const base = seed.toLowerCase().replace(/[^a-z0-9_]/g, "").slice(0, 10) || "player";
  const suffix = Math.random().toString(36).slice(2, 6);
  return (base + suffix).slice(0, 16);
}

async function db() {
  const { getSql } = await import("@/lib/db");
  return getSql();
}

async function ensure(userId: string, hint: string): Promise<Profile> {
  const sql = await db();
  const existing = await sql<ProfileRow>`select * from profiles where user_id = ${userId}`;
  if (existing[0]) {
    await sql`update profiles set last_seen = now() where user_id = ${userId}`;
    return mapProfile(existing[0]);
  }
  const { getSessionUser } = await import("@/lib/auth/verify.server");
  const session = await getSessionUser();
  const email = session?.id === userId ? session.email : null;
  const display = cleanName(hint || email?.split("@")[0] || "Player", 24) || "Player";
  for (let i = 0; i < 6; i++) {
    const username = usernameOf(email?.split("@")[0] || display);
    const hue = Math.floor(Math.random() * 360);
    try {
      const rows = await sql<ProfileRow>`
        insert into profiles (user_id, username, display_name, avatar_hue)
        values (${userId}, ${username}, ${display}, ${hue})
        returning *`;
      return mapProfile(rows[0]);
    } catch (error) {
      const again = await sql<ProfileRow>`select * from profiles where user_id = ${userId}`;
      if (again[0]) return mapProfile(again[0]);
      if (i === 5) throw error;
    }
  }
  throw new Error("Could not create your profile.");
}

function pair(a: string, b: string): [string, string] {
  return a < b ? [a, b] : [b, a];
}

async function ensureRoomColumns(sql: Awaited<ReturnType<typeof db>>) {
  await sql`alter table rooms add column if not exists fill_ai boolean not null default false`;
  await sql`alter table rooms add column if not exists listed boolean not null default true`;
}

function hideHiddenCards(state: TurnState, userId: string): TurnState {
  if (state.game !== "whot") return state;
  const blank = (id: string): { id: string; shape: "circle"; n: number } => ({ id, shape: "circle", n: 0 });
  return {
    game: "whot",
    whot: {
      ...state.whot,
      hands: state.whot.hands.map((hand, index) =>
        state.whot.seats[index] === userId ? hand : hand.map((_, card) => blank(`hid-${index}-${card}`)),
      ),
      draw: state.whot.draw.map((_, index) => blank(`pile-${index}`)),
    },
  };
}

function roomCode(): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = crypto.getRandomValues(new Uint8Array(6));
  let out = "";
  for (const b of bytes) out += alphabet[b % alphabet.length];
  return out;
}

export type PublicPlayer = {
  userId: string;
  username: string;
  displayName: string;
  avatarHue: number;
  level: number;
  wins: number;
  losses: number;
  draws: number;
  lastSeen: string;
  online: boolean;
};

function mapPlayer(r: ProfileRow): PublicPlayer {
  const profile = mapProfile(r);
  const seen = new Date(profile.lastSeen).getTime();
  return {
    userId: profile.userId,
    username: profile.username,
    displayName: profile.displayName,
    avatarHue: profile.avatarHue,
    level: profile.level,
    wins: profile.wins,
    losses: profile.losses,
    draws: profile.draws,
    lastSeen: profile.lastSeen,
    online: Number.isFinite(seen) && Date.now() - seen < 90_000,
  };
}

export const getAlerts = createServerFn({ method: "POST" })
  .validator((input: { displayName?: string }) => ({
    displayName: cleanName(String(input?.displayName ?? ""), 24),
  }))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const me = await ensure(context.userId, data.displayName);
    const sql = await db();
    const onlineRows = await sql<{ n: number }>`
      select count(*) as n from profiles where last_seen > now() - interval '90 seconds'`;
    const unreadRows = await sql<{ n: number }>`
      select count(*) as n from direct_messages where recipient_id = ${context.userId} and read_at is null`;
    const requestRows = await sql<{ n: number }>`
      select count(*) as n from friendships
      where status = 'pending' and requested_by <> ${context.userId}
        and (user_a = ${context.userId} or user_b = ${context.userId})`;
    return {
      me,
      online: Number(onlineRows[0]?.n ?? 0),
      unread: Number(unreadRows[0]?.n ?? 0),
      requests: Number(requestRows[0]?.n ?? 0),
    };
  });

export const updateProfile = createServerFn({ method: "POST" })
  .validator((input: { username?: string; displayName?: string; bio?: string; avatarHue?: number }) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await db();
    const current = await ensure(context.userId, "");
    const username = (data.username ?? current.username).toLowerCase().trim();
    if (!/^[a-z0-9_]{3,16}$/.test(username)) {
      throw new Error("Usernames are 3–16 characters: letters, numbers, underscore.");
    }
    const displayName = cleanName(data.displayName ?? current.displayName, 24);
    if (displayName.length < 2) throw new Error("Display name is too short.");
    const bio = cleanName(data.bio ?? current.bio, 160);
    const avatarHue = Math.max(0, Math.min(359, Math.round(Number(data.avatarHue ?? current.avatarHue))));
    const clash = await sql<{ user_id: string }>`
      select user_id from profiles where username = ${username} and user_id <> ${context.userId}`;
    if (clash[0]) throw new Error("That username is taken.");
    const rows = await sql<ProfileRow>`
      update profiles
      set username = ${username}, display_name = ${displayName}, bio = ${bio}, avatar_hue = ${avatarHue}, last_seen = now()
      where user_id = ${context.userId}
      returning *`;
    return mapProfile(rows[0]);
  });

export const getHome = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const me = await ensure(context.userId, "");
    const sql = await db();
    const onlineRows = await sql<{ n: number }>`
      select count(*) as n from profiles where last_seen > now() - interval '90 seconds'`;
    const top = await sql<ProfileRow>`
      select * from profiles order by wins desc, level desc, username asc limit 5`;
    const mine = await sql<{ n: number }>`select count(*) as n from matches where user_id = ${context.userId}`;
    const today = await sql<{ n: number }>`
      select count(*) as n from matches where played_at > now() - interval '1 day'`;
    return {
      me,
      online: Number(onlineRows[0]?.n ?? 0),
      top: top.map(mapPlayer),
      myMatches: Number(mine[0]?.n ?? 0),
      matchesToday: Number(today[0]?.n ?? 0),
      players: Number((await sql<{ n: number }>`select count(*) as n from profiles`)[0]?.n ?? 0),
    };
  });

export const searchPlayers = createServerFn({ method: "POST" })
  .validator((input: { q?: string }) => String(input?.q ?? "").trim().slice(0, 48).replace(/[%_]/g, ""))
  .middleware([authMiddleware])
  .handler(async ({ context, data: q }) => {
    if (q.length < 2) return [];
    const sql = await db();
    const like = `%${q}%`;
    const rows = await sql<ProfileRow>`
      select * from profiles
      where user_id <> ${context.userId}
        and (username ilike ${like} or display_name ilike ${like} or user_id ilike ${like})
      order by username asc
      limit 20`;
    return rows.map(mapPlayer);
  });

export type FriendEdge = PublicPlayer & { status: "pending" | "accepted"; incoming: boolean };

export const listFriends = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await db();
    const me = context.userId;
    const rows = await sql<
      ProfileRow & { status: "pending" | "accepted"; requested_by: string }
    >`
      select pr.user_id, pr.username, pr.display_name, pr.bio, pr.avatar_hue, pr.level, pr.xp,
             pr.wins, pr.losses, pr.draws, pr.last_seen, f.status, f.requested_by
      from friendships f
      join profiles pr on pr.user_id = case when f.user_a = ${me} then f.user_b else f.user_a end
      where f.user_a = ${me} or f.user_b = ${me}
      order by f.created_at desc`;
    return rows.map((r) => ({
      ...mapPlayer(r),
      status: r.status,
      incoming: r.status === "pending" && r.requested_by !== me,
    }));
  });

export const sendFriendRequest = createServerFn({ method: "POST" })
  .validator((input: { username?: string }) => String(input?.username ?? "").toLowerCase().trim())
  .middleware([authMiddleware])
  .handler(async ({ context, data: username }) => {
    const sql = await db();
    const found = await sql<{ user_id: string }>`select user_id from profiles where username = ${username}`;
    if (!found[0]) throw new Error("No player with that username.");
    if (found[0].user_id === context.userId) throw new Error("You cannot add yourself.");
    const [a, b] = pair(context.userId, found[0].user_id);
    const existing = await sql<{ status: string; requested_by: string }>`
      select status, requested_by from friendships where user_a = ${a} and user_b = ${b}`;
    if (existing[0]?.status === "accepted") throw new Error("You are already friends.");
    if (existing[0]?.status === "pending") {
      if (existing[0].requested_by === context.userId) throw new Error("Request already sent.");
      await sql`update friendships set status = 'accepted' where user_a = ${a} and user_b = ${b}`;
      return { ok: true as const, accepted: true };
    }
    await sql`
      insert into friendships (user_a, user_b, status, requested_by)
      values (${a}, ${b}, 'pending', ${context.userId})`;
    return { ok: true as const, accepted: false };
  });

export const respondFriend = createServerFn({ method: "POST" })
  .validator((input: { userId?: string; accept?: boolean }) => ({
    userId: String(input?.userId ?? ""),
    accept: Boolean(input?.accept),
  }))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await db();
    const [a, b] = pair(context.userId, data.userId);
    if (!data.accept) {
      await sql`delete from friendships where user_a = ${a} and user_b = ${b} and status = 'pending'`;
      return { ok: true as const };
    }
    const rows = await sql`
      update friendships set status = 'accepted'
      where user_a = ${a} and user_b = ${b} and status = 'pending' and requested_by <> ${context.userId}
      returning user_a`;
    if (!rows.length) throw new Error("No incoming request to accept.");
    return { ok: true as const };
  });

export const removeFriend = createServerFn({ method: "POST" })
  .validator((input: { userId?: string }) => String(input?.userId ?? ""))
  .middleware([authMiddleware])
  .handler(async ({ context, data: other }) => {
    const sql = await db();
    const [a, b] = pair(context.userId, other);
    await sql`delete from friendships where user_a = ${a} and user_b = ${b}`;
    return { ok: true as const };
  });

async function areFriends(me: string, other: string): Promise<boolean> {
  const sql = await db();
  const [a, b] = pair(me, other);
  const rows = await sql<{ status: string }>`
    select status from friendships where user_a = ${a} and user_b = ${b} and status = 'accepted'`;
  return Boolean(rows[0]);
}

export type PostView = {
  id: string;
  body: string;
  gameSlug: string | null;
  scoreLabel: string | null;
  createdAt: string;
  likes: number;
  comments: number;
  liked: boolean;
  author: PublicPlayer;
  mine: boolean;
};

export const listPosts = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await db();
    const rows = await sql<
      ProfileRow & {
        id: string;
        body: string;
        game_slug: string | null;
        score_label: string | null;
        post_created: unknown;
        likes: number;
        comments: number;
        liked: boolean | string;
      }
    >`
      select p.id, p.body, p.game_slug, p.score_label, p.created_at as post_created,
        pr.user_id, pr.username, pr.display_name, pr.bio, pr.avatar_hue, pr.level, pr.xp,
        pr.wins, pr.losses, pr.draws, pr.last_seen,
        (select count(*) from post_likes l where l.post_id = p.id) as likes,
        (select count(*) from post_comments c where c.post_id = p.id) as comments,
        exists(select 1 from post_likes l where l.post_id = p.id and l.user_id = ${context.userId}) as liked
      from posts p
      join profiles pr on pr.user_id = p.user_id
      order by p.created_at desc
      limit 40`;
    return rows.map((r) => ({
      id: r.id,
      body: r.body,
      gameSlug: r.game_slug,
      scoreLabel: r.score_label,
      createdAt: stamp(r.post_created),
      likes: Number(r.likes) || 0,
      comments: Number(r.comments) || 0,
      liked: r.liked === true || r.liked === "t" || r.liked === "true",
      author: mapPlayer(r),
      mine: r.user_id === context.userId,
    }));
  });

export const createPost = createServerFn({ method: "POST" })
  .validator((input: { body?: string; gameSlug?: string; scoreLabel?: string }) => ({
    body: cleanName(String(input?.body ?? ""), 400),
    gameSlug: String(input?.gameSlug ?? "").slice(0, 24),
    scoreLabel: cleanName(String(input?.scoreLabel ?? ""), 80),
  }))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    if (data.body.length < 1 && !data.scoreLabel) throw new Error("Write something first.");
    const sql = await db();
    const id = crypto.randomUUID();
    const game = data.gameSlug && gameBySlug(data.gameSlug) ? data.gameSlug : null;
    await sql`
      insert into posts (id, user_id, body, game_slug, score_label)
      values (${id}, ${context.userId}, ${data.body || data.scoreLabel}, ${game}, ${data.scoreLabel || null})`;
    return { id };
  });

export const toggleLike = createServerFn({ method: "POST" })
  .validator((input: { postId?: string }) => String(input?.postId ?? ""))
  .middleware([authMiddleware])
  .handler(async ({ context, data: postId }) => {
    const sql = await db();
    const existing = await sql`select post_id from post_likes where post_id = ${postId} and user_id = ${context.userId}`;
    if (existing.length) {
      await sql`delete from post_likes where post_id = ${postId} and user_id = ${context.userId}`;
      return { liked: false };
    }
    await sql`insert into post_likes (post_id, user_id) values (${postId}, ${context.userId})`;
    return { liked: true };
  });

export const listComments = createServerFn({ method: "POST" })
  .validator((input: { postId?: string }) => String(input?.postId ?? ""))
  .middleware([authMiddleware])
  .handler(async ({ data: postId }) => {
    const sql = await db();
    const rows = await sql<ProfileRow & { id: string; body: string; comment_created: unknown }>`
      select c.id, c.body, c.created_at as comment_created,
        pr.user_id, pr.username, pr.display_name, pr.bio, pr.avatar_hue, pr.level, pr.xp,
        pr.wins, pr.losses, pr.draws, pr.last_seen
      from post_comments c
      join profiles pr on pr.user_id = c.user_id
      where c.post_id = ${postId}
      order by c.created_at asc
      limit 80`;
    return rows.map((r) => ({
      id: r.id,
      body: r.body,
      createdAt: stamp(r.comment_created),
      author: mapPlayer(r),
    }));
  });

export const addComment = createServerFn({ method: "POST" })
  .validator((input: { postId?: string; body?: string }) => ({
    postId: String(input?.postId ?? ""),
    body: cleanName(String(input?.body ?? ""), 240),
  }))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    if (data.body.length < 1) throw new Error("Comment is empty.");
    const sql = await db();
    const id = crypto.randomUUID();
    await sql`
      insert into post_comments (id, post_id, user_id, body)
      values (${id}, ${data.postId}, ${context.userId}, ${data.body})`;
    return { id };
  });

export const deletePost = createServerFn({ method: "POST" })
  .validator((input: { postId?: string }) => String(input?.postId ?? ""))
  .middleware([authMiddleware])
  .handler(async ({ context, data: postId }) => {
    const sql = await db();
    await sql`delete from posts where id = ${postId} and user_id = ${context.userId}`;
    return { ok: true as const };
  });

export type MessageView = {
  id: string;
  body: string;
  createdAt: string;
  mine: boolean;
};

export const listThreads = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await db();
    const me = context.userId;
    const rows = await sql<
      ProfileRow & { body: string; sent_at: unknown; sender_id: string; recipient_id: string; read_at: unknown }
    >`
      select m.body, m.created_at as sent_at, m.sender_id, m.recipient_id, m.read_at,
        pr.user_id, pr.username, pr.display_name, pr.bio, pr.avatar_hue, pr.level, pr.xp,
        pr.wins, pr.losses, pr.draws, pr.last_seen
      from direct_messages m
      join profiles pr on pr.user_id = case when m.sender_id = ${me} then m.recipient_id else m.sender_id end
      where m.sender_id = ${me} or m.recipient_id = ${me}
      order by m.created_at desc
      limit 200`;
    const seen = new Set<string>();
    const threads: {
      player: PublicPlayer;
      body: string;
      createdAt: string;
      unread: number;
    }[] = [];
    for (const r of rows) {
      if (seen.has(r.user_id)) continue;
      seen.add(r.user_id);
      const unread = rows.filter((m) => m.user_id === r.user_id && m.recipient_id === me && !m.read_at).length;
      threads.push({
        player: mapPlayer(r),
        body: r.body,
        createdAt: stamp(r.sent_at),
        unread,
      });
    }
    return threads;
  });

export const listMessages = createServerFn({ method: "POST" })
  .validator((input: { username?: string }) => String(input?.username ?? "").toLowerCase().trim())
  .middleware([authMiddleware])
  .handler(async ({ context, data: username }) => {
    const sql = await db();
    const found = await sql<ProfileRow>`select * from profiles where username = ${username}`;
    if (!found[0]) throw new Error("Player not found.");
    const other = found[0].user_id;
    if (other === context.userId) throw new Error("That is your own profile.");
    await sql`
      update direct_messages set read_at = now()
      where recipient_id = ${context.userId} and sender_id = ${other} and read_at is null`;
    const rows = await sql<{ id: string; body: string; created_at: unknown; sender_id: string }>`
      select id, body, created_at, sender_id from direct_messages
      where (sender_id = ${context.userId} and recipient_id = ${other})
         or (sender_id = ${other} and recipient_id = ${context.userId})
      order by created_at asc
      limit 200`;
    return {
      player: mapPlayer(found[0]),
      messages: rows.map((r) => ({
        id: r.id,
        body: r.body,
        createdAt: stamp(r.created_at),
        mine: r.sender_id === context.userId,
      })),
    };
  });

export const sendMessage = createServerFn({ method: "POST" })
  .validator((input: { username?: string; body?: string }) => ({
    username: String(input?.username ?? "").toLowerCase().trim(),
    body: cleanName(String(input?.body ?? ""), 400),
  }))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    if (data.body.length < 1) throw new Error("Message is empty.");
    const sql = await db();
    const found = await sql<{ user_id: string }>`select user_id from profiles where username = ${data.username}`;
    if (!found[0]) throw new Error("Player not found.");
    if (found[0].user_id === context.userId) throw new Error("You cannot message yourself.");
    const id = crypto.randomUUID();
    await sql`
      insert into direct_messages (id, sender_id, recipient_id, body)
      values (${id}, ${context.userId}, ${found[0].user_id}, ${data.body})`;
    return { id };
  });

export type RoomMember = PublicPlayer & { ready: boolean; host: boolean };

export type RoomView = {
  code: string;
  hostId: string;
  gameSlug: string;
  maxPlayers: number;
  fillAi: boolean;
  status: "lobby" | "live" | "done";
  version: number;
  state: TurnState | null;
  members: RoomMember[];
  messages: { id: string; body: string; createdAt: string; author: PublicPlayer }[];
  scores: { userId: string; username: string; displayName: string; score: number; detail: string }[];
};

export const createRoom = createServerFn({ method: "POST" })
  .validator((input: { slug?: string; withAi?: boolean; seats?: number; fillAi?: boolean; listed?: boolean }) => ({
    slug: String(input?.slug ?? ""),
    withAi: Boolean(input?.withAi),
    seats: Number(input?.seats) || 0,
    fillAi: Boolean(input?.fillAi),
    listed: input?.listed !== false,
  }))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const game = gameBySlug(data.slug);
    if (!game) throw new Error("Unknown game.");
    if (game.slug === "adventure") throw new Error("Open World Adventure is solo. There is no shared room.");
    const sql = await db();
    await ensureRoomColumns(sql);
    await ensure(context.userId, "");
    let code = roomCode();
    for (let i = 0; i < 5; i++) {
      const clash = await sql`select code from rooms where code = ${code}`;
      if (!clash.length) break;
      code = roomCode();
    }
    const duel = game.slug === "football" || game.slug === "shooter" || game.slug === "race";
    const seats = duel || game.slug === "snooker" ? 2 : Math.min(game.max, Math.max(game.min, data.seats || game.max));
    const fillAi = duel ? false : Boolean(data.fillAi && isTurnGame(game.slug));
    const liveNow = data.withAi && isTurnGame(game.slug);
    const state = liveNow ? initialTurn(game.slug, [context.userId, "ai"]) : null;
    const listed = liveNow ? false : data.listed;
    await sql`
      insert into rooms (code, host_id, game_slug, max_players, status, state_json, state_version, fill_ai, listed)
      values (${code}, ${context.userId}, ${game.slug}, ${liveNow ? game.max : seats}, ${liveNow ? "live" : "lobby"}, ${state ? JSON.stringify(state) : ""}, ${state ? 1 : 0}, ${liveNow ? true : fillAi}, ${listed})`;
    await sql`insert into room_members (code, user_id, ready) values (${code}, ${context.userId}, true)`;
    return { code };
  });

export const joinRoom = createServerFn({ method: "POST" })
  .validator((input: { code?: string }) =>
    String(input?.code ?? "")
      .toUpperCase()
      .replace(/[^A-Z0-9]/g, "")
      .slice(0, 8),
  )
  .middleware([authMiddleware])
  .handler(async ({ context, data: code }) => {
    const sql = await db();
    await ensure(context.userId, "");
    const rooms = await sql<{ status: string; max_players: number; game_slug: string }>`
      select status, max_players, game_slug from rooms where code = ${code}`;
    if (!rooms[0]) throw new Error("No room with that code.");
    if (rooms[0].status !== "lobby") throw new Error("That match already started.");
    const members = await sql<{ user_id: string }>`select user_id from room_members where code = ${code}`;
    if (members.some((m) => m.user_id === context.userId)) return { code };
    const joined = await sql<{ code: string }>`
      insert into room_members (code, user_id, ready)
      select ${code}, ${context.userId}, false
      where exists (
        select 1 from rooms r
        where r.code = ${code} and r.status = 'lobby'
          and (select count(*) from room_members m where m.code = r.code) < r.max_players
      )
      returning code`;
    if (!joined.length) throw new Error("That room is full or the match already started.");
    return { code };
  });

export type OpenRoom = {
  code: string;
  gameSlug: string;
  hostName: string;
  players: number;
  maxPlayers: number;
};

export const listOpenRooms = createServerFn({ method: "POST" })
  .validator((input: { slug?: string } | undefined) => ({
    slug: String(input?.slug ?? "").slice(0, 40),
  }))
  .middleware([authMiddleware])
  .handler(async ({ data }) => {
    const sql = await db();
    await ensureRoomColumns(sql);
    await sql`
      delete from room_members rm
      using profiles pr, rooms r
      where rm.user_id = pr.user_id
        and rm.code = r.code
        and r.status = 'lobby'
        and pr.last_seen < now() - interval '3 minutes'`;
    await sql`
      delete from rooms r
      where r.status = 'lobby'
        and not exists (select 1 from room_members m where m.code = r.code)`;
    const rows = await sql<{
      code: string;
      game_slug: string;
      max_players: number;
      display_name: string;
      players: number;
    }>`
      select r.code, r.game_slug, r.max_players, pr.display_name,
        (select count(*) from room_members m where m.code = r.code) as players
      from rooms r
      join profiles pr on pr.user_id = r.host_id
      where r.status = 'lobby' and r.listed = true
        and (${data.slug} = '' or r.game_slug = ${data.slug})
      order by r.updated_at desc
      limit 40`;
    const rooms: OpenRoom[] = rows.map((row) => ({
      code: row.code,
      gameSlug: row.game_slug,
      hostName: row.display_name,
      players: Number(row.players) || 0,
      maxPlayers: Number(row.max_players) || 0,
    }));
    return rooms;
  });

export const getRoom = createServerFn({ method: "POST" })
  .validator((input: { code?: string }) =>
    String(input?.code ?? "")
      .toUpperCase()
      .replace(/[^A-Z0-9]/g, "")
      .slice(0, 8),
  )
  .middleware([authMiddleware])
  .handler(async ({ context, data: code }) => {
    const sql = await db();
    const rooms = await sql<{
      code: string;
      host_id: string;
      game_slug: string;
      max_players: number;
      status: "lobby" | "live" | "done";
      state_json: string;
      state_version: number;
      fill_ai: boolean;
    }>`select * from rooms where code = ${code}`;
    if (!rooms[0]) throw new Error("Room not found.");
    const room = rooms[0];
    const members = await sql<ProfileRow & { ready: boolean }>`
      select pr.user_id, pr.username, pr.display_name, pr.bio, pr.avatar_hue, pr.level, pr.xp,
             pr.wins, pr.losses, pr.draws, pr.last_seen, rm.ready
      from room_members rm
      join profiles pr on pr.user_id = rm.user_id
      where rm.code = ${code}
      order by rm.joined_at asc`;
    const messages = await sql<ProfileRow & { id: string; body: string; sent_at: unknown }>`
      select m.id, m.body, m.created_at as sent_at,
        pr.user_id, pr.username, pr.display_name, pr.bio, pr.avatar_hue, pr.level, pr.xp,
        pr.wins, pr.losses, pr.draws, pr.last_seen
      from room_messages m
      join profiles pr on pr.user_id = m.user_id
      where m.code = ${code}
      order by m.created_at asc
      limit 80`;
    const scores = await sql<{ user_id: string; username: string; display_name: string; score: number; detail: string }>`
      select s.user_id, s.score, s.detail, pr.username, pr.display_name
      from room_scores s
      join profiles pr on pr.user_id = s.user_id
      where s.code = ${code}
      order by s.score desc`;
    let state: TurnState | null = null;
    if (room.state_json) {
      try {
        state = JSON.parse(room.state_json) as TurnState;
      state = hideHiddenCards(state, context.userId);
      } catch {
        state = null;
      }
    }
    const view: RoomView = {
      code: room.code,
      hostId: room.host_id,
      gameSlug: room.game_slug,
      maxPlayers: Number(room.max_players),
      fillAi: room.fill_ai === true || room.fill_ai === "t",
      status: room.status,
      version: Number(room.state_version) || 0,
      state,
      members: members.map((m) => ({ ...mapPlayer(m), ready: Boolean(m.ready), host: m.user_id === room.host_id })),
      messages: messages.map((m) => ({
        id: m.id,
        body: m.body,
        createdAt: stamp(m.sent_at),
        author: mapPlayer(m),
      })),
      scores: scores.map((s) => ({
        userId: s.user_id,
        username: s.username,
        displayName: s.display_name,
        score: Number(s.score) || 0,
        detail: s.detail,
      })),
    };
    return view;
  });

export const setReady = createServerFn({ method: "POST" })
  .validator((input: { code?: string; ready?: boolean }) => ({
    code: String(input?.code ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8),
    ready: Boolean(input?.ready),
  }))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await db();
    await sql`update room_members set ready = ${data.ready} where code = ${data.code} and user_id = ${context.userId}`;
    return { ok: true as const };
  });

export const leaveRoom = createServerFn({ method: "POST" })
  .validator((input: { code?: string }) => String(input?.code ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8))
  .middleware([authMiddleware])
  .handler(async ({ context, data: code }) => {
    const sql = await db();
    await sql`delete from room_members where code = ${code} and user_id = ${context.userId}`;
    const left = await sql<{ user_id: string }>`select user_id from room_members where code = ${code} order by joined_at asc`;
    if (!left.length) {
      await sql`delete from rooms where code = ${code}`;
      return { ok: true as const };
    }
    const rooms = await sql<{ host_id: string }>`select host_id from rooms where code = ${code}`;
    if (rooms[0]?.host_id === context.userId) {
      await sql`update rooms set host_id = ${left[0].user_id} where code = ${code}`;
    }
    return { ok: true as const };
  });

export const startRoom = createServerFn({ method: "POST" })
  .validator((input: { code?: string }) => String(input?.code ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8))
  .middleware([authMiddleware])
  .handler(async ({ context, data: code }) => {
    const sql = await db();
    const rooms = await sql<{ host_id: string; game_slug: string; status: string; max_players: number; fill_ai: boolean }>`
      select host_id, game_slug, status, max_players, fill_ai from rooms where code = ${code}`;
    if (!rooms[0]) throw new Error("Room not found.");
    if (rooms[0].host_id !== context.userId) throw new Error("Only the host can start.");
    if (rooms[0].status !== "lobby") throw new Error("This match already started.");
    const game = gameBySlug(rooms[0].game_slug);
    if (!game) throw new Error("Unknown game.");
    const members = await sql<{ user_id: string }>`
      select user_id from room_members where code = ${code} order by joined_at asc`;
    const humans = [context.userId, ...members.map((m) => m.user_id).filter((id) => id !== context.userId)];
    const fillAi = rooms[0].fill_ai === true || rooms[0].fill_ai === "t";
    const duel = game.slug === "football" || game.slug === "shooter" || game.slug === "race";
    if (duel) {
      if (humans.length < 2) throw new Error("Need a second player. Share the room code. The computer is a separate button, not a hidden opponent.");
      if (humans.length > 2) throw new Error("This match is 1v1.");
      await sql`update rooms set status = 'live', updated_at = now() where code = ${code}`;
      return { ok: true as const };
    }
    if (isTurnGame(game.slug)) {
      const seats = [...humans];
      const cap = Number(rooms[0].max_players) || game.max;
      if (!fillAi && seats.length < cap) {
        throw new Error(`Waiting for ${cap - seats.length} more player${cap - seats.length === 1 ? "" : "s"}. Or host again and allow the computer to fill empty seats.`);
      }
      if (fillAi) {
        while (seats.length < Math.max(game.min, cap)) seats.push("ai");
      }
      if (seats.length < game.min) throw new Error("Not enough players to start.");
      if (seats.length > game.max) throw new Error("Too many players for this game.");
      const state = initialTurn(game.slug, seats);
      await sql`
        update rooms set status = 'live', state_json = ${JSON.stringify(state)}, state_version = state_version + 1, updated_at = now()
        where code = ${code}`;
    } else {
      await sql`update rooms set status = 'live', updated_at = now() where code = ${code}`;
    }
    return { ok: true as const };
  });

export const sendRoomMessage = createServerFn({ method: "POST" })
  .validator((input: { code?: string; body?: string }) => ({
    code: String(input?.code ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8),
    body: cleanName(String(input?.body ?? ""), 240),
  }))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    if (!data.body) throw new Error("Message is empty.");
    const sql = await db();
    const member = await sql`select user_id from room_members where code = ${data.code} and user_id = ${context.userId}`;
    if (!member.length) throw new Error("Join the room before chatting.");
    await sql`
      insert into room_messages (id, code, user_id, body)
      values (${crypto.randomUUID()}, ${data.code}, ${context.userId}, ${data.body})`;
    return { ok: true as const };
  });

export const actRoom = createServerFn({ method: "POST" })
  .validator((input: { code?: string; action?: unknown }) => ({
    code: String(input?.code ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8),
    action: (input?.action ?? {}) as Record<string, unknown>,
  }))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await db();
    const rooms = await sql<{ state_json: string; state_version: number; status: string }>`
      select state_json, state_version, status from rooms where code = ${data.code}`;
    if (!rooms[0] || rooms[0].status !== "live" || !rooms[0].state_json) throw new Error("No live match in this room.");
    const member = await sql`select user_id from room_members where code = ${data.code} and user_id = ${context.userId}`;
    if (!member.length) throw new Error("You are not in this room.");
    let state = JSON.parse(rooms[0].state_json) as TurnState;
    const version = Number(rooms[0].state_version) || 0;
    if (data.action.type === "ai") {
      if (turnSeat(state) !== "ai") return { version, changed: false };
      state = stepAi(state);
    } else {
      state = applyTurn(state, context.userId, data.action);
    }
    const updated = await sql<{ state_version: number }>`
      update rooms
      set state_json = ${JSON.stringify(state)}, state_version = ${version + 1}, updated_at = now()
      where code = ${data.code} and state_version = ${version}
      returning state_version`;
    if (!updated.length) throw new Error("The board changed. Try that again.");
    return { version: Number(updated[0].state_version), changed: true };
  });

async function grantXp(userId: string, result: "win" | "loss" | "draw") {
  const sql = await db();
  const gain = result === "win" ? 30 : result === "draw" ? 12 : 8;
  const win = result === "win" ? 1 : 0;
  const loss = result === "loss" ? 1 : 0;
  const draw = result === "draw" ? 1 : 0;
  await sql`
    update profiles set
      wins = wins + ${win},
      losses = losses + ${loss},
      draws = draws + ${draw},
      xp = xp + ${gain},
      level = (1 + floor((xp + ${gain}) / 80.0))::int,
      last_seen = now()
    where user_id = ${userId}`;
}

export const claimTurnResult = createServerFn({ method: "POST" })
  .validator((input: { code?: string }) => String(input?.code ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8))
  .middleware([authMiddleware])
  .handler(async ({ context, data: code }) => {
    const sql = await db();
    const rooms = await sql<{ state_json: string; game_slug: string }>`
      select state_json, game_slug from rooms where code = ${code}`;
    if (!rooms[0]?.state_json) return { saved: false as const };
    const state = JSON.parse(rooms[0].state_json) as TurnState;
    const outcome = matchResultFor(state, context.userId);
    if (!outcome) return { saved: false as const };
    const existing = await sql`select id from matches where user_id = ${context.userId} and room_code = ${code}`;
    if (existing.length) return { saved: true as const };
    let opponent = outcome.opponent;
    if (opponent === "ai") opponent = "Computer";
    else {
      const named = await sql<{ username: string }>`select username from profiles where user_id = ${opponent}`;
      opponent = named[0]?.username ?? "Player";
    }
    await sql`
      insert into matches (id, user_id, game_slug, result, detail, opponent, room_code)
      values (${crypto.randomUUID()}, ${context.userId}, ${rooms[0].game_slug}, ${outcome.result}, ${outcome.detail}, ${opponent}, ${code})`;
    await grantXp(context.userId, outcome.result);
    return { saved: true as const, result: outcome.result, detail: outcome.detail, opponent };
  });

export const saveActionResult = createServerFn({ method: "POST" })
  .validator(
    (input: {
      id?: string;
      slug?: string;
      result?: string;
      detail?: string;
      opponent?: string;
      score?: number;
      code?: string;
    }) => ({
      id: String(input?.id ?? ""),
      slug: String(input?.slug ?? ""),
      result: input?.result === "win" || input?.result === "draw" ? input.result : "loss",
      detail: cleanName(String(input?.detail ?? ""), 80),
      opponent: cleanName(String(input?.opponent ?? "Computer"), 40) || "Computer",
      score: Math.max(0, Math.min(999999, Math.round(Number(input?.score ?? 0)))),
      code: String(input?.code ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8),
    }),
  )
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    if (!gameBySlug(data.slug) || isTurnGame(data.slug)) throw new Error("That result cannot be saved this way.");
    if (!/^[0-9a-f-]{36}$/i.test(data.id)) throw new Error("Bad match id.");
    const sql = await db();
    const inserted = await sql<{ id: string }>`
      insert into matches (id, user_id, game_slug, result, detail, opponent, room_code)
      values (${data.id}, ${context.userId}, ${data.slug}, ${data.result}, ${data.detail}, ${data.opponent}, ${data.code || null})
      on conflict (id) do nothing
      returning id`;
    if (data.code) {
      const member = await sql`select user_id from room_members where code = ${data.code} and user_id = ${context.userId}`;
      if (member.length) {
        await sql`
          insert into room_scores (code, user_id, score, detail)
          values (${data.code}, ${context.userId}, ${data.score}, ${data.detail})
          on conflict (code, user_id) do update set score = excluded.score, detail = excluded.detail`;
      }
    }
    if (inserted.length) await grantXp(context.userId, data.result);
    return { saved: true as const };
  });

export const listMatches = createServerFn({ method: "POST" })
  .validator((input: { username?: string }) => String(input?.username ?? "").toLowerCase().trim())
  .middleware([authMiddleware])
  .handler(async ({ context, data: username }) => {
    const sql = await db();
    const me = await ensure(context.userId, "");
    const targetName = username || me.username;
    const found = await sql<ProfileRow>`select * from profiles where username = ${targetName}`;
    if (!found[0]) throw new Error("Player not found.");
    const profile = mapProfile(found[0]);
    const [a, b] = pair(context.userId, profile.userId);
    let friend: "self" | "friends" | "none" = "none";
    if (profile.userId === context.userId) friend = "self";
    else {
      const rel = await sql<{ status: string; requested_by: string }>`
        select status, requested_by from friendships where user_a = ${a} and user_b = ${b}`;
      friend = rel[0]?.status === "accepted" ? "friends" : "none";
    }
    const rows = await sql<{
      id: string;
      game_slug: string;
      result: "win" | "loss" | "draw";
      detail: string;
      opponent: string;
      played_at: unknown;
    }>`
      select id, game_slug, result, detail, opponent, played_at
      from matches where user_id = ${profile.userId}
      order by played_at desc
      limit 30`;
    return {
      profile,
      relation: friend,
      matches: rows.map((r) => ({
        id: r.id,
        gameSlug: r.game_slug,
        result: r.result,
        detail: r.detail,
        opponent: r.opponent,
        playedAt: stamp(r.played_at),
      })),
    };
  });

export const inviteFriend = createServerFn({ method: "POST" })
  .validator((input: { code?: string; username?: string }) => ({
    code: String(input?.code ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8),
    username: String(input?.username ?? "").toLowerCase().trim(),
  }))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await db();
    const rooms = await sql<{ game_slug: string }>`select game_slug from rooms where code = ${data.code}`;
    if (!rooms[0]) throw new Error("Room not found.");
    const game = gameBySlug(rooms[0].game_slug);
    const found = await sql<{ user_id: string }>`select user_id from profiles where username = ${data.username}`;
    if (!found[0]) throw new Error("Player not found.");
    if (!(await areFriends(context.userId, found[0].user_id))) throw new Error("Invite friends only.");
    const body = `Join my ${game?.name ?? "SAM BN"} room: ${data.code}`;
    await sql`
      insert into direct_messages (id, sender_id, recipient_id, body)
      values (${crypto.randomUUID()}, ${context.userId}, ${found[0].user_id}, ${body})`;
    return { ok: true as const };
  });
