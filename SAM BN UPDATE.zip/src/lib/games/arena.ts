import type { Pad } from "./pad";

export type Bullet = { x: number; y: number; vx: number; vy: number; mine: boolean; dmg: number };

export type WeaponId = "rifle" | "smg" | "shotgun" | "sniper" | "pistol";

export const WEAPONS: { id: WeaponId; name: string; rate: number; dmg: number; speed: number; mag: number; reload: number; spread: number; pellets: number }[] = [
  { id: "rifle", name: "Rifle", rate: 0.12, dmg: 16, speed: 680, mag: 30, reload: 1.35, spread: 0.035, pellets: 1 },
  { id: "smg", name: "SMG", rate: 0.07, dmg: 9, speed: 620, mag: 28, reload: 1.05, spread: 0.09, pellets: 1 },
  { id: "shotgun", name: "Shotgun", rate: 0.72, dmg: 10, speed: 500, mag: 6, reload: 1.7, spread: 0.18, pellets: 6 },
  { id: "sniper", name: "Sniper", rate: 1.05, dmg: 72, speed: 920, mag: 5, reload: 1.9, spread: 0.004, pellets: 1 },
  { id: "pistol", name: "Pistol", rate: 0.28, dmg: 22, speed: 580, mag: 12, reload: 0.95, spread: 0.03, pellets: 1 },
];

export type Fighter = {
  x: number;
  y: number;
  facing: number;
  hp: number;
  stocks: number;
  cool: number;
  slot: number;
  mag: number;
  reserve: number;
  reload: number;
  crouch: number;
  hop: number;
};

export type Arena = {
  x: number;
  y: number;
  facing: number;
  hp: number;
  stocks: number;
  cool: number;
  slot: number;
  mag: number;
  reserve: number;
  reload: number;
  crouch: number;
  hop: number;
  clock: number;
  bot: Fighter;
  bullets: Bullet[];
  over: boolean;
};

export const BLOCKS = [
  { x: 180, y: 80, w: 110, h: 70 },
  { x: 680, y: 300, w: 140, h: 60 },
  { x: 400, y: 180, w: 70, h: 140 },
  { x: 760, y: 70, w: 90, h: 90 },
  { x: 80, y: 340, w: 120, h: 48 },
];

const MATCH_SECONDS = 180;

function clamp(n: number, a: number, b: number) {
  return Math.max(a, Math.min(b, n));
}

export function hitsBlock(x: number, y: number, r: number) {
  if (x < r || y < r || x > 960 - r || y > 480 - r) return true;
  return BLOCKS.some((b) => x > b.x - r && x < b.x + b.w + r && y > b.y - r && y < b.y + b.h + r);
}

function los(ax: number, ay: number, bx: number, by: number) {
  const steps = 14;
  for (let i = 1; i < steps; i++) {
    const x = ax + ((bx - ax) * i) / steps;
    const y = ay + ((by - ay) * i) / steps;
    if (hitsBlock(x, y, 1)) return false;
  }
  return true;
}

function fighter(x: number, y: number, facing: number): Fighter {
  const gun = WEAPONS[0];
  return { x, y, facing, hp: 100, stocks: 3, cool: 0, slot: 0, mag: gun.mag, reserve: gun.mag * 3, reload: 0, crouch: 0, hop: 0 };
}

export function createArena(): Arena {
  const me = fighter(120, 240, 0);
  return {
    ...me,
    clock: MATCH_SECONDS,
    bot: fighter(820, 240, Math.PI),
    bullets: [],
    over: false,
  };
}

function pushShot(s: Arena, x: number, y: number, facing: number, speed: number, mine: boolean, dmg: number) {
  s.bullets.push({ x, y, vx: Math.cos(facing) * speed, vy: Math.sin(facing) * speed, mine, dmg });
}

function shoot(body: { x: number; y: number; facing: number; slot: number; mag: number; reserve: number; reload: number; cool: number }, mine: boolean, s: Arena) {
  const gun = WEAPONS[body.slot] ?? WEAPONS[0];
  if (body.reload > 0 || body.cool > 0) return;
  if (body.mag <= 0) {
    if (body.reserve > 0) body.reload = gun.reload;
    return;
  }
  body.cool = gun.rate;
  body.mag -= 1;
  for (let p = 0; p < gun.pellets; p++) {
    const spread = (Math.random() - 0.5) * gun.spread * 2;
    pushShot(s, body.x, body.y, body.facing + spread, gun.speed, mine, gun.dmg);
  }
}

function tickBody(body: { reload: number; mag: number; reserve: number; slot: number; cool: number; crouch: number; hop: number }, dt: number, wantReload: boolean) {
  const gun = WEAPONS[body.slot] ?? WEAPONS[0];
  body.cool -= dt;
  body.crouch = Math.max(0, body.crouch - dt);
  body.hop = Math.max(0, body.hop - dt);
  if (body.reload > 0) {
    body.reload -= dt;
    if (body.reload <= 0) {
      const need = gun.mag - body.mag;
      const take = Math.min(need, body.reserve);
      body.mag += take;
      body.reserve -= take;
      body.reload = 0;
    }
    return;
  }
  if (wantReload && body.mag < gun.mag && body.reserve > 0) body.reload = gun.reload;
}

function moveBody(body: { x: number; y: number }, nx: number, ny: number) {
  if (!hitsBlock(nx, body.y, 12)) body.x = clamp(nx, 20, 940);
  if (!hitsBlock(body.x, ny, 12)) body.y = clamp(ny, 20, 460);
}

/** Host-side arena. `opp` is the computer, or the other phone. Damage is applied here, not by the client that got hit. */
export function stepArena(s: Arena, dt: number, me: Pad, opp: Pad | "ai") {
  if (s.over) return;
  s.clock = Math.max(0, (s.clock ?? MATCH_SECONDS) - dt);
  const speed = (me.crouch ? 120 : 210) * dt;
  const facing = s.facing + (me.turn || 0) * dt;
  s.facing = facing;
  const fx = Math.cos(facing);
  const fy = Math.sin(facing);
  const forward = -me.y;
  const strafe = me.x;
  moveBody(s, s.x + (fx * forward + -fy * strafe) * speed, s.y + (fy * forward + fx * strafe) * speed);
  if (typeof me.slot === "number" && me.slot >= 0 && me.slot < WEAPONS.length && me.slot !== s.slot && s.reload <= 0) {
    s.slot = me.slot;
    const gun = WEAPONS[s.slot];
    s.mag = gun.mag;
    s.reserve = gun.mag * 2;
    s.reload = 0;
  }
  if (me.crouch) s.crouch = 0.2;
  if (me.jump && s.hop <= 0 && s.crouch <= 0) s.hop = 0.34;
  tickBody(s, dt, Boolean(me.reload));
  if ((me.fire || me.shoot) && s.reload <= 0) shoot(s, true, s);

  if (opp === "ai") {
    const dx = s.x - s.bot.x;
    const dy = s.y - s.bot.y;
    const dist = Math.hypot(dx, dy);
    const see = los(s.bot.x, s.bot.y, s.x, s.y);
    const wantSlot = dist > 380 ? 3 : dist < 150 ? 2 : 0;
    if (s.bot.reload <= 0 && s.bot.slot !== wantSlot) {
      s.bot.slot = wantSlot;
      s.bot.mag = WEAPONS[wantSlot].mag;
      s.bot.reserve = WEAPONS[wantSlot].mag * 2;
    }
    const strafe = see ? Math.sin(s.clock * 2.2) : 0;
    const toward = see && dist < 220 ? -1 : 1;
    const aim = Math.atan2(dy, dx);
    s.bot.facing = aim;
    const sp = 145 * dt;
    moveBody(
      s.bot,
      s.bot.x + (Math.cos(aim) * toward + Math.cos(aim + Math.PI / 2) * strafe) * sp,
      s.bot.y + (Math.sin(aim) * toward + Math.sin(aim + Math.PI / 2) * strafe) * sp,
    );
    tickBody(s.bot, dt, s.bot.mag <= 0);
    if (see && dist < 520) shoot(s.bot, false, s);
  } else {
    const of = s.bot.facing + (opp.turn || 0) * dt;
    s.bot.facing = of;
    const ox = Math.cos(of);
    const oy = Math.sin(of);
    const osp = (opp.crouch ? 120 : 210) * dt;
    moveBody(
      s.bot,
      s.bot.x + (ox * -opp.y + -oy * opp.x) * osp,
      s.bot.y + (oy * -opp.y + ox * opp.x) * osp,
    );
    if (typeof opp.slot === "number" && opp.slot >= 0 && opp.slot < WEAPONS.length && opp.slot !== s.bot.slot && s.bot.reload <= 0) {
      s.bot.slot = opp.slot;
      s.bot.mag = WEAPONS[s.bot.slot].mag;
      s.bot.reserve = WEAPONS[s.bot.slot].mag * 2;
    }
    if (opp.crouch) s.bot.crouch = 0.2;
    if (opp.jump && s.bot.hop <= 0) s.bot.hop = 0.34;
    tickBody(s.bot, dt, Boolean(opp.reload));
    if ((opp.fire || opp.shoot) && s.bot.reload <= 0) shoot(s.bot, false, s);
  }

  const meR = s.hop > 0.05 ? 8 : s.crouch > 0 ? 9 : 14;
  const botR = s.bot.hop > 0.05 ? 8 : s.bot.crouch > 0 ? 9 : 14;
  for (const b of s.bullets) {
    b.x += b.vx * dt;
    b.y += b.vy * dt;
    if (hitsBlock(b.x, b.y, 0)) b.x = -999;
    if (b.mine && Math.hypot(b.x - s.bot.x, b.y - s.bot.y) < botR) {
      s.bot.hp -= b.dmg;
      b.x = -999;
    }
    if (!b.mine && Math.hypot(b.x - s.x, b.y - s.y) < meR) {
      s.hp -= b.dmg;
      b.x = -999;
    }
  }
  s.bullets = s.bullets.filter((b) => b.x > 0 && b.x < 960 && b.y > 0 && b.y < 480);
  if (s.hp <= 0) {
    s.stocks -= 1;
    s.hp = 100;
    s.x = 120;
    s.y = 240;
  }
  if (s.bot.hp <= 0) {
    s.bot.stocks -= 1;
    s.bot.hp = 100;
    s.bot.x = 820;
    s.bot.y = 240;
  }
  if (s.stocks <= 0 || s.bot.stocks <= 0 || s.clock <= 0) s.over = true;
}
