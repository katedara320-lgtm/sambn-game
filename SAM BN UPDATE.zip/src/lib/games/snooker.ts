/** 8-ball on the SAM BN table. The slug stays snooker so existing rooms and links keep working. */

export type BallKind = "cue" | "solid" | "stripe" | "eight";
export type Group = "solid" | "stripe";

export type TableBall = {
  id: string;
  n: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  value: number;
  kind: BallKind;
  pocketed: boolean;
  spotX: number;
  spotY: number;
  spin: number;
  follow: number;
};

export type SnookerState = {
  seats: string[];
  balls: TableBall[];
  turn: number;
  scores: number[];
  phase: "break" | "open" | "play";
  nextColour: number;
  groups: [Group | null, Group | null];
  ballInHand: boolean;
  kitchen: boolean;
  winner: number | "draw" | null;
  log: string;
};

export type SnookerAction =
  | { type: "shot"; dx: number; dy: number; power: number; side?: number; follow?: number }
  | { type: "place"; x: number; y: number };

export const POCKETS = [
  { x: 46, y: 46 },
  { x: 450, y: 34 },
  { x: 854, y: 46 },
  { x: 46, y: 404 },
  { x: 450, y: 416 },
  { x: 854, y: 404 },
];

const R = 12;
const COLOUR: Record<number, string> = {
  1: "#e6b325",
  2: "#1d4ed8",
  3: "#dc2626",
  4: "#7c3aed",
  5: "#f97316",
  6: "#15803d",
  7: "#7f1d1d",
  8: "#141414",
  9: "#e6b325",
  10: "#1d4ed8",
  11: "#dc2626",
  12: "#7c3aed",
  13: "#f97316",
  14: "#15803d",
  15: "#7f1d1d",
};

export function rackSnooker(seats: string[]): SnookerState {
  if (seats.length < 1 || seats.length > 2) throw new Error("8-ball is one or two players.");
  const balls: TableBall[] = [objectBall("cue", 0, 200, 225, "cue")];
  const order = [1, 9, 2, 3, 8, 10, 11, 4, 13, 6, 7, 14, 15, 12, 5];
  let i = 0;
  for (let row = 0; row < 5; row++) {
    for (let col = 0; col <= row; col++) {
      const n = order[i];
      i += 1;
      const x = 610 + row * 25;
      const y = 225 - row * 13 + col * 26;
      balls.push(objectBall(`b${n}`, n, x, y, n === 8 ? "eight" : n < 8 ? "solid" : "stripe"));
    }
  }
  return {
    seats,
    balls,
    turn: 0,
    scores: seats.map(() => 7),
    phase: "break",
    nextColour: 0,
    groups: [null, null],
    ballInHand: false,
    kitchen: false,
    winner: null,
    log: "Open table. Drag back from the white and release.",
  };
}

function objectBall(id: string, n: number, x: number, y: number, kind: BallKind): TableBall {
  return {
    id,
    n,
    x,
    y,
    vx: 0,
    vy: 0,
    color: n === 0 ? "#f7f4ef" : COLOUR[n],
    value: n,
    kind,
    pocketed: false,
    spotX: x,
    spotY: y,
    spin: 0,
    follow: 0,
  };
}

export function resting(state: SnookerState) {
  return state.balls.every((b) => b.pocketed || Math.hypot(b.vx, b.vy) < 4);
}

export function launchCue(state: SnookerState, action: Extract<SnookerAction, { type: "shot" }>): SnookerState {
  if (state.winner !== null) throw new Error("This rack is over.");
  if (state.ballInHand) throw new Error("Place the cue ball first.");
  if (!resting(state)) throw new Error("Balls are still moving.");
  const next = clone(state);
  const cue = next.balls.find((b) => b.kind === "cue" && !b.pocketed);
  if (!cue) throw new Error("The cue ball is off the table.");
  const len = Math.hypot(action.dx, action.dy) || 1;
  const power = Math.max(0.15, Math.min(1, action.power));
  cue.vx = (action.dx / len) * (120 + power * 620);
  cue.vy = (action.dy / len) * (120 + power * 620);
  cue.spin = clamp(action.side ?? 0);
  cue.follow = clamp(action.follow ?? 0);
  return next;
}

export function placeCue(state: SnookerState, x: number, y: number): SnookerState {
  if (!state.ballInHand) throw new Error("The cue ball is not in hand.");
  if (x < 64 || x > 836 || y < 64 || y > 386) throw new Error("Place the cue ball on the cloth.");
  if (state.kitchen && x > 250) throw new Error("After the break, place the cue ball behind the line.");
  const next = clone(state);
  const cue = next.balls.find((b) => b.kind === "cue");
  if (!cue) throw new Error("The cue ball is missing.");
  if (next.balls.some((b) => b !== cue && !b.pocketed && Math.hypot(b.x - x, b.y - y) < R * 2 + 1)) {
    throw new Error("The cue ball cannot sit on another ball.");
  }
  cue.pocketed = false;
  cue.x = x;
  cue.y = y;
  cue.vx = 0;
  cue.vy = 0;
  cue.spin = 0;
  cue.follow = 0;
  next.ballInHand = false;
  next.kitchen = false;
  next.log = "Cue ball placed. Drag back to shoot.";
  return next;
}

export function finishShot(state: SnookerState, beforeIds: string[], firstId: string | null): SnookerState {
  const was = new Set(beforeIds);
  const potted = state.balls.filter((b) => b.pocketed && !was.has(b.id));
  for (const ball of state.balls) {
    ball.vx = 0;
    ball.vy = 0;
    ball.spin = 0;
    ball.follow = 0;
  }
  return judge(state, potted, firstId);
}

export function rollShot(state: SnookerState, action: Extract<SnookerAction, { type: "shot" }>): { frames: TableBall[][]; result: SnookerState } {
  const before = state.balls.filter((b) => b.pocketed).map((b) => b.id);
  const next = launchCue(state, action);
  const hit = { id: null as string | null };
  const frames: TableBall[][] = [next.balls.map((b) => ({ ...b }))];
  const dt = 1 / 120;
  for (let i = 0; i < 120 * 8; i++) {
    step(next.balls, dt, [], hit);
    if (i % 2 === 0) frames.push(next.balls.map((b) => ({ ...b })));
    if (next.balls.every((b) => b.pocketed || Math.hypot(b.vx, b.vy) < 4)) break;
  }
  const result = finishShot(next, before, hit.id);
  frames.push(result.balls.map((b) => ({ ...b })));
  return { frames, result };
}

export function applySnooker(state: SnookerState, seat: number, action: SnookerAction): SnookerState {
  if (seat !== state.turn) throw new Error("It is not your shot.");
  if (action.type === "place") return placeCue(state, action.x, action.y);
  return rollShot(state, action).result;
}

export function aiSnooker(state: SnookerState): SnookerAction {
  if (state.ballInHand) return { type: "place", x: state.kitchen ? 180 : 320, y: 180 + (state.turn % 2) * 90 };
  const cue = state.balls.find((b) => b.kind === "cue" && !b.pocketed);
  const target = aimTarget(state);
  if (!cue || !target) return { type: "shot", dx: 1, dy: 0, power: 0.45, side: 0, follow: 0 };
  return { type: "shot", dx: target.x - cue.x, dy: target.y - cue.y, power: 0.62, side: 0, follow: 0.15 };
}

function aimTarget(state: SnookerState) {
  const group = state.groups[state.turn];
  const live = state.balls.filter((b) => !b.pocketed && b.kind !== "cue");
  if (group && !live.some((b) => b.kind === group)) return live.find((b) => b.kind === "eight");
  if (group) return live.find((b) => b.kind === group) ?? live[0];
  return live.find((b) => b.kind === "solid" || b.kind === "stripe") ?? live[0];
}

function judge(state: SnookerState, potted: TableBall[], firstId: string | null): SnookerState {
  const cue = potted.find((b) => b.kind === "cue");
  const eight = potted.find((b) => b.kind === "eight");
  const solids = potted.filter((b) => b.kind === "solid");
  const stripes = potted.filter((b) => b.kind === "stripe");
  const onBreak = state.phase === "break";
  const me = state.turn;
  const foe = (me + 1) % Math.max(1, state.seats.length);
  const first = state.balls.find((b) => b.id === firstId) ?? null;
  const group = state.groups[me];

  if (eight && onBreak) respot(state, eight);

  if (eight && !onBreak) {
    const stillOwn = Boolean(group && state.balls.some((b) => !b.pocketed && b.kind === group));
    const early = !group || stillOwn || Boolean(cue);
    if (early) {
      if (state.seats.length === 1) {
        respot(state, eight);
        return foul(state, cue, onBreak, "The 8-ball dropped too early.");
      }
      state.winner = foe;
      state.log = cue ? "Lost. The 8-ball and the cue ball both dropped." : "Lost. The 8-ball was pocketed too early.";
      state.scores = remainingScores(state);
      return state;
    }
    state.winner = me;
    state.log = "8-ball. Rack won.";
    state.scores = remainingScores(state);
    return state;
  }

  let bad = "";
  if (cue) bad = "Scratch.";
  else if (!first) bad = "The cue ball hit nothing.";
  else if (state.phase === "play" && group) {
    const eightOn = !state.balls.some((b) => !b.pocketed && b.kind === group);
    const ok = eightOn ? first.kind === "eight" : first.kind === group;
    if (!ok) bad = eightOn ? "The 8-ball was not hit first." : "The cue ball hit the wrong group first.";
  } else if (!cue && first.kind === "eight" && state.phase !== "break") {
    bad = "The 8-ball was hit first.";
  }
  if (bad) return foul(state, cue, onBreak, bad);

  let assigned = false;
  if (!state.groups[me] && (solids.length || stripes.length)) {
    const pick: Group = solids.length === stripes.length ? (solids[0] ? "solid" : "stripe") : solids.length > stripes.length ? "solid" : "stripe";
    state.groups[me] = pick;
    if (state.seats.length > 1) state.groups[foe] = pick === "solid" ? "stripe" : "solid";
    state.phase = "play";
    assigned = true;
  } else if (state.phase === "break") state.phase = "open";

  const own = state.groups[me];
  const kept = Boolean(own && potted.some((b) => b.kind === own));
  state.scores = remainingScores(state);
  if ((assigned || kept) && state.seats.length > 1) {
    state.log = `${own === "solid" ? "Solids" : "Stripes"}. Still your shot.`;
    return state;
  }
  if (state.seats.length === 1) {
    state.log = potted.length ? "Ball down. Shoot again." : "Miss.";
    return state;
  }
  state.turn = foe;
  state.log = "Turn over.";
  return state;
}

function foul(state: SnookerState, cue: TableBall | undefined, onBreak: boolean, why: string): SnookerState {
  if (cue) {
    cue.pocketed = true;
    cue.vx = 0;
    cue.vy = 0;
  }
  state.ballInHand = true;
  state.kitchen = onBreak;
  if (state.phase === "break") state.phase = "open";
  if (state.seats.length > 1) state.turn = (state.turn + 1) % state.seats.length;
  state.scores = remainingScores(state);
  state.log = `Foul. ${why} ${onBreak ? "Ball in hand behind the line." : "Ball in hand anywhere."}`;
  return state;
}

function remainingScores(state: SnookerState) {
  return state.seats.map((_, index) => {
    const group = state.groups[index];
    if (!group) return 7;
    return state.balls.filter((b) => !b.pocketed && b.kind === group).length;
  });
}

function respot(state: SnookerState, ball: TableBall) {
  ball.pocketed = false;
  ball.vx = 0;
  ball.vy = 0;
  let x = 700;
  let y = 225;
  for (let n = 0; n < 16; n++) {
    const blocked = state.balls.some((other) => other !== ball && !other.pocketed && Math.hypot(other.x - x, other.y - y) < R * 2);
    if (!blocked) break;
    x += R * 2;
  }
  ball.x = x;
  ball.y = y;
}

function clone(state: SnookerState): SnookerState {
  return {
    ...state,
    scores: [...state.scores],
    groups: [...state.groups],
    balls: state.balls.map((b) => ({ ...b })),
  };
}

function clamp(n: number) {
  return Math.max(-1, Math.min(1, n));
}

function stepUntilRest(balls: TableBall[], hit: { id: string | null }) {
  const dt = 1 / 120;
  for (let i = 0; i < 120 * 8; i++) {
    step(balls, dt, [], hit);
    if (balls.every((b) => b.pocketed || Math.hypot(b.vx, b.vy) < 4)) {
      for (const b of balls) {
        b.vx = 0;
        b.vy = 0;
      }
      return;
    }
  }
}

export type TableEvent = "pocket" | "cushion" | "collide";

export function tickTable(balls: TableBall[], dt: number): TableEvent[] {
  const events: TableEvent[] = [];
  step(balls, dt, events);
  return events;
}

function step(balls: TableBall[], dt: number, events: TableEvent[] = [], hit?: { id: string | null }) {
  for (const b of balls) {
    if (b.pocketed) continue;
    if (b.kind === "cue" && Math.abs(b.spin) > 0.04) {
      const speed = Math.hypot(b.vx, b.vy);
      if (speed > 12) {
        const ang = Math.atan2(b.vy, b.vx) + b.spin * 0.55 * dt;
        b.vx = Math.cos(ang) * speed;
        b.vy = Math.sin(ang) * speed;
        b.spin *= Math.exp(-1.6 * dt);
      }
    }
    b.x += b.vx * dt;
    b.y += b.vy * dt;
    const damp = Math.exp(-1.15 * dt);
    b.vx *= damp;
    b.vy *= damp;
    for (const p of POCKETS) {
      if (Math.hypot(b.x - p.x, b.y - p.y) < 20) {
        b.pocketed = true;
        b.vx = 0;
        b.vy = 0;
        events.push("pocket");
      }
    }
    const close = POCKETS.some((p) => Math.hypot(b.x - p.x, b.y - p.y) < 36);
    if (!b.pocketed && !close) {
      const speed = Math.hypot(b.vx, b.vy);
      if (b.x < 48) {
        b.x = 48;
        b.vx = Math.abs(b.vx) * 0.82;
        if (speed > 70) events.push("cushion");
      }
      if (b.x > 852) {
        b.x = 852;
        b.vx = -Math.abs(b.vx) * 0.82;
        if (speed > 70) events.push("cushion");
      }
      if (b.y < 48) {
        b.y = 48;
        b.vy = Math.abs(b.vy) * 0.82;
        if (speed > 70) events.push("cushion");
      }
      if (b.y > 402) {
        b.y = 402;
        b.vy = -Math.abs(b.vy) * 0.82;
        if (speed > 70) events.push("cushion");
      }
    }
  }
  for (let pass = 0; pass < 3; pass++) {
    for (let i = 0; i < balls.length; i++) {
      for (let j = i + 1; j < balls.length; j++) {
        if (pass === 0 && collide(balls[i], balls[j], hit)) events.push("collide");
        else if (pass > 0) collide(balls[i], balls[j], hit);
      }
    }
  }
}

function collide(a: TableBall, b: TableBall, hit?: { id: string | null }): boolean {
  if (a.pocketed || b.pocketed) return false;
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const dist = Math.hypot(dx, dy) || 0.001;
  const min = R * 2;
  if (dist >= min) return false;
  const nx = dx / dist;
  const ny = dy / dist;
  const overlap = min - dist;
  a.x -= nx * overlap * 0.5;
  a.y -= ny * overlap * 0.5;
  b.x += nx * overlap * 0.5;
  b.y += ny * overlap * 0.5;
  if (hit && hit.id === null) {
    if (a.kind === "cue") hit.id = b.id;
    else if (b.kind === "cue") hit.id = a.id;
  }
  const rel = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny;
  if (rel > 0) return false;
  const impulse = (-1.86 * rel) / 2;
  a.vx -= impulse * nx;
  a.vy -= impulse * ny;
  b.vx += impulse * nx;
  b.vy += impulse * ny;
  const cue = a.kind === "cue" ? a : b.kind === "cue" ? b : null;
  const other = cue === a ? b : cue === b ? a : null;
  if (cue && other && (cue.spin || cue.follow)) {
    const sign = cue === a ? 1 : -1;
    const tx = -ny * sign;
    const ty = nx * sign;
    other.vx += (nx * sign * cue.follow + tx * cue.spin) * 55;
    other.vy += (ny * sign * cue.follow + ty * cue.spin) * 55;
    cue.vx += (-nx * sign * cue.follow + tx * cue.spin) * 40;
    cue.vy += (-ny * sign * cue.follow + ty * cue.spin) * 40;
    cue.spin = 0;
    cue.follow = 0;
  }
  return Math.abs(impulse) > 18;
}
