export type Shape = "circle" | "triangle" | "cross" | "square" | "star" | "whot";

export type WhotCard = { id: string; shape: Shape; n: number };

export type WhotState = {
  seats: string[];
  hands: WhotCard[][];
  draw: WhotCard[];
  discard: WhotCard[];
  turn: number;
  shape: Shape;
  pending: number;
  demand: 0 | 2 | 5;
  winner: number | "draw" | null;
  log: string;
};

export const WHOT_RULES =
  "SAM BN Lagos table: match the called shape or the number. 1 is Hold On and 8 is Suspension (next player sits out). 2 is Pick Two and can be stacked with another 2. 5 is Pick Three and can be stacked with another 5. 14 is General Market. Whot 20 is the only wild card — call the next shape, including Star. Stars are a normal suit, not wild.";

export type WhotAction =
  | { type: "play"; cardId: string; call?: Shape }
  | { type: "draw" };

const SHAPES: Shape[] = ["circle", "triangle", "cross", "square"];

function shuffle<T>(list: T[]): T[] {
  const a = [...list];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function deck(): WhotCard[] {
  const cards: WhotCard[] = [];
  let i = 0;
  const push = (shape: Shape, n: number) => {
    cards.push({ id: `${shape}-${n}-${i++}`, shape, n });
  };
  for (const shape of ["circle", "triangle", "cross", "square"] as Shape[]) {
    for (const n of [1, 2, 3, 4, 5, 7, 8, 10, 11, 12, 13, 14]) push(shape, n);
  }
  for (const n of [1, 2, 3, 4, 5, 7, 8]) push("star", n);
  for (let w = 0; w < 5; w++) push("whot", 20);
  return shuffle(cards);
}

export function initialWhot(seats: string[]): WhotState {
  const pile = deck();
  const hands = seats.map(() => [] as WhotCard[]);
  for (let r = 0; r < 5; r++) {
    for (let s = 0; s < seats.length; s++) hands[s].push(pile.pop()!);
  }
  let top = pile.pop()!;
  while (top.shape === "whot" && pile.length) {
    pile.unshift(top);
    top = pile.pop()!;
  }
  return {
    seats,
    hands,
    draw: pile,
    discard: [top],
    turn: 0,
    shape: top.shape,
    pending: 0,
    demand: 0,
    winner: null,
    log: "Match the shape or the number. Whot 20 calls the next shape.",
  };
}

function top(state: WhotState): WhotCard {
  return state.discard[state.discard.length - 1];
}

function pull(state: WhotState, seat: number, n: number) {
  for (let i = 0; i < n; i++) {
    if (state.draw.length === 0) {
      const keep = state.discard.pop();
      state.draw = shuffle(state.discard);
      state.discard = keep ? [keep] : [];
    }
    const card = state.draw.pop();
    if (!card) return;
    state.hands[seat].push(card);
  }
}

function advance(state: WhotState, steps: number) {
  const n = state.seats.length;
  state.turn = (state.turn + steps) % n;
}

export function playable(state: WhotState, card: WhotCard): boolean {
  const demand = state.demand ?? 0;
  if (demand === 2) return card.n === 2;
  if (demand === 5) return card.n === 5;
  if (card.shape === "whot") return true;
  return card.shape === state.shape || card.n === top(state).n;
}

export function applyWhot(state: WhotState, seat: number, action: WhotAction): WhotState {
  if (state.winner !== null) throw new Error("This Whot match is over.");
  if (seat !== state.turn) throw new Error("It is not your turn.");
  const next: WhotState = {
    ...state,
    hands: state.hands.map((h) => [...h]),
    draw: [...state.draw],
    discard: [...state.discard],
  };
  if (action.type === "draw") {
    const n = next.demand ? next.pending : 1;
    pull(next, seat, n);
    next.pending = 0;
    next.demand = 0;
    next.log = n > 1 ? `Picked ${n}.` : "Drew a card.";
    advance(next, 1);
    return next;
  }
  const idx = next.hands[seat].findIndex((c) => c.id === action.cardId);
  if (idx < 0) throw new Error("You do not have that card.");
  const card = next.hands[seat][idx];
  if (!playable(next, card)) throw new Error("That card does not match.");
  if (card.shape === "whot" && next.hands[seat].length > 0 && !action.call) {
    throw new Error("Call a shape for Whot.");
  }
  next.hands[seat].splice(idx, 1);
  next.discard.push(card);
  if (next.hands[seat].length === 0) {
    next.winner = seat;
    next.log = "Hand cleared.";
    return next;
  }
  if (card.shape === "whot") {
    const called = action.call && action.call !== "whot" ? action.call : "circle";
    next.shape = called;
    next.demand = 0;
    next.pending = 0;
    next.log = `Whot. Shape is now ${next.shape}.`;
    advance(next, 1);
    return next;
  }
  next.shape = card.shape;
  if (card.n === 1 || card.n === 8) {
    next.demand = 0;
    next.pending = 0;
    next.log = card.n === 1 ? "Hold on. Next player sits out." : "Suspension. Next player sits out.";
    advance(next, 2);
    return next;
  }
  if (card.n === 2) {
    next.pending += 2;
    next.demand = 2;
    next.log = `Pick two. ${next.pending} cards waiting.`;
    advance(next, 1);
    return next;
  }
  if (card.n === 5) {
    next.pending += 3;
    next.demand = 5;
    next.log = `Pick three. ${next.pending} cards waiting.`;
    advance(next, 1);
    return next;
  }
  if (card.n === 14) {
    next.demand = 0;
    next.pending = 0;
    for (let s = 0; s < next.seats.length; s++) if (s !== seat) pull(next, s, 1);
    next.log = "General market. Everyone else picks one.";
    advance(next, 1);
    return next;
  }
  next.demand = 0;
  next.pending = 0;
  next.log = `Played ${card.shape} ${card.n}.`;
  advance(next, 1);
  return next;
}

export function aiWhot(state: WhotState): WhotAction {
  const hand = state.hands[state.turn];
  const options = hand.filter((c) => playable(state, c));
  if (!options.length) return { type: "draw" };
  const plain = options.find((c) => c.shape !== "whot" && c.n !== 1 && c.n !== 2 && c.n !== 5 && c.n !== 8 && c.n !== 14);
  const card = plain ?? options[0];
  if (card.shape === "whot") {
    const counts = new Map<Shape, number>();
    for (const c of hand) {
      if (c.shape === "whot") continue;
      counts.set(c.shape, (counts.get(c.shape) ?? 0) + 1);
    }
    let call: Shape = "circle";
    let best = -1;
    for (const shape of [...SHAPES, "star"] as Shape[]) {
      const n = counts.get(shape) ?? 0;
      if (n > best) {
        best = n;
        call = shape;
      }
    }
    return { type: "play", cardId: card.id, call };
  }
  return { type: "play", cardId: card.id };
}
