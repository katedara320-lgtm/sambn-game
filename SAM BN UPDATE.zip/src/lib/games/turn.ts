import { aiMove, applyMove, initialChess, seatToMove, type ChessState } from "./chess";
import { aiLudo, applyLudo, initialLudo, type LudoAction, type LudoState } from "./ludo";
import { aiSnooker, applySnooker, rackSnooker, type SnookerAction, type SnookerState } from "./snooker";
import { aiWhot, applyWhot, initialWhot, type WhotAction, type WhotState } from "./whot";
import { applySnakes, initialSnakes, type SnakesState } from "./snakes";
import { aiZono, applyZono, initialZono, type ZonoAction, type ZonoState } from "./zonopoly";

export type TurnState =
  | { game: "chess"; chess: ChessState }
  | { game: "whot"; whot: WhotState }
  | { game: "snakes"; snakes: SnakesState }
  | { game: "zonopoly"; zono: ZonoState }
  | { game: "ludo"; ludo: LudoState }
  | { game: "snooker"; snooker: SnookerState };

export function isTurnGame(slug: string): boolean {
  return slug === "chess" || slug === "whot" || slug === "snakes" || slug === "zonopoly" || slug === "ludo" || slug === "snooker";
}

export function initialTurn(slug: string, seats: string[]): TurnState {
  if (slug === "chess") {
    if (seats.length !== 2) throw new Error("Chess needs two players.");
    return { game: "chess", chess: initialChess([seats[0], seats[1]]) };
  }
  if (slug === "whot") return { game: "whot", whot: initialWhot(seats) };
  if (slug === "snakes") return { game: "snakes", snakes: initialSnakes(seats) };
  if (slug === "zonopoly") return { game: "zonopoly", zono: initialZono(seats) };
  if (slug === "ludo") return { game: "ludo", ludo: initialLudo(seats) };
  if (slug === "snooker") return { game: "snooker", snooker: rackSnooker(seats.length > 2 ? seats.slice(0, 2) : seats) };
  throw new Error("This game is not turn-based.");
}

export function turnSeat(state: TurnState): string | null {
  if (state.game === "chess") {
    if (state.chess.winner) return null;
    return seatToMove(state.chess);
  }
  if (state.game === "whot") {
    if (state.whot.winner !== null) return null;
    return state.whot.seats[state.whot.turn];
  }
  if (state.game === "snakes") {
    if (state.snakes.winner !== null) return null;
    return state.snakes.seats[state.snakes.turn];
  }
  if (state.game === "ludo") {
    if (state.ludo.winner !== null) return null;
    return state.ludo.seats[state.ludo.turn];
  }
  if (state.game === "snooker") {
    if (state.snooker.winner !== null) return null;
    return state.snooker.seats[state.snooker.turn];
  }
  if (state.zono.winner !== null || state.zono.phase === "done") return null;
  return state.zono.seats[state.zono.turn];
}

export function applyTurn(state: TurnState, userId: string, action: unknown): TurnState {
  const seatId = turnSeat(state);
  if (!seatId) throw new Error("This match is over.");
  if (seatId === "ai") {
    if (userId !== "ai" && (action as { type?: string })?.type !== "ai") {
      throw new Error("The computer is thinking.");
    }
    return stepAi(state);
  }
  if (seatId !== userId) throw new Error("It is not your turn.");
  if (state.game === "chess") {
    const move = action as { from?: number; to?: number };
    if (typeof move.from !== "number" || typeof move.to !== "number") throw new Error("Pick a move.");
    return { game: "chess", chess: applyMove(state.chess, { from: move.from, to: move.to }) };
  }
  if (state.game === "whot") {
    const act = action as WhotAction;
    const seat = state.whot.seats.indexOf(userId);
    return { game: "whot", whot: applyWhot(state.whot, seat, act) };
  }
  if (state.game === "snakes") {
    const seat = state.snakes.seats.indexOf(userId);
    return { game: "snakes", snakes: applySnakes(state.snakes, seat) };
  }
  if (state.game === "ludo") {
    const seat = state.ludo.seats.indexOf(userId);
    return { game: "ludo", ludo: applyLudo(state.ludo, seat, action as LudoAction) };
  }
  if (state.game === "snooker") {
    const seat = state.snooker.seats.indexOf(userId);
    const shot = action as SnookerAction;
    if (shot.type !== "shot") throw new Error("Take a shot.");
    return { game: "snooker", snooker: applySnooker(state.snooker, seat, shot) };
  }
  const seat = state.zono.seats.indexOf(userId);
  return { game: "zonopoly", zono: applyZono(state.zono, seat, action as ZonoAction) };
}

export function stepAi(state: TurnState): TurnState {
  if (turnSeat(state) !== "ai") return state;
  if (state.game === "chess") {
    const move = aiMove(state.chess);
    if (!move) return state;
    return { game: "chess", chess: applyMove(state.chess, move) };
  }
  if (state.game === "whot") {
    const seat = state.whot.turn;
    return { game: "whot", whot: applyWhot(state.whot, seat, aiWhot(state.whot)) };
  }
  if (state.game === "snakes") {
    return { game: "snakes", snakes: applySnakes(state.snakes, state.snakes.turn) };
  }
  if (state.game === "ludo") {
    const action = aiLudo(state.ludo);
    return { game: "ludo", ludo: applyLudo(state.ludo, state.ludo.turn, action) };
  }
  if (state.game === "snooker") {
    return { game: "snooker", snooker: applySnooker(state.snooker, state.snooker.turn, aiSnooker(state.snooker)) };
  }
  return { game: "zonopoly", zono: applyZono(state.zono, state.zono.turn, aiZono(state.zono)) };
}

export function matchResultFor(
  state: TurnState,
  userId: string,
): { result: "win" | "loss" | "draw"; detail: string; opponent: string } | null {
  if (state.game === "chess") {
    if (!state.chess.winner) return null;
    const meWhite = state.chess.seats[0] === userId;
    const opponent = meWhite ? state.chess.seats[1] : state.chess.seats[0];
    if (state.chess.winner === "draw") return { result: "draw", detail: state.chess.reason || "Draw", opponent };
    const won = (state.chess.winner === "w" && meWhite) || (state.chess.winner === "b" && !meWhite);
    return { result: won ? "win" : "loss", detail: state.chess.reason || "Checkmate", opponent };
  }
  if (state.game === "whot") {
    if (state.whot.winner === null) return null;
    const me = state.whot.seats.indexOf(userId);
    const opponent = state.whot.seats.find((s) => s !== userId) ?? "ai";
    if (state.whot.winner === "draw") return { result: "draw", detail: "Draw", opponent };
    return { result: state.whot.winner === me ? "win" : "loss", detail: "Whot", opponent };
  }
  if (state.game === "snakes") {
    if (state.snakes.winner === null) return null;
    const me = state.snakes.seats.indexOf(userId);
    const opponent = state.snakes.seats.find((s) => s !== userId) ?? "ai";
    return { result: state.snakes.winner === me ? "win" : "loss", detail: "Reached 100", opponent };
  }
  if (state.game === "ludo") {
    if (state.ludo.winner === null) return null;
    const me = state.ludo.seats.indexOf(userId);
    const opponent = state.ludo.seats.find((s) => s !== userId) ?? "ai";
    return { result: state.ludo.winner === me ? "win" : "loss", detail: "All tokens home", opponent };
  }
  if (state.game === "snooker") {
    if (state.snooker.winner === null) return null;
    const me = state.snooker.seats.indexOf(userId);
    const opponent = state.snooker.seats.find((s) => s !== userId) ?? "Practice";
    if (state.snooker.winner === "draw") return { result: "draw", detail: state.snooker.log, opponent };
    return {
      result: state.snooker.winner === me ? "win" : "loss",
      detail: state.snooker.log,
      opponent,
    };
  }
  if (state.zono.winner === null) return null;
  const me = state.zono.seats.indexOf(userId);
  const opponent = state.zono.seats.find((s) => s !== userId) ?? "ai";
  return {
    result: state.zono.winner === me ? "win" : "loss",
    detail: `${state.zono.money[me]} saved`,
    opponent,
  };
}
