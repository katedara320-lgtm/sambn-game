import type { Pad } from "./pad";

export type Car = {
  x: number;
  y: number;
  angle: number;
  speed: number;
  lap: number;
  cp: number;
  done: boolean;
};

export type RaceState = {
  cars: [Car, Car];
  time: number;
  over: boolean;
  winner: 0 | 1 | null;
};

const LAPS = 3;

export function createRace(): RaceState {
  return {
    cars: [car(400, 240, 0), car(460, 240, 0)],
    time: 0,
    over: false,
    winner: null,
  };
}

function car(x: number, y: number, angle: number): Car {
  return { x, y, angle, speed: 0, lap: 0, cp: 0, done: false };
}

export function stepRace(state: RaceState, dt: number, me: Pad, opp: Pad | "ai") {
  if (state.over) return;
  state.time += dt;
  drive(state.cars[0], dt, me.x, me.y < -0.2 || me.shoot ? 1 : me.y > 0.35 ? -0.7 : 0);
  if (opp === "ai") {
    const target = checkpointAngle(state.cars[1].cp);
    let diff = target - state.cars[1].angle;
    while (diff > Math.PI) diff -= Math.PI * 2;
    while (diff < -Math.PI) diff += Math.PI * 2;
    drive(state.cars[1], dt, Math.max(-1, Math.min(1, diff * 1.6)), 0.85);
  } else {
    drive(state.cars[1], dt, opp.x, opp.y < -0.2 || opp.shoot ? 1 : opp.y > 0.35 ? -0.7 : 0);
  }
  bump(state.cars[0], state.cars[1]);
  if (state.cars[0].done || state.cars[1].done) {
    state.over = true;
    state.winner = state.cars[0].done && (!state.cars[1].done || state.cars[0].lap >= state.cars[1].lap) ? 0 : 1;
    if (state.cars[0].done && state.cars[1].done) state.winner = 0;
  }
}

function drive(c: Car, dt: number, steer: number, throttle: number) {
  if (c.done) return;
  const off = offTrack(c.x, c.y);
  const grip = off ? 0.45 : 1;
  c.angle += steer * 2.2 * dt * grip * (0.35 + Math.min(1, Math.abs(c.speed) / 220));
  const accel = throttle > 0 ? 280 : throttle < 0 ? -220 : -40;
  c.speed += accel * dt;
  const max = off ? 140 : 320;
  c.speed = Math.max(-80, Math.min(max, c.speed));
  c.speed *= Math.exp((off ? -1.8 : -0.25) * dt);
  c.x += Math.cos(c.angle) * c.speed * dt;
  c.y += Math.sin(c.angle) * c.speed * dt;
  c.x = Math.max(20, Math.min(940, c.x));
  c.y = Math.max(20, Math.min(460, c.y));
  const progress = progressOf(c.x, c.y);
  const gate = c.cp % 4;
  const target = gate * 0.25;
  const delta = (progress - target + 1) % 1;
  if (delta < 0.18 && c.speed > 40) {
    c.cp += 1;
    if (c.cp > 0 && c.cp % 4 === 0) c.lap += 1;
    if (c.lap >= LAPS) c.done = true;
  }
}

function bump(a: Car, b: Car) {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const dist = Math.hypot(dx, dy) || 0.001;
  if (dist > 28) return;
  const nx = dx / dist;
  const ny = dy / dist;
  const overlap = 28 - dist;
  a.x -= nx * overlap * 0.5;
  a.y -= ny * overlap * 0.5;
  b.x += nx * overlap * 0.5;
  b.y += ny * overlap * 0.5;
  a.speed *= 0.7;
  b.speed *= 0.7;
}

export function offTrack(x: number, y: number) {
  const nx = (x - 480) / 340;
  const ny = (y - 240) / 150;
  const d = nx * nx + ny * ny;
  return d < 0.42 || d > 1.15;
}

function progressOf(x: number, y: number) {
  const ang = Math.atan2(y - 240, x - 480);
  return (ang + Math.PI) / (Math.PI * 2);
}

function checkpointAngle(cp: number) {
  return -Math.PI + (cp % 4) * (Math.PI / 2) + 0.2;
}

export function racePlace(state: RaceState, index: 0 | 1) {
  const me = state.cars[index].cp;
  const them = state.cars[index === 0 ? 1 : 0].cp;
  return me >= them ? 1 : 2;
}
