export type Color = "w" | "b";

export type ChessMove = { from: number; to: number; promo?: "Q" | "R" | "B" | "N" };

export type ChessState = {
  board: string;
  turn: Color;
  castling: string;
  ep: number | null;
  halfmove: number;
  seats: [string, string];
  winner: Color | "draw" | null;
  reason: string;
  history: string[];
};

const KNIGHT: [number, number][] = [
  [-2, -1],
  [-2, 1],
  [-1, -2],
  [-1, 2],
  [1, -2],
  [1, 2],
  [2, -1],
  [2, 1],
];
const KING: [number, number][] = [
  [-1, -1],
  [-1, 0],
  [-1, 1],
  [0, -1],
  [0, 1],
  [1, -1],
  [1, 0],
  [1, 1],
];
const BISHOP: [number, number][] = [
  [-1, -1],
  [-1, 1],
  [1, -1],
  [1, 1],
];
const ROOK: [number, number][] = [
  [-1, 0],
  [1, 0],
  [0, -1],
  [0, 1],
];

const START = "rnbqkbnr" + "pppppppp" + ".".repeat(32) + "PPPPPPPP" + "RNBQKBNR";

export function initialChess(seats: [string, string]): ChessState {
  const state: ChessState = {
    board: START,
    turn: "w",
    castling: "KQkq",
    ep: null,
    halfmove: 0,
    seats,
    winner: null,
    reason: "",
    history: [],
  };
  state.history = [keyOf(state)];
  return state;
}

export function sqName(i: number): string {
  return "abcdefgh"[i % 8] + String(8 - Math.floor(i / 8));
}

function keyOf(s: Pick<ChessState, "board" | "turn" | "castling" | "ep">): string {
  return `${s.board} ${s.turn} ${s.castling} ${s.ep ?? "-"}`;
}

function white(p: string): boolean {
  return p >= "A" && p <= "Z";
}

export function pieceColor(p: string): Color | null {
  if (p === "." || !p) return null;
  return white(p) ? "w" : "b";
}

function opp(c: Color): Color {
  return c === "w" ? "b" : "w";
}

function on(r: number, c: number): boolean {
  return r >= 0 && r < 8 && c >= 0 && c < 8;
}

function setAt(board: string, i: number, ch: string): string {
  return board.slice(0, i) + ch + board.slice(i + 1);
}

export function kingSquare(board: string, color: Color): number {
  return board.indexOf(color === "w" ? "K" : "k");
}

export function isAttacked(board: string, sq: number, by: Color): boolean {
  const row = Math.floor(sq / 8);
  const col = sq % 8;
  const pawnRow = by === "w" ? row + 1 : row - 1;
  if (pawnRow >= 0 && pawnRow < 8) {
    for (const dc of [-1, 1]) {
      const c = col + dc;
      if (c < 0 || c > 7) continue;
      const p = board[pawnRow * 8 + c];
      if (by === "w" && p === "P") return true;
      if (by === "b" && p === "p") return true;
    }
  }
  for (const [dr, dc] of KNIGHT) {
    const r = row + dr;
    const c = col + dc;
    if (!on(r, c)) continue;
    const p = board[r * 8 + c];
    if ((by === "w" && p === "N") || (by === "b" && p === "n")) return true;
  }
  for (const [dr, dc] of KING) {
    const r = row + dr;
    const c = col + dc;
    if (!on(r, c)) continue;
    const p = board[r * 8 + c];
    if ((by === "w" && p === "K") || (by === "b" && p === "k")) return true;
  }
  const slide = (dirs: [number, number][], rook: boolean) => {
    for (const [dr, dc] of dirs) {
      let r = row + dr;
      let c = col + dc;
      while (on(r, c)) {
        const p = board[r * 8 + c];
        if (p !== ".") {
          const mine = pieceColor(p) === by;
          const kind = p.toLowerCase();
          if (mine && (kind === "q" || (rook ? kind === "r" : kind === "b"))) return true;
          break;
        }
        r += dr;
        c += dc;
      }
    }
    return false;
  };
  return slide(ROOK, true) || slide(BISHOP, false);
}

function pseudo(state: ChessState): ChessMove[] {
  const { board, turn } = state;
  const moves: ChessMove[] = [];
  const dir = turn === "w" ? -1 : 1;
  const startRow = turn === "w" ? 6 : 1;
  const promoRow = turn === "w" ? 0 : 7;
  for (let i = 0; i < 64; i++) {
    const p = board[i];
    if (pieceColor(p) !== turn) continue;
    const row = Math.floor(i / 8);
    const col = i % 8;
    const kind = p.toLowerCase();
    const push = (r: number, c: number, promo?: ChessMove["promo"]) => {
      if (!on(r, c)) return;
      const t = r * 8 + c;
      const target = board[t];
      if (target !== "." && pieceColor(target) === turn) return;
      moves.push({ from: i, to: t, promo });
    };
    if (kind === "p") {
      const r1 = row + dir;
      if (on(r1, col) && board[r1 * 8 + col] === ".") {
        if (r1 === promoRow) push(r1, col, "Q");
        else {
          push(r1, col);
          const r2 = row + dir * 2;
          if (row === startRow && board[r2 * 8 + col] === ".") push(r2, col);
        }
      }
      for (const dc of [-1, 1]) {
        const c = col + dc;
        if (!on(r1, c)) continue;
        const t = r1 * 8 + c;
        const target = board[t];
        const canCap = target !== "." && pieceColor(target) !== turn;
        const canEp = state.ep === t;
        if (canCap || canEp) {
          if (r1 === promoRow) push(r1, c, "Q");
          else push(r1, c);
        }
      }
    } else if (kind === "n") {
      for (const [dr, dc] of KNIGHT) push(row + dr, col + dc);
    } else if (kind === "k") {
      for (const [dr, dc] of KING) push(row + dr, col + dc);
      const rights = state.castling;
      if (turn === "w" && i === 60 && !isAttacked(board, 60, "b")) {
        if (rights.includes("K") && board[61] === "." && board[62] === "." && board[63] === "R") {
          if (!isAttacked(board, 61, "b") && !isAttacked(board, 62, "b")) moves.push({ from: 60, to: 62 });
        }
        if (rights.includes("Q") && board[59] === "." && board[58] === "." && board[57] === "." && board[56] === "R") {
          if (!isAttacked(board, 59, "b") && !isAttacked(board, 58, "b")) moves.push({ from: 60, to: 58 });
        }
      }
      if (turn === "b" && i === 4 && !isAttacked(board, 4, "w")) {
        if (rights.includes("k") && board[5] === "." && board[6] === "." && board[7] === "r") {
          if (!isAttacked(board, 5, "w") && !isAttacked(board, 6, "w")) moves.push({ from: 4, to: 6 });
        }
        if (rights.includes("q") && board[3] === "." && board[2] === "." && board[1] === "." && board[0] === "r") {
          if (!isAttacked(board, 3, "w") && !isAttacked(board, 2, "w")) moves.push({ from: 4, to: 2 });
        }
      }
    } else {
      const dirs = kind === "b" ? BISHOP : kind === "r" ? ROOK : [...BISHOP, ...ROOK];
      for (const [dr, dc] of dirs) {
        let r = row + dr;
        let c = col + dc;
        while (on(r, c)) {
          const t = r * 8 + c;
          const target = board[t];
          if (target === ".") push(r, c);
          else {
            if (pieceColor(target) !== turn) push(r, c);
            break;
          }
          r += dr;
          c += dc;
        }
      }
    }
  }
  return moves;
}

function applyRaw(state: ChessState, move: ChessMove): ChessState {
  let board = state.board;
  const piece = board[move.from];
  const captured = board[move.to];
  const kind = piece.toLowerCase();
  board = setAt(board, move.from, ".");
  let placed = piece;
  if (kind === "p" && (Math.floor(move.to / 8) === 0 || Math.floor(move.to / 8) === 7)) {
    placed = state.turn === "w" ? "Q" : "q";
  }
  board = setAt(board, move.to, placed);
  if (kind === "p" && state.ep === move.to && captured === ".") {
    const cap = state.turn === "w" ? move.to + 8 : move.to - 8;
    board = setAt(board, cap, ".");
  }
  if (kind === "k" && Math.abs((move.to % 8) - (move.from % 8)) === 2) {
    if (move.to === 62) {
      board = setAt(board, 63, ".");
      board = setAt(board, 61, "R");
    } else if (move.to === 58) {
      board = setAt(board, 56, ".");
      board = setAt(board, 59, "R");
    } else if (move.to === 6) {
      board = setAt(board, 7, ".");
      board = setAt(board, 5, "r");
    } else if (move.to === 2) {
      board = setAt(board, 0, ".");
      board = setAt(board, 3, "r");
    }
  }
  let castling = state.castling;
  const drop = (ch: string) => {
    castling = castling.replace(ch, "");
  };
  if (piece === "K") {
    drop("K");
    drop("Q");
  }
  if (piece === "k") {
    drop("k");
    drop("q");
  }
  if (move.from === 63 || move.to === 63) drop("K");
  if (move.from === 56 || move.to === 56) drop("Q");
  if (move.from === 7 || move.to === 7) drop("k");
  if (move.from === 0 || move.to === 0) drop("q");
  let ep: number | null = null;
  if (kind === "p" && Math.abs(Math.floor(move.to / 8) - Math.floor(move.from / 8)) === 2) {
    ep = (Math.floor(move.from / 8) + Math.floor(move.to / 8)) / 2 * 8 + (move.from % 8);
  }
  const halfmove = kind === "p" || captured !== "." ? 0 : state.halfmove + 1;
  return {
    ...state,
    board,
    turn: opp(state.turn),
    castling,
    ep,
    halfmove,
    winner: null,
    reason: "",
  };
}

export function legalMoves(state: ChessState): ChessMove[] {
  if (state.winner) return [];
  const out: ChessMove[] = [];
  for (const move of pseudo(state)) {
    const next = applyRaw(state, move);
    const king = kingSquare(next.board, state.turn);
    if (king >= 0 && !isAttacked(next.board, king, next.turn)) out.push(move);
  }
  return out;
}

function insufficient(board: string): boolean {
  const pieces = [...board].filter((p) => p !== "." && p.toLowerCase() !== "k");
  if (pieces.length === 0) return true;
  if (pieces.length === 1 && (pieces[0].toLowerCase() === "n" || pieces[0].toLowerCase() === "b")) return true;
  return false;
}

export function applyMove(state: ChessState, move: ChessMove): ChessState {
  const allowed = legalMoves(state).some((m) => m.from === move.from && m.to === move.to);
  if (!allowed) throw new Error("That move is not legal.");
  const next = applyRaw(state, move);
  const key = keyOf(next);
  const history = [...state.history, key].slice(-80);
  next.history = history;
  const replies = legalMoves(next);
  const inCheck = isAttacked(next.board, kingSquare(next.board, next.turn), opp(next.turn));
  if (replies.length === 0) {
    if (inCheck) {
      next.winner = state.turn;
      next.reason = "Checkmate";
    } else {
      next.winner = "draw";
      next.reason = "Stalemate";
    }
  } else if (next.halfmove >= 100) {
    next.winner = "draw";
    next.reason = "Fifty-move rule";
  } else if (history.filter((h) => h === key).length >= 3) {
    next.winner = "draw";
    next.reason = "Threefold repetition";
  } else if (insufficient(next.board)) {
    next.winner = "draw";
    next.reason = "Insufficient material";
  }
  return next;
}

const VALUE: Record<string, number> = { p: 100, n: 320, b: 330, r: 500, q: 900, k: 0 };

function evalSide(state: ChessState): number {
  if (state.winner === "draw") return 0;
  if (state.winner === state.turn) return 100000;
  if (state.winner) return -100000;
  let score = 0;
  for (const ch of state.board) {
    const v = VALUE[ch.toLowerCase()] ?? 0;
    if (!v) continue;
    score += white(ch) ? v : -v;
  }
  return state.turn === "w" ? score : -score;
}

function negamax(state: ChessState, depth: number): number {
  if (depth === 0 || state.winner) return evalSide(state);
  const moves = legalMoves(state);
  if (!moves.length) return evalSide(state);
  let best = -Infinity;
  for (const move of moves) {
    const score = -negamax(applyRawChecked(state, move), depth - 1);
    if (score > best) best = score;
  }
  return best;
}

function applyRawChecked(state: ChessState, move: ChessMove): ChessState {
  const next = applyRaw(state, move);
  const replies = legalMoves(next);
  const inCheck = isAttacked(next.board, kingSquare(next.board, next.turn), opp(next.turn));
  if (replies.length === 0) {
    next.winner = inCheck ? state.turn : "draw";
  }
  return next;
}

export function aiMove(state: ChessState): ChessMove | null {
  const moves = legalMoves(state);
  if (!moves.length) return null;
  const ranked = moves.map((m) => ({ m, s: -negamax(applyRawChecked(state, m), 1) }));
  ranked.sort((a, b) => b.s - a.s);
  const band = ranked.filter((x) => x.s >= ranked[0].s - 12);
  return band[Math.floor(Math.random() * band.length)].m;
}

export function seatToMove(state: ChessState): string {
  return state.turn === "w" ? state.seats[0] : state.seats[1];
}
