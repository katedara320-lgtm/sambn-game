import type { Pad } from "./pad";

export type Mover = { x: number; y: number; vx: number; vy: number };

export type Pitch = {
  me: Mover;
  opp: Mover;
  ball: Mover;
  meScore: number;
  oppScore: number;
  time: number;
  over: boolean;
};

export function createPitch(): Pitch {
  return {
    me: { x: 220, y: 240, vx: 0, vy: 0 },
    opp: { x: 740, y: 240, vx: 0, vy: 0 },
    ball: { x: 480, y: 240, vx: 0, vy: 0 },
    meScore: 0,
    oppScore: 0,
    time: 90,
    over: false,
  };
}

function clamp(n: number, a: number, b: number) {
  return Math.max(a, Math.min(b, n));
}

function kick(player: Mover, ball: Mover, pressed: boolean, dir: number) {
  if (!pressed) return;
  if (Math.hypot(player.x - ball.x, player.y - ball.y) > 42) return;
  const speed = Math.hypot(player.vx, player.vy);
  const ang = speed > 20 ? Math.atan2(player.vy, player.vx) : dir > 0 ? 0 : Math.PI;
  ball.vx = Math.cos(ang) * 460;
  ball.vy = Math.sin(ang) * 460;
}

function resetPitch(s: Pitch, toMe: boolean) {
  s.ball.x = 480;
  s.ball.y = 240;
  s.ball.vx = toMe ? -80 : 80;
  s.ball.vy = 0;
  s.me.x = 220;
  s.me.y = 240;
  s.opp.x = 740;
  s.opp.y = 240;
}

/** Host-side pitch. `opp` is the computer, or the other phone's pad. Never both. */
export function stepPitch(s: Pitch, dt: number, me: Pad, opp: Pad | "ai") {
  if (s.over) return;
  s.me.vx = me.x * 230;
  s.me.vy = me.y * 230;
  s.me.x = clamp(s.me.x + s.me.vx * dt, 40, 920);
  s.me.y = clamp(s.me.y + s.me.vy * dt, 36, 444);
  if (opp === "ai") {
    const defend = s.ball.x > 520;
    const tx = defend ? s.ball.x + 16 : 700;
    const ty = s.ball.y;
    const adx = tx - s.opp.x;
    const ady = ty - s.opp.y;
    const am = Math.hypot(adx, ady) || 1;
    s.opp.vx = (adx / am) * 185;
    s.opp.vy = (ady / am) * 185;
    s.opp.x = clamp(s.opp.x + s.opp.vx * dt, 40, 920);
    s.opp.y = clamp(s.opp.y + s.opp.vy * dt, 36, 444);
    kick(s.opp, s.ball, Math.hypot(s.opp.x - s.ball.x, s.opp.y - s.ball.y) < 40, -1);
  } else {
    s.opp.vx = opp.x * 230;
    s.opp.vy = opp.y * 230;
    s.opp.x = clamp(s.opp.x + s.opp.vx * dt, 40, 920);
    s.opp.y = clamp(s.opp.y + s.opp.vy * dt, 36, 444);
    kick(s.opp, s.ball, opp.shoot, -1);
  }
  kick(s.me, s.ball, me.shoot, 1);
  s.ball.x += s.ball.vx * dt;
  s.ball.y += s.ball.vy * dt;
  s.ball.vx *= Math.exp(-1.3 * dt);
  s.ball.vy *= Math.exp(-1.3 * dt);
  if (s.ball.y < 28 || s.ball.y > 452) s.ball.vy *= -0.8;
  s.ball.y = clamp(s.ball.y, 28, 452);
  if (s.ball.x < 18 && s.ball.y > 170 && s.ball.y < 310) {
    s.oppScore += 1;
    resetPitch(s, true);
  } else if (s.ball.x > 942 && s.ball.y > 170 && s.ball.y < 310) {
    s.meScore += 1;
    resetPitch(s, false);
  } else if (s.ball.x < 24 || s.ball.x > 936) {
    s.ball.vx *= -0.8;
    s.ball.x = clamp(s.ball.x, 24, 936);
  }
  s.time -= dt;
  if (s.meScore >= 3 || s.oppScore >= 3 || s.time <= 0) s.over = true;
}
