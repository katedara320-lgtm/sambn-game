/** SAM BN Ludo. Four tokens, a 6 to leave the yard, exact finish, safe starts, and captures. */

export type LudoState = {
  seats: string[];
  tokens: number[][];
  turn: number;
  phase: "roll" | "move";
  dice: number;
  sixes: number;
  winner: number | null;
  log: string;
};

export type LudoAction = { type: "roll" } | { type: "move"; token: number };

export const PATH: [number, number][] = [
  [1, 6], [2, 6], [3, 6], [4, 6], [5, 6], [6, 5], [6, 4], [6, 3], [6, 2], [6, 1], [6, 0],
  [7, 0], [8, 0], [8, 1], [8, 2], [8, 3], [8, 4], [8, 5], [9, 6], [10, 6], [11, 6], [12, 6], [13, 6], [14, 6],
  [14, 7], [14, 8], [13, 8], [12, 8], [11, 8], [10, 8], [9, 8], [8, 9], [8, 10], [8, 11], [8, 12], [8, 13], [8, 14],
  [7, 14], [6, 14], [6, 13], [6, 12], [6, 11], [6, 10], [6, 9], [5, 8], [4, 8], [3, 8], [2, 8], [1, 8], [0, 8],
  [0, 7], [0, 6],
];

export const HOMES: [number, number][][] = [
  [[1, 7], [2, 7], [3, 7], [4, 7], [5, 7], [6, 7]],
  [[7, 1], [7, 2], [7, 3], [7, 4], [7, 5], [7, 6]],
  [[13, 7], [12, 7], [11, 7], [10, 7], [9, 7], [8, 7]],
  [[7, 13], [7, 12], [7, 11], [7, 10], [7, 9], [7, 8]],
];

export const YARDS: [number, number][][] = [
  [[1, 2], [2, 2], [1, 3], [2, 3]],
  [[12, 2], [13, 2], [12, 3], [13, 3]],
  [[12, 11], [13, 11], [12, 12], [13, 12]],
  [[1, 11], [2, 11], [1, 12], [2, 12]],
];

export const LUDO_COLORS = ["#ff2d8a", "#3dffb0", "#f5c16c", "#7eb6ff"];

const STARTS = [0, 13, 26, 39];
const SAFE = new Set([0, 8, 13, 21, 26, 34, 39, 47]);

export function initialLudo(seats: string[]): LudoState {
  if (seats.length < 2 || seats.length > 4) throw new Error("Ludo needs 2 to 4 players.");
  return {
    seats,
    tokens: seats.map(() => [-1, -1, -1, -1]),
    turn: 0,
    phase: "roll",
    dice: 0,
    sixes: 0,
    winner: null,
    log: "Roll a 6 to leave the yard.",
  };
}

export function tokenCell(seat: number, pos: number, token: number): [number, number] {
  if (pos < 0) return YARDS[seat][token];
  if (pos >= 100) return HOMES[seat][pos - 100] ?? HOMES[seat][5];
  const index = (STARTS[seat] + pos) % 52;
  return PATH[index];
}

function trackIndex(seat: number, steps: number) {
  return (STARTS[seat] + steps) % 52;
}

function occupied(state: LudoState, seat: number, pos: number, ignore: number) {
  return state.tokens[seat].some((p, i) => i !== ignore && p === pos);
}

function othersOn(state: LudoState, seat: number, steps: number) {
  const index = trackIndex(seat, steps);
  const hits: { seat: number; token: number }[] = [];
  for (let s = 0; s < state.seats.length; s++) {
    if (s === seat) continue;
    state.tokens[s].forEach((p, token) => {
      if (p >= 0 && p < 100 && trackIndex(s, p) === index) hits.push({ seat: s, token });
    });
  }
  return hits;
}

export function legalTokens(state: LudoState): number[] {
  if (state.phase !== "move" || state.winner !== null) return [];
  const seat = state.turn;
  const dice = state.dice;
  const out: number[] = [];
  for (let i = 0; i < 4; i++) {
    const pos = state.tokens[seat][i];
    if (pos < 0) {
      if (dice === 6 && !occupied(state, seat, 0, i)) out.push(i);
      continue;
    }
    if (pos >= 105) continue;
    if (pos >= 100) {
      const next = pos + dice;
      if (next <= 105 && !occupied(state, seat, next === 105 ? 105 : next, i)) out.push(i);
      continue;
    }
    const next = pos + dice;
    if (next > 50) {
      const home = next - 51;
      if (home > 5) continue;
      const stored = 100 + home;
      if (!occupied(state, seat, stored, i)) out.push(i);
      continue;
    }
    if (occupied(state, seat, next, i)) continue;
    const foes = othersOn(state, seat, next);
    if (foes.length > 1) continue;
    out.push(i);
  }
  return out;
}

function pass(state: LudoState, log: string) {
  state.phase = "roll";
  state.dice = 0;
  state.sixes = 0;
  state.turn = (state.turn + 1) % state.seats.length;
  state.log = log;
}

export function applyLudo(state: LudoState, seat: number, action: LudoAction, rng: () => number = Math.random): LudoState {
  if (state.winner !== null) throw new Error("This Ludo match is over.");
  if (seat !== state.turn) throw new Error("It is not your turn.");
  const next: LudoState = {
    ...state,
    tokens: state.tokens.map((row) => [...row]),
  };
  if (action.type === "roll") {
    if (next.phase !== "roll") throw new Error("Move a token first.");
    const dice = 1 + Math.floor(rng() * 6);
    next.dice = dice;
    if (dice === 6) next.sixes += 1;
    else next.sixes = 0;
    if (next.sixes >= 3) {
      pass(next, "Three sixes. The turn passes.");
      return next;
    }
    next.phase = "move";
    if (!legalTokens(next).length) {
      pass(next, `Rolled ${dice}. No legal move.`);
      return next;
    }
    next.log = `Rolled ${dice}.`;
    return next;
  }
  if (next.phase !== "move") throw new Error("Roll the dice first.");
  const token = action.token;
  if (!legalTokens(next).includes(token)) throw new Error("That token cannot move.");
  const pos = next.tokens[seat][token];
  const dice = next.dice;
  let captured = false;
  if (pos < 0) next.tokens[seat][token] = 0;
  else if (pos >= 100) next.tokens[seat][token] = pos + dice;
  else if (pos + dice > 50) next.tokens[seat][token] = 100 + (pos + dice - 51);
  else {
    const landed = pos + dice;
    next.tokens[seat][token] = landed;
    const foes = othersOn(next, seat, landed);
    const index = trackIndex(seat, landed);
    if (foes.length === 1 && !SAFE.has(index)) {
      next.tokens[foes[0].seat][foes[0].token] = -1;
      captured = true;
    }
  }
  if (next.tokens[seat].every((p) => p >= 105)) {
    next.winner = seat;
    next.phase = "roll";
    next.log = "All four tokens are home.";
    return next;
  }
  if (dice === 6) {
    next.phase = "roll";
    next.dice = 0;
    next.log = captured ? "Captured, and you rolled a 6. Roll again." : "You rolled a 6. Roll again.";
    return next;
  }
  pass(next, captured ? "Captured. Next player." : "Next player.");
  return next;
}

export function aiLudo(state: LudoState, rng: () => number = Math.random): LudoAction {
  if (state.phase === "roll") return { type: "roll" };
  const options = legalTokens(state);
  let best = options[0] ?? 0;
  let score = -1;
  for (const token of options) {
    const trial = applyLudo(state, state.turn, { type: "move", token }, rng);
    const mine = trial.tokens[state.turn][token];
    const value = (trial.log.startsWith("Captured") ? 50 : 0) + (mine < 0 ? 0 : mine);
    if (value > score) {
      score = value;
      best = token;
    }
  }
  return { type: "move", token: best };
}
