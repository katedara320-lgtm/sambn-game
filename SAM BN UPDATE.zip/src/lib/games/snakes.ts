export type SnakesState = {
  seats: string[];
  pos: number[];
  turn: number;
  dice: number;
  winner: number | null;
  log: string;
};

export const LADDERS: Record<number, number> = {
  4: 14,
  9: 31,
  21: 42,
  28: 84,
  36: 44,
  51: 67,
  71: 91,
  80: 100,
};

export const SNAKES: Record<number, number> = {
  16: 6,
  47: 26,
  49: 11,
  56: 53,
  62: 19,
  64: 60,
  87: 24,
  93: 73,
  95: 75,
  98: 78,
};

export function initialSnakes(seats: string[]): SnakesState {
  return {
    seats,
    pos: seats.map(() => 0),
    turn: 0,
    dice: 0,
    winner: null,
    log: "Roll the dice. Ladders climb, snakes slide. Land exactly on 100.",
  };
}

export function applySnakes(state: SnakesState, seat: number): SnakesState {
  if (state.winner !== null) throw new Error("This game is over.");
  if (seat !== state.turn) throw new Error("It is not your turn.");
  const dice = 1 + Math.floor(Math.random() * 6);
  const next: SnakesState = { ...state, pos: [...state.pos], dice };
  let land = next.pos[seat] + dice;
  if (land > 100) {
    next.log = `Rolled ${dice}. Need an exact roll to finish.`;
    next.turn = (seat + 1) % next.seats.length;
    return next;
  }
  let note = `Rolled ${dice} and landed on ${land}.`;
  if (LADDERS[land]) {
    land = LADDERS[land];
    note = `Rolled ${dice}. Ladder to ${land}.`;
  } else if (SNAKES[land]) {
    land = SNAKES[land];
    note = `Rolled ${dice}. Snake down to ${land}.`;
  }
  next.pos[seat] = land;
  if (land === 100) {
    next.winner = seat;
    next.log = "Reached 100.";
    return next;
  }
  next.log = note;
  next.turn = (seat + 1) % next.seats.length;
  return next;
}
