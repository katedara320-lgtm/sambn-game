export type Pad = {
  x: number;
  y: number;
  shoot: boolean;
  aimX: number;
  aimY: number;
  fire: boolean;
  at: number;
  /** Radians per second. Used by the shooter look stick and mouse. */
  turn?: number;
  reload?: boolean;
  crouch?: boolean;
  jump?: boolean;
  /** Weapon index 0-4. Omit to keep the current weapon. */
  slot?: number;
};

export function freshPad(): Pad {
  return { x: 0, y: 0, shoot: false, aimX: 0, aimY: 0, fire: false, at: 0 };
}

/** Ignore a pad that has not been refreshed recently so a dropped packet cannot hold SHOOT forever. */
export function livePad(pad: Pad, now: number): Pad {
  if (!pad.at || now - pad.at > 500) return { ...freshPad(), at: pad.at };
  return pad;
}
