export type TileKind = "go" | "city" | "tax" | "chance" | "rest";

export type Tile = { name: string; kind: TileKind; price: number };

export const TILES: Tile[] = [
  { name: "Go", kind: "go", price: 0 },
  { name: "Lagos Market", kind: "city", price: 120 },
  { name: "Chance", kind: "chance", price: 0 },
  { name: "Accra Port", kind: "city", price: 120 },
  { name: "Fuel Levy", kind: "tax", price: 80 },
  { name: "Nairobi Rail", kind: "city", price: 200 },
  { name: "Kigali Hills", kind: "city", price: 160 },
  { name: "Chance", kind: "chance", price: 0 },
  { name: "Cairo Corniche", kind: "city", price: 180 },
  { name: "Dakar Shore", kind: "city", price: 180 },
  { name: "Rest Stop", kind: "rest", price: 0 },
  { name: "Joburg Reef", kind: "city", price: 220 },
  { name: "Community", kind: "chance", price: 0 },
  { name: "Addis Ridge", kind: "city", price: 220 },
  { name: "Customs", kind: "tax", price: 120 },
  { name: "Cape Line", kind: "city", price: 260 },
  { name: "Kumasi Square", kind: "city", price: 260 },
  { name: "Chance", kind: "chance", price: 0 },
  { name: "Abuja Centre", kind: "city", price: 300 },
  { name: "Harbour Tax", kind: "tax", price: 150 },
];

const CHANCES = [
  { text: "Market day. Collect 80.", money: 80 },
  { text: "Fuel hike. Pay 60.", money: -60 },
  { text: "Family visit. Collect 50.", money: 50 },
  { text: "Festival weekend. Collect 100.", money: 100 },
  { text: "Broken axle. Pay 40.", money: -40 },
];

export type ZonoState = {
  seats: string[];
  money: number[];
  pos: number[];
  owner: (number | null)[];
  upgrade: boolean[];
  out: boolean[];
  turn: number;
  phase: "roll" | "buy" | "end" | "done";
  dice: [number, number];
  log: string;
  winner: number | null;
};

export type ZonoAction = { type: "roll" } | { type: "buy" } | { type: "pass" } | { type: "upgrade" } | { type: "end" };

export function initialZono(seats: string[]): ZonoState {
  return {
    seats,
    money: seats.map(() => 1200),
    pos: seats.map(() => 0),
    owner: TILES.map(() => null),
    upgrade: TILES.map(() => false),
    out: seats.map(() => false),
    turn: 0,
    phase: "roll",
    dice: [0, 0],
    log: "Roll, buy cities, and be the last one standing — or the first to 2500.",
    winner: null,
  };
}

function nextTurn(state: ZonoState) {
  const n = state.seats.length;
  for (let i = 1; i <= n; i++) {
    const s = (state.turn + i) % n;
    if (!state.out[s]) {
      state.turn = s;
      state.phase = "roll";
      return;
    }
  }
}

function checkWinner(state: ZonoState) {
  const alive = state.seats.map((_, i) => i).filter((i) => !state.out[i]);
  const rich = alive.find((i) => state.money[i] >= 2500);
  if (rich !== undefined) {
    state.winner = rich;
    state.phase = "done";
    state.log = "Reached 2500. Empire secured.";
    return;
  }
  if (alive.length === 1) {
    state.winner = alive[0];
    state.phase = "done";
    state.log = "Last player standing.";
  }
}

function bust(state: ZonoState, seat: number) {
  state.out[seat] = true;
  state.money[seat] = 0;
  state.owner = state.owner.map((o) => (o === seat ? null : o));
  state.upgrade = state.upgrade.map((u, i) => (state.owner[i] === null ? false : u));
  checkWinner(state);
}

function charge(state: ZonoState, from: number, amount: number, to: number | null) {
  if (amount <= 0) return;
  if (state.money[from] >= amount) {
    state.money[from] -= amount;
    if (to !== null) state.money[to] += amount;
    return;
  }
  if (to !== null) state.money[to] += state.money[from];
  state.money[from] = 0;
  bust(state, from);
}

export function rentOf(state: ZonoState, tile: number): number {
  const tileInfo = TILES[tile];
  if (tileInfo.kind !== "city") return 0;
  const base = Math.round(tileInfo.price * 0.28);
  return state.upgrade[tile] ? base * 2 : base;
}

export function applyZono(state: ZonoState, seat: number, action: ZonoAction): ZonoState {
  if (state.phase === "done" || state.winner !== null) throw new Error("This match is over.");
  if (seat !== state.turn) throw new Error("It is not your turn.");
  const next: ZonoState = {
    ...state,
    money: [...state.money],
    pos: [...state.pos],
    owner: [...state.owner],
    upgrade: [...state.upgrade],
    out: [...state.out],
    dice: [...state.dice] as [number, number],
  };
  if (action.type === "roll") {
    if (next.phase !== "roll") throw new Error("You already rolled.");
    const a = 1 + Math.floor(Math.random() * 6);
    const b = 1 + Math.floor(Math.random() * 6);
    next.dice = [a, b];
    const steps = a + b;
    const prev = next.pos[seat];
    const land = (prev + steps) % TILES.length;
    if (prev + steps >= TILES.length) {
      next.money[seat] += 200;
    }
    next.pos[seat] = land;
    const tile = TILES[land];
    next.log = `Rolled ${a}+${b}. ${tile.name}.`;
    if (tile.kind === "tax") {
      charge(next, seat, tile.price, null);
      next.log = `${tile.name}. Paid ${tile.price}.`;
    } else if (tile.kind === "chance") {
      const card = CHANCES[Math.floor(Math.random() * CHANCES.length)];
      if (card.money >= 0) next.money[seat] += card.money;
      else charge(next, seat, -card.money, null);
      next.log = card.text;
    } else if (tile.kind === "city") {
      const owner = next.owner[land];
      if (owner === null) {
        next.phase = next.money[seat] >= tile.price ? "buy" : "end";
        if (next.phase === "end") next.log = `${tile.name} is for sale, but you cannot afford it.`;
        else next.log = `${tile.name} is unowned. Buy for ${tile.price}?`;
        checkWinner(next);
        return next;
      }
      if (owner !== seat && !next.out[owner]) {
        const rent = rentOf(next, land);
        charge(next, seat, rent, owner);
        next.log = `Rent ${rent} on ${tile.name}.`;
      } else if (owner === seat && !next.upgrade[land] && next.money[seat] >= Math.round(tile.price / 2)) {
        next.phase = "buy";
        next.log = `You own ${tile.name}. Upgrade for ${Math.round(tile.price / 2)}?`;
        return next;
      }
    }
    next.phase = next.winner !== null ? "done" : "end";
    checkWinner(next);
    return next;
  }
  if (action.type === "buy" || action.type === "upgrade") {
    if (next.phase !== "buy") throw new Error("Nothing to buy.");
    const land = next.pos[seat];
    const tile = TILES[land];
    if (next.owner[land] === null) {
      if (next.money[seat] < tile.price) throw new Error("Not enough money.");
      next.money[seat] -= tile.price;
      next.owner[land] = seat;
      next.log = `Bought ${tile.name}.`;
    } else if (next.owner[land] === seat && !next.upgrade[land]) {
      const cost = Math.round(tile.price / 2);
      if (next.money[seat] < cost) throw new Error("Not enough money to upgrade.");
      next.money[seat] -= cost;
      next.upgrade[land] = true;
      next.log = `Upgraded ${tile.name}. Rent doubled.`;
    }
    next.phase = "end";
    checkWinner(next);
    return next;
  }
  if (action.type === "pass") {
    if (next.phase !== "buy") throw new Error("Nothing to pass.");
    next.phase = "end";
    next.log = "Passed.";
    return next;
  }
  if (next.phase !== "end") throw new Error("Finish the turn first.");
  nextTurn(next);
  checkWinner(next);
  return next;
}

export function aiZono(state: ZonoState): ZonoAction {
  if (state.phase === "roll") return { type: "roll" };
  if (state.phase === "buy") {
    const land = state.pos[state.turn];
    const tile = TILES[land];
    if (state.owner[land] === null && state.money[state.turn] - tile.price >= 180) return { type: "buy" };
    if (state.owner[land] === state.turn && state.money[state.turn] >= Math.round(tile.price / 2) + 200) {
      return { type: "upgrade" };
    }
    return { type: "pass" };
  }
  return { type: "end" };
}
