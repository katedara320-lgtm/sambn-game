import { createFileRoute, Navigate } from "@tanstack/react-router";
import { LandscapeStage } from "@/components/landscape";
import { ActionMatch, TurnMatch } from "@/components/play-match";
import { gameBySlug } from "@/lib/sambn/catalog";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/play/$slug")({
  validateSearch: (search: Record<string, unknown>) => ({
    room: typeof search.room === "string" ? search.room.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8) : "",
  }),
  component: PlayPage,
});

function PlayPage() {
  const { slug } = Route.useParams();
  const { room } = Route.useSearch();
  const game = gameBySlug(slug);
  const { user, isPending } = useCurrentUserState();
  if (!game) return <p className="p-6">Unknown game.</p>;
  if (isPending) {
    return (
      <LandscapeStage title={game.name} backTo={`/games/${slug}`} pause={slug !== "snooker"}>
        <p className="grid h-full place-items-center">Loading…</p>
      </LandscapeStage>
    );
  }
  if (!user) return <Navigate to="/login" search={{ redirect: `/play/${slug}` }} />;
  return (
    <LandscapeStage title={game.name} backTo={room ? `/room/${room}` : `/games/${slug}`} pause={slug !== "snooker"}>
      {game.mode === "turn" || (slug === "snooker" && room) ? (
        <TurnMatch slug={slug} code={room} userId={user.id} />
      ) : (
        <ActionMatch slug={slug} code={room} userId={user.id} />
      )}
    </LandscapeStage>
  );
}
