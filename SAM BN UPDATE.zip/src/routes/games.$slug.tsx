import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { gameBySlug, isRealtimeDuel } from "@/lib/sambn/catalog";
import { createRoom } from "@/lib/sambn/api";
import { HostGame } from "@/components/host-game";
import { OpenRooms } from "@/components/open-rooms";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { errText } from "@/components/ui";

export const Route = createFileRoute("/games/$slug")({ component: GamePage });

function GamePage() {
  const { slug } = Route.useParams();
  const game = gameBySlug(slug);
  const navigate = useNavigate();
  const { user, isPending } = useCurrentUserState();
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [hosting, setHosting] = useState(false);

  if (!game) {
    return (
      <p>
        That game is not on SAM BN. <Link to="/games">Back to games</Link>
      </p>
    );
  }

  function goLogin() {
    void navigate({ to: "/login", search: { redirect: `/games/${game?.slug ?? ""}` } });
  }

  async function playComputer() {
    if (!user) {
      goLogin();
      return;
    }
    if (game!.mode === "turn" || game!.slug === "snooker") {
      setBusy(true);
      setError("");
      try {
        const room = await createRoom({ data: { slug: game!.slug, withAi: true } });
        void navigate({ to: "/play/$slug", params: { slug: game!.slug }, search: { room: room.code } });
      } catch (err) {
        setError(errText(err));
        setBusy(false);
      }
      return;
    }
    void navigate({ to: "/play/$slug", params: { slug: game!.slug }, search: { room: "" } });
  }

  const duel = isRealtimeDuel(game.slug);
  const soloOnly = game.slug === "adventure";

  return (
    <div className="space-y-4">
      <Link to="/games" className="text-sm text-muted">
        ← Back to games
      </Link>
      <div className="overflow-hidden rounded-3xl border border-line">
        <img src={game.image} alt="" className="h-52 w-full object-cover" />
        <div className="space-y-3 bg-panel p-4">
          <p className="text-xs uppercase tracking-widest text-pink">{game.tag}</p>
          <h1 className="font-display text-4xl font-extrabold">{game.name}</h1>
          <p>{game.blurb}</p>
          <p className="text-sm leading-relaxed text-muted">{game.honest}</p>
          <p className="text-sm text-gold">Opens in landscape. If the phone stays upright, you will be asked to rotate it.</p>
          {isPending ? <div className="h-11 animate-pulse rounded-xl bg-ink" /> : null}
          {!isPending ? (
            <div className="flex flex-wrap gap-2">
              <button type="button" disabled={busy} onClick={() => void playComputer()} className="min-h-11 rounded-xl bg-pink px-4 font-bold text-ink disabled:opacity-50">
                {game.slug === "snooker" ? "Play the computer" : "Play against computer"}
              </button>
              {game.slug === "snooker" ? (
                <button
                  type="button"
                  className="min-h-11 rounded-xl border border-line px-4 font-semibold"
                  onClick={() => {
                    if (!user) {
                      goLogin();
                      return;
                    }
                    void navigate({ to: "/play/$slug", params: { slug: game.slug }, search: { room: "" } });
                  }}
                >
                  Practice alone
                </button>
              ) : null}
              {soloOnly ? null : (
                <button type="button" onClick={() => setHosting((open) => !open)} className="min-h-11 rounded-xl border border-line px-4 font-semibold">
                  {duel || game.mode === "turn" || game.slug === "snooker" ? "Play against a player" : "Host a score room"}
                </button>
              )}
            </div>
          ) : null}
          {error ? <p className="text-sm text-pink-2">{error}</p> : null}
        </div>
      </div>
      {hosting ? <HostGame initialSlug={game.slug} /> : null}
      {soloOnly ? null : (
        <div className="space-y-2 rounded-3xl border border-line bg-panel p-4">
          <p className="font-display text-xl font-extrabold">Play online</p>
          <p className="text-sm text-muted">Public rooms for this game. Tap Join. A full room cannot be entered.</p>
          <OpenRooms slug={game.slug} />
        </div>
      )}
    </div>
  );
}
