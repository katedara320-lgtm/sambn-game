import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { GAMES } from "@/lib/sambn/catalog";
import { getHome } from "@/lib/sambn/api";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { GameCard, Panel } from "@/components/ui";

export const Route = createFileRoute("/")({ component: HomePage });

function HomePage() {
  const { user, isPending } = useCurrentUserState();
  const [stats, setStats] = useState<{ online: number; players: number; matchesToday: number; myMatches: number; top: { username: string; displayName: string; wins: number }[] } | null>(null);

  useEffect(() => {
    if (isPending || !user) return;
    let cancel = false;
    getHome()
      .then((home) => {
        if (!cancel) setStats(home);
      })
      .catch(() => undefined);
    return () => {
      cancel = true;
    };
  }, [isPending, user?.id]);

  return (
    <div className="space-y-5">
      <section className="rise relative overflow-hidden rounded-3xl border border-line bg-panel">
        <img src="/art/hero.jpg" alt="" className="h-64 w-full object-cover sm:h-80" />
        <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/80 to-transparent" />
        <div className="absolute inset-0 flex flex-col justify-end p-5 sm:p-8">
          <p className="text-xs font-semibold uppercase tracking-widest text-pink">Welcome to</p>
          <h1 className="font-display text-4xl font-extrabold sm:text-6xl">
            SAM <span className="text-pink">BN</span>
          </h1>
          <p className="text-sm font-semibold uppercase tracking-widest text-gold">Africa's Finest</p>
          <p className="mt-2 max-w-md text-sm text-fg">Games are better together. Play. Chat. Compete.</p>
          <div className="mt-4">
            {isPending ? <span className="inline-block h-11 w-36 animate-pulse rounded-xl bg-panel-2" /> : null}
            {!isPending && user ? (
              <Link to="/games" className="inline-flex min-h-11 items-center rounded-xl bg-pink px-4 font-bold text-ink">
                Start playing
              </Link>
            ) : null}
            {!isPending && !user ? (
              <Link to="/login" className="inline-flex min-h-11 items-center rounded-xl bg-pink px-4 font-bold text-ink">
                Sign in to play
              </Link>
            ) : null}
          </div>
        </div>
      </section>
      <div>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-display text-xl font-bold">Game lobby</h2>
          <Link to="/games" className="text-sm text-pink">
            View all
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
          {GAMES.slice(0, 6).map((game) => (
            <GameCard key={game.slug} game={game} />
          ))}
        </div>
      </div>
      <div className="grid gap-3 md:grid-cols-2">
        <Panel className="p-4">
          <p className="text-xs uppercase tracking-widest text-muted">Lobby</p>
          <div className="mt-3 grid grid-cols-2 gap-3 text-sm">
            <Stat label="Online now" value={stats ? String(stats.online) : "—"} />
            <Stat label="Players" value={stats ? String(stats.players) : "—"} />
            <Stat label="Matches today" value={stats ? String(stats.matchesToday) : "—"} />
            <Stat label="Your matches" value={stats ? String(stats.myMatches) : "—"} />
          </div>
          {!user && !isPending ? <p className="mt-3 text-sm text-muted">Sign in and these numbers are the real lobby, not a fake crowd.</p> : null}
        </Panel>
        <Panel className="p-4">
          <p className="text-xs uppercase tracking-widest text-muted">Top players</p>
          <ol className="mt-3 space-y-2">
            {(stats?.top ?? []).map((player, index) => (
              <li key={player.username} className="flex items-center justify-between text-sm">
                <Link to="/u/$username" params={{ username: player.username }} className="font-semibold">
                  {index + 1}. {player.displayName}
                </Link>
                <span className="text-gold">{player.wins} wins</span>
              </li>
            ))}
            {!stats?.top.length ? <li className="text-sm text-muted">No ranked wins yet. Be the first.</li> : null}
          </ol>
        </Panel>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-ink px-3 py-3">
      <p className="text-xs text-muted">{label}</p>
      <p className="font-display text-2xl font-extrabold">{value}</p>
    </div>
  );
}
