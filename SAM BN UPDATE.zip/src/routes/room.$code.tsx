import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Copy } from "lucide-react";
import {
  getRoom,
  inviteFriend,
  leaveRoom,
  listFriends,
  sendRoomMessage,
  setReady,
  startRoom,
  type RoomView,
} from "@/lib/sambn/api";
import { gameBySlug, isRealtimeDuel } from "@/lib/sambn/catalog";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { Avatar, errText } from "@/components/ui";

export const Route = createFileRoute("/room/$code")({ component: RoomPage });

function RoomPage() {
  const { code } = Route.useParams();
  const { user, isPending } = useCurrentUserState();
  const navigate = useNavigate();
  const [room, setRoom] = useState<RoomView | null>(null);
  const [error, setError] = useState("");
  const [chat, setChat] = useState("");
  const [friends, setFriends] = useState<{ username: string; displayName: string; avatarHue: number }[]>([]);
  const [copied, setCopied] = useState(false);
  const entered = useRef(false);

  function enterMatch(gameSlug: string, roomCode: string) {
    const key = `sambn-entered-${roomCode}`;
    sessionStorage.setItem(key, "1");
    entered.current = true;
    void navigate({ to: "/play/$slug", params: { slug: gameSlug }, search: { room: roomCode } });
  }

  useEffect(() => {
    if (!user) return;
    let cancel = false;
    const tick = () => {
      getRoom({ data: { code } })
        .then((next) => {
          if (!cancel) setRoom(next);
        })
        .catch((err) => {
          if (!cancel) setError(errText(err));
        });
    };
    tick();
    const id = window.setInterval(tick, 2000);
    listFriends()
      .then((rows) => {
        if (!cancel) setFriends(rows.filter((row) => row.status === "accepted"));
      })
      .catch(() => undefined);
    return () => {
      cancel = true;
      window.clearInterval(id);
    };
  }, [code, user?.id]);

  useEffect(() => {
    if (!room || room.status !== "live" || entered.current) return;
    if (sessionStorage.getItem(`sambn-entered-${room.code}`)) return;
    entered.current = true;
    sessionStorage.setItem(`sambn-entered-${room.code}`, "1");
    void navigate({ to: "/play/$slug", params: { slug: room.gameSlug }, search: { room: room.code } });
  }, [room, navigate]);

  if (isPending) return <p className="text-muted">Loading room…</p>;
  if (!user) return <RedirectToSignIn />;
  if (!room) return <p className="text-muted">{error || "Finding that room…"}</p>;
  const game = gameBySlug(room.gameSlug);
  const mine = room.members.find((member) => member.userId === user.id);
  const host = room.hostId === user.id;
  const duel = isRealtimeDuel(room.gameSlug);
  const needed = duel ? 2 : room.fillAi ? 1 : room.maxPlayers;
  const canStart = room.members.length >= needed;

  return (
    <div className="space-y-4">
      <Link to="/games/$slug" params={{ slug: room.gameSlug }} className="text-sm text-muted">
        ← Back to {game?.name ?? "games"}
      </Link>
      <div className="overflow-hidden rounded-3xl border border-line">
        <div className="relative h-40">
          <img src={game?.image} alt="" className="h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-ink to-transparent" />
          <div className="absolute bottom-3 left-4">
            <h1 className="font-display text-3xl font-extrabold">{game?.name}</h1>
            <p className="text-sm text-muted">{game?.blurb}</p>
          </div>
          <span className="absolute right-3 top-3 rounded-full bg-pink px-3 py-1 text-xs font-bold text-ink">
            {room.status === "lobby" ? "Lobby" : room.status === "live" ? "Live" : "Finished"}
          </span>
        </div>
        <div className="grid gap-4 bg-panel p-4 lg:grid-cols-[1fr_280px]">
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-3 rounded-2xl border border-line bg-ink p-3">
              <div>
                <p className="text-xs text-muted">Room code</p>
                <p className="font-display text-3xl font-extrabold tracking-widest">{room.code}</p>
              </div>
              <button
                type="button"
                className="inline-flex min-h-11 items-center gap-2 rounded-xl bg-pink px-3 font-bold text-ink"
                onClick={() => {
                  void navigator.clipboard.writeText(room.code).then(() => {
                    setCopied(true);
                    window.setTimeout(() => setCopied(false), 1200);
                  });
                }}
              >
                <Copy className="h-4 w-4" />
                {copied ? "Copied" : "Copy code"}
              </button>
              <p className="text-sm text-muted">
                Private room · {room.members.length}/{room.maxPlayers} players
                {room.members.find((member) => member.host) ? ` · Host ${room.members.find((member) => member.host)?.displayName}` : ""}
              </p>
            </div>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {Array.from({ length: room.maxPlayers }, (_, index) => {
                const member = room.members[index];
                return (
                  <div key={index} className="rounded-2xl border border-line bg-ink p-3 text-center">
                    {member ? (
                      <>
                        <Avatar name={member.displayName} hue={member.avatarHue} online={member.online} />
                        <p className="mt-2 truncate text-sm font-bold">{member.displayName}</p>
                        <p className="text-xs text-muted">{member.host ? "Host" : member.ready ? "Ready" : "In room"}</p>
                      </>
                    ) : (
                      <p className="py-6 text-sm text-muted">Empty slot</p>
                    )}
                  </div>
                );
              })}
            </div>
            <p className="text-sm text-muted">{game?.honest}</p>
            {duel ? <p className="text-sm text-muted">Real 1v1. Start stays locked until a second person joins. No computer is added.</p> : null}
            {game?.mode === "turn" && room.fillAi ? <p className="text-sm text-muted">Empty seats will be the computer, and the board will say Computer.</p> : null}
            {game?.mode === "turn" && !room.fillAi ? <p className="text-sm text-muted">Empty seats stay empty until people join. The computer is not filling them.</p> : null}
            {error ? <p className="text-sm text-pink-2">{error}</p> : null}
            <div className="flex flex-wrap gap-2">
              {room.status === "lobby" && mine ? (
                <button
                  type="button"
                  className="min-h-11 rounded-xl border border-line px-4"
                  onClick={() => {
                    void setReady({ data: { code: room.code, ready: !mine.ready } }).catch((err) => setError(errText(err)));
                  }}
                >
                  {mine.ready ? "Not ready" : "Ready"}
                </button>
              ) : null}
              {room.status === "lobby" && host ? (
                <button
                  type="button"
                  disabled={!canStart}
                  className="min-h-11 rounded-xl bg-pink px-4 font-bold text-ink disabled:opacity-50"
                  onClick={() => {
                    void startRoom({ data: { code: room.code } })
                      .then(() => enterMatch(room.gameSlug, room.code))
                      .catch((err) => setError(errText(err)));
                  }}
                >
                  {canStart ? "Start game" : `Start game (${room.members.length}/${needed})`}
                </button>
              ) : null}
              {room.status === "live" ? (
                <button
                  type="button"
                  className="min-h-11 rounded-xl bg-pink px-4 font-bold text-ink"
                  onClick={() => navigate({ to: "/play/$slug", params: { slug: room.gameSlug }, search: { room: room.code } })}
                >
                  Enter match
                </button>
              ) : null}
              <button
                type="button"
                className="min-h-11 rounded-xl border border-line px-4"
                onClick={() => {
                  void leaveRoom({ data: { code: room.code } }).then(() => navigate({ to: "/games" }));
                }}
              >
                Leave
              </button>
            </div>
            {room.scores.length ? (
              <div>
                <p className="text-sm font-semibold">Scores this room</p>
                <ul className="mt-2 space-y-1 text-sm">
                  {room.scores.map((score) => (
                    <li key={score.userId} className="flex justify-between">
                      <span>{score.displayName}</span>
                      <span>
                        {score.score} · {score.detail}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}
          </div>
          <div className="flex max-h-[28rem] flex-col rounded-2xl border border-line bg-ink">
            <p className="border-b border-line px-3 py-2 text-sm font-semibold">Room chat</p>
            <div className="flex-1 space-y-2 overflow-y-auto p-3">
              {room.messages.map((message) => (
                <p key={message.id} className="text-sm">
                  <span className="font-semibold text-pink">{message.author.displayName}</span> {message.body}
                </p>
              ))}
              {!room.messages.length ? <p className="text-sm text-muted">Say hello. The code is {room.code}.</p> : null}
            </div>
            <form
              className="flex gap-2 border-t border-line p-2"
              onSubmit={(event) => {
                event.preventDefault();
                const body = chat.trim();
                if (!body) return;
                setChat("");
                void sendRoomMessage({ data: { code: room.code, body } }).catch((err) => setError(errText(err)));
              }}
            >
              <input value={chat} onChange={(event) => setChat(event.target.value)} placeholder="Type a message" className="min-h-11 flex-1 rounded-xl bg-panel px-3 outline-none" />
              <button type="submit" className="min-h-11 rounded-xl bg-pink px-3 font-bold text-ink">
                Send
              </button>
            </form>
          </div>
        </div>
      </div>
      <div className="rounded-2xl border border-line bg-panel p-4">
        <p className="font-semibold">Invite friends</p>
        <div className="mt-2 flex flex-wrap gap-2">
          {friends.map((friend) => (
            <button
              key={friend.username}
              type="button"
              className="min-h-11 rounded-full border border-line px-3 text-sm"
              onClick={() => {
                void inviteFriend({ data: { code: room.code, username: friend.username } })
                  .then(() => setError(`Invited ${friend.displayName} in chat.`))
                  .catch((err) => setError(errText(err)));
              }}
            >
              {friend.displayName}
            </button>
          ))}
          {!friends.length ? <p className="text-sm text-muted">Add friends first, then invite them with the room code.</p> : null}
        </div>
      </div>
    </div>
  );
}
