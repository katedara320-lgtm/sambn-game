import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { addComment, createPost, deletePost, listComments, listMatches, listPosts, toggleLike, type PostView } from "@/lib/sambn/api";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { Avatar, ScoreCard, ago, errText } from "@/components/ui";

export const Route = createFileRoute("/community")({ component: CommunityPage });

function CommunityPage() {
  const { user, isPending } = useCurrentUserState();
  const [posts, setPosts] = useState<PostView[]>([]);
  const [body, setBody] = useState("");
  const [error, setError] = useState("");
  const [last, setLast] = useState<{ slug: string; label: string } | null>(null);

  function load() {
    return listPosts()
      .then(setPosts)
      .catch((err) => setError(errText(err)));
  }

  useEffect(() => {
    if (!user) return;
    void load();
    listMatches({ data: { username: "" } })
      .then((res) => {
        const match = res.matches[0];
        if (match) setLast({ slug: match.gameSlug, label: `${match.result} · ${match.detail}` });
      })
      .catch(() => undefined);
  }, [user?.id]);

  if (isPending) return <p className="text-muted">Loading the feed…</p>;
  if (!user) return <RedirectToSignIn />;

  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <h1 className="font-display text-3xl font-extrabold">Community</h1>
      <form
        className="space-y-2 rounded-2xl border border-line bg-panel p-3"
        onSubmit={(event) => {
          event.preventDefault();
          void createPost({ data: { body } })
            .then(() => {
              setBody("");
              return load();
            })
            .catch((err) => setError(errText(err)));
        }}
      >
        <textarea value={body} onChange={(event) => setBody(event.target.value)} placeholder="What happened on the table?" className="min-h-24 w-full rounded-xl bg-ink px-3 py-2 outline-none" />
        <div className="flex flex-wrap gap-2">
          <button type="submit" className="min-h-11 rounded-xl bg-pink px-4 font-bold text-ink">
            Post
          </button>
          {last ? (
            <button
              type="button"
              className="min-h-11 rounded-xl border border-line px-3 text-sm"
              onClick={() => {
                void createPost({ data: { body: body || "Just played.", gameSlug: last.slug, scoreLabel: last.label } })
                  .then(() => {
                    setBody("");
                    return load();
                  })
                  .catch((err) => setError(errText(err)));
              }}
            >
              Share last result
            </button>
          ) : null}
        </div>
      </form>
      {error ? <p className="text-sm text-pink-2">{error}</p> : null}
      {!posts.length ? <p className="text-sm text-muted">The feed is empty. Post the first result.</p> : null}
      {posts.map((post) => (
        <PostCard key={post.id} post={post} onChange={() => void load()} />
      ))}
    </div>
  );
}

function PostCard({ post, onChange }: { post: PostView; onChange: () => void }) {
  const [open, setOpen] = useState(false);
  const [comments, setComments] = useState<{ id: string; body: string; author: { displayName: string; username: string } }[]>([]);
  const [text, setText] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    if (!open) return;
    void listComments({ data: { postId: post.id } }).then(setComments).catch((err) => setError(errText(err)));
  }, [open, post.id]);

  return (
    <article className="rounded-2xl border border-line bg-panel p-4">
      <div className="flex items-center gap-3">
        <Avatar name={post.author.displayName} hue={post.author.avatarHue} />
        <div>
          <Link to="/u/$username" params={{ username: post.author.username }} className="font-semibold">
            {post.author.displayName}
          </Link>
          <p className="text-xs text-muted">{ago(post.createdAt)}</p>
        </div>
        {post.mine ? (
          <button type="button" className="ml-auto text-xs text-muted" onClick={() => void deletePost({ data: { postId: post.id } }).then(onChange)}>
            Delete
          </button>
        ) : null}
      </div>
      <p className="mt-3 whitespace-pre-wrap text-sm">{post.body}</p>
      <ScoreCard slug={post.gameSlug} label={post.scoreLabel} />
      <div className="mt-3 flex gap-3 text-sm">
        <button
          type="button"
          className={post.liked ? "font-bold text-pink" : "text-muted"}
          onClick={() => void toggleLike({ data: { postId: post.id } }).then(onChange)}
        >
          {post.liked ? "Liked" : "Like"} · {post.likes}
        </button>
        <button type="button" className="text-muted" onClick={() => setOpen((value) => !value)}>
          Comments · {post.comments}
        </button>
      </div>
      {open ? (
        <div className="mt-3 space-y-2">
          {comments.map((comment) => (
            <p key={comment.id} className="text-sm">
              <Link to="/u/$username" params={{ username: comment.author.username }} className="font-semibold">
                {comment.author.displayName}
              </Link>{" "}
              {comment.body}
            </p>
          ))}
          <form
            className="flex gap-2"
            onSubmit={(event) => {
              event.preventDefault();
              if (!text.trim()) return;
              void addComment({ data: { postId: post.id, body: text } })
                .then(() => {
                  setText("");
                  return listComments({ data: { postId: post.id } }).then(setComments);
                })
                .then(onChange)
                .catch((err) => setError(errText(err)));
            }}
          >
            <input value={text} onChange={(event) => setText(event.target.value)} placeholder="Comment" className="min-h-11 flex-1 rounded-xl bg-ink px-3 outline-none" />
            <button type="submit" className="min-h-11 rounded-xl bg-pink px-3 font-bold text-ink">
              Send
            </button>
          </form>
          {error ? <p className="text-xs text-pink-2">{error}</p> : null}
        </div>
      ) : null}
    </article>
  );
}
