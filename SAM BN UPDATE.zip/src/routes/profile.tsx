import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { listMatches, updateProfile, type Profile } from "@/lib/sambn/api";
import { gameBySlug } from "@/lib/sambn/catalog";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { RedirectToSignIn, UserButton } from "@/lib/auth/gates";
import { Avatar, Field, ago, errText } from "@/components/ui";
import { audioPrefs, setAudioPrefs, unlockAudio } from "@/lib/audio";

export const Route = createFileRoute("/profile")({ component: ProfilePage });

function ProfilePage() {
  const { user, isPending } = useCurrentUserState();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [matches, setMatches] = useState<{ id: string; gameSlug: string; result: string; detail: string; opponent: string; playedAt: string }[]>([]);
  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [bio, setBio] = useState("");
  const [hue, setHue] = useState(330);
  const [error, setError] = useState("");
  const [saved, setSaved] = useState("");

  useEffect(() => {
    if (!user) return;
    let cancel = false;
    listMatches({ data: { username: "" } })
      .then((page) => {
        if (cancel) return;
        setProfile(page.profile);
        setMatches(page.matches);
        setUsername(page.profile.username);
        setDisplayName(page.profile.displayName);
        setBio(page.profile.bio);
        setHue(page.profile.avatarHue);
      })
      .catch((err) => {
        if (!cancel) setError(errText(err));
      });
    return () => {
      cancel = true;
    };
  }, [user?.id]);

  if (isPending) return <div className="h-40 animate-pulse rounded-3xl bg-panel" />;
  if (!user) return <RedirectToSignIn />;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <Avatar name={displayName || username || "You"} hue={hue} size="lg" />
        <div>
          <h1 className="font-display text-3xl font-extrabold">{displayName || "Your profile"}</h1>
          <p className="text-sm text-muted">
            {profile ? `Level ${profile.level} · ${profile.wins} wins · ${profile.losses} losses` : "SAM BN account"}
          </p>
        </div>
      </div>
      <form
        className="space-y-3 rounded-3xl border border-line bg-panel p-4"
        onSubmit={(event) => {
          event.preventDefault();
          setError("");
          setSaved("");
          void updateProfile({ data: { username, displayName, bio, avatarHue: hue } })
            .then((next) => {
              setProfile(next);
              setSaved("Saved. This account stays on this site.");
            })
            .catch((err) => setError(errText(err)));
        }}
      >
        <Field label="Username" value={username} onChange={setUsername} />
        <Field label="Display name" value={displayName} onChange={setDisplayName} />
        <label className="block space-y-1 text-sm">
          <span className="text-muted">Bio</span>
          <textarea value={bio} onChange={(event) => setBio(event.target.value)} className="min-h-20 w-full rounded-xl border border-line bg-ink px-3 py-2 outline-none" />
        </label>
        <label className="block text-sm text-muted">
          Avatar colour
          <input type="range" min={0} max={359} value={hue} onChange={(event) => setHue(Number(event.target.value))} className="w-full" />
        </label>
        {error ? <p className="text-sm text-pink-2">{error}</p> : null}
        {saved ? <p className="text-sm text-good">{saved}</p> : null}
        <button type="submit" className="min-h-11 rounded-xl bg-pink px-4 font-bold text-ink">
          Save profile
        </button>
      </form>
      <AudioSettings />
      <div>
        <h2 className="font-display text-xl font-bold">Match history</h2>
        {!matches.length ? <p className="mt-2 text-sm text-muted">Finish a game and it shows up here.</p> : null}
        <ul className="mt-2 space-y-2">
          {matches.map((match) => (
            <li key={match.id} className="flex items-center justify-between rounded-xl border border-line bg-panel px-3 py-2 text-sm">
              <span>
                <Link to="/games/$slug" params={{ slug: match.gameSlug }} className="font-semibold">
                  {gameBySlug(match.gameSlug)?.name ?? match.gameSlug}
                </Link>
                <span className="text-muted"> · {match.detail} vs {match.opponent}</span>
              </span>
              <span className={match.result === "win" ? "text-good" : "text-muted"}>
                {match.result} · {ago(match.playedAt)}
              </span>
            </li>
          ))}
        </ul>
      </div>
      <div className="rounded-2xl border border-line bg-panel p-4">
        <UserButton />
      </div>
    </div>
  );
}

function AudioSettings() {
  const [prefs, setPrefs] = useState({ muted: false, sfx: 0.7, music: 0 });
  useEffect(() => setPrefs(audioPrefs()), []);
  function apply(next: Partial<typeof prefs>) {
    unlockAudio();
    setAudioPrefs(next);
    setPrefs(audioPrefs());
  }
  return (
    <div className="space-y-3 rounded-2xl border border-line bg-panel p-4">
      <h2 className="font-display text-xl font-bold">Sound</h2>
      <p className="text-sm text-muted">Tap once to allow sound. Nothing plays until you do. Music stays off until you turn it up. The choice is remembered on this phone.</p>
      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" checked={prefs.muted} onChange={(event) => apply({ muted: event.target.checked })} />
        Mute
      </label>
      <label className="block text-sm text-muted">
        Effects {Math.round(prefs.sfx * 100)}%
        <input type="range" min={0} max={100} value={Math.round(prefs.sfx * 100)} onChange={(event) => apply({ sfx: Number(event.target.value) / 100 })} className="w-full" />
      </label>
      <label className="block text-sm text-muted">
        Music {Math.round(prefs.music * 100)}%
        <input type="range" min={0} max={100} value={Math.round(prefs.music * 100)} onChange={(event) => apply({ music: Number(event.target.value) / 100 })} className="w-full" />
      </label>
    </div>
  );
}
