import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { listMessages, sendMessage, type MessageView, type PublicPlayer } from "@/lib/sambn/api";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { Avatar, ago, errText } from "@/components/ui";

export const Route = createFileRoute("/chat/$username")({ component: ThreadPage });

type Row = MessageView & { failed?: boolean; pending?: boolean };

function ThreadPage() {
  const { username } = Route.useParams();
  const { user, isPending } = useCurrentUserState();
  const [player, setPlayer] = useState<PublicPlayer | null>(null);
  const [messages, setMessages] = useState<Row[]>([]);
  const [body, setBody] = useState("");
  const [error, setError] = useState("");
  const [sending, setSending] = useState(false);
  const scroller = useRef<HTMLDivElement>(null);

  function load() {
    return listMessages({ data: { username } })
      .then((res) => {
        setPlayer(res.player);
        setMessages(res.messages);
        setError("");
      })
      .catch((err) => setError(errText(err)));
  }

  useEffect(() => {
    if (!user) return;
    void load();
    const id = window.setInterval(() => void load(), 2500);
    return () => window.clearInterval(id);
  }, [user?.id, username]);

  useEffect(() => {
    const el = scroller.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages.length]);

  function send(text: string) {
    const trimmed = text.trim();
    if (!trimmed || sending) return;
    setSending(true);
    setError("");
    const optimistic: Row = {
      id: `local-${Date.now()}`,
      body: trimmed,
      createdAt: new Date().toISOString(),
      mine: true,
      pending: true,
    };
    setMessages((current) => [...current, optimistic]);
    setBody("");
    void sendMessage({ data: { username, body: trimmed } })
      .then(() => load())
      .catch((err) => {
        setError(errText(err));
        setMessages((current) => current.map((row) => (row.id === optimistic.id ? { ...row, pending: false, failed: true } : row)));
        setBody(trimmed);
      })
      .finally(() => setSending(false));
  }

  if (isPending) return <p className="text-muted">Loading chat…</p>;
  if (!user) return <RedirectToSignIn />;

  return (
    <div className="flex h-[calc(100dvh-9rem)] flex-col">
      <div className="mb-3 flex items-center gap-3">
        <Link to="/chat" className="grid h-11 w-11 place-items-center rounded-full bg-panel text-sm text-muted">
          ←
        </Link>
        {player ? <Avatar name={player.displayName} hue={player.avatarHue} online={player.online} size="sm" /> : null}
        <div className="min-w-0">
          <p className="truncate font-semibold">{player?.displayName ?? username}</p>
          <p className="truncate text-xs text-muted">@{player?.username ?? username} · only the two of you</p>
        </div>
      </div>
      {error ? <p className="mb-2 text-sm text-pink-2">{error}</p> : null}
      <div ref={scroller} className="flex-1 space-y-3 overflow-y-auto rounded-2xl border border-line bg-panel p-3">
        {messages.map((message) => (
          <div key={message.id} className={`flex items-end gap-2 ${message.mine ? "flex-row-reverse" : ""}`}>
            {!message.mine && player ? <Avatar name={player.displayName} hue={player.avatarHue} size="sm" /> : null}
            <div className={`max-w-[80%] ${message.mine ? "text-right" : ""}`}>
              <p className="mb-1 text-[10px] text-muted">{message.mine ? "You" : player?.displayName ?? username}</p>
              <p className={`whitespace-pre-wrap rounded-2xl px-3 py-2 text-sm ${message.mine ? "bg-pink text-ink" : "bg-ink"} ${message.failed ? "opacity-60" : ""}`}>
                {message.body}
              </p>
              <p className="mt-1 text-[10px] text-muted">
                {message.failed ? "Not sent" : message.pending ? "Sending…" : ago(message.createdAt)}
              </p>
            </div>
          </div>
        ))}
        {!messages.length ? <p className="text-sm text-muted">No messages yet. Say hello.</p> : null}
      </div>
      <form
        className="mt-2 flex items-end gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          send(body);
        }}
      >
        <textarea
          value={body}
          rows={2}
          onChange={(event) => setBody(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === "Enter" && !event.shiftKey) {
              event.preventDefault();
              send(body);
            }
          }}
          placeholder="Message"
          className="min-h-11 flex-1 resize-none rounded-xl border border-line bg-panel px-3 py-2 outline-none"
        />
        <button type="submit" disabled={sending || !body.trim()} className="min-h-11 rounded-xl bg-pink px-4 font-bold text-ink disabled:opacity-40">
          Send
        </button>
      </form>
    </div>
  );
}
