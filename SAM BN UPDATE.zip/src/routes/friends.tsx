import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { listFriends, removeFriend, respondFriend, searchPlayers, sendFriendRequest, type FriendEdge, type PublicPlayer } from "@/lib/sambn/api";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { Avatar, errText } from "@/components/ui";

export const Route = createFileRoute("/friends")({ component: FriendsPage });

function FriendsPage() {
  const { user, isPending } = useCurrentUserState();
  const [q, setQ] = useState("");
  const [found, setFound] = useState<PublicPlayer[]>([]);
  const [edges, setEdges] = useState<FriendEdge[]>([]);
  const [error, setError] = useState("");

  function load() {
    return listFriends()
      .then(setEdges)
      .catch((err) => setError(errText(err)));
  }

  useEffect(() => {
    if (!user) return;
    void load();
  }, [user?.id]);

  if (isPending) return <p className="text-muted">Loading friends…</p>;
  if (!user) return <RedirectToSignIn />;

  const incoming = edges.filter((edge) => edge.status === "pending" && edge.incoming);
  const outgoing = edges.filter((edge) => edge.status === "pending" && !edge.incoming);
  const friends = edges.filter((edge) => edge.status === "accepted");

  return (
    <div className="space-y-4">
      <h1 className="font-display text-3xl font-extrabold">Friends</h1>
      <form
        className="flex gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          void searchPlayers({ data: { q } })
            .then(setFound)
            .catch((err) => setError(errText(err)));
        }}
      >
        <input value={q} onChange={(event) => setQ(event.target.value)} placeholder="Search username" className="min-h-11 flex-1 rounded-xl border border-line bg-panel px-3 outline-none" />
        <button type="submit" className="min-h-11 rounded-xl bg-pink px-4 font-bold text-ink">
          Search
        </button>
      </form>
      {error ? <p className="text-sm text-pink-2">{error}</p> : null}
      {found.length ? (
        <ul className="space-y-2">
          {found.map((player) => (
            <li key={player.userId} className="flex items-center gap-3 rounded-2xl border border-line bg-panel p-3">
              <Avatar name={player.displayName} hue={player.avatarHue} online={player.online} />
              <div className="min-w-0 flex-1">
                <Link to="/u/$username" params={{ username: player.username }} className="font-semibold">
                  {player.displayName}
                </Link>
                <p className="text-xs text-muted">@{player.username}</p>
              </div>
              <button
                type="button"
                className="min-h-11 rounded-xl bg-pink px-3 text-sm font-bold text-ink"
                onClick={() => {
                  void sendFriendRequest({ data: { username: player.username } })
                    .then(() => load())
                    .catch((err) => setError(errText(err)));
                }}
              >
                Add
              </button>
            </li>
          ))}
        </ul>
      ) : null}
      <Section title="Requests" empty="No incoming requests." rows={incoming} />
      <div className="space-y-2">
        {incoming.map((edge) => (
          <Row key={edge.userId} edge={edge}>
            <button type="button" className="min-h-11 rounded-xl bg-pink px-3 text-sm font-bold text-ink" onClick={() => void respondFriend({ data: { userId: edge.userId, accept: true } }).then(() => load())}>
              Accept
            </button>
            <button type="button" className="min-h-11 rounded-xl border border-line px-3 text-sm" onClick={() => void respondFriend({ data: { userId: edge.userId, accept: false } }).then(() => load())}>
              Decline
            </button>
          </Row>
        ))}
      </div>
      <Section title="Sent" empty="" rows={outgoing} />
      <div className="space-y-2">
        {outgoing.map((edge) => (
          <Row key={edge.userId} edge={edge}>
            <span className="text-xs text-muted">Pending</span>
          </Row>
        ))}
      </div>
      <h2 className="font-display text-xl font-bold">Your friends</h2>
      {!friends.length ? <p className="text-sm text-muted">Search a username and send a request.</p> : null}
      <div className="space-y-2">
        {friends.map((edge) => (
          <Row key={edge.userId} edge={edge}>
            <Link to="/chat/$username" params={{ username: edge.username }} className="min-h-11 rounded-xl bg-pink px-3 py-2 text-sm font-bold text-ink">
              Chat
            </Link>
            <button type="button" className="min-h-11 text-sm text-muted" onClick={() => void removeFriend({ data: { userId: edge.userId } }).then(() => load())}>
              Remove
            </button>
          </Row>
        ))}
      </div>
    </div>
  );
}

function Section({ title, empty, rows }: { title: string; empty: string; rows: FriendEdge[] }) {
  if (!rows.length && !empty) return null;
  return (
    <h2 className="font-display text-xl font-bold">
      {title}
      {!rows.length && empty ? <span className="mt-1 block text-sm font-normal text-muted">{empty}</span> : null}
    </h2>
  );
}

function Row({ edge, children }: { edge: FriendEdge; children: ReactNode }) {
  return (
    <div className="flex items-center gap-3 rounded-2xl border border-line bg-panel p-3">
      <Avatar name={edge.displayName} hue={edge.avatarHue} online={edge.online} />
      <div className="min-w-0 flex-1">
        <Link to="/u/$username" params={{ username: edge.username }} className="font-semibold">
          {edge.displayName}
        </Link>
        <p className="text-xs text-muted">@{edge.username}</p>
      </div>
      {children}
    </div>
  );
}
