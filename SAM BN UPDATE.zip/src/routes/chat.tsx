import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { listThreads, searchPlayers, type PublicPlayer } from "@/lib/sambn/api";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { Avatar, ago, errText } from "@/components/ui";

export const Route = createFileRoute("/chat")({ component: ChatPage });

function ChatPage() {
  const { user, isPending } = useCurrentUserState();
  const [threads, setThreads] = useState<Awaited<ReturnType<typeof listThreads>>>([]);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [found, setFound] = useState<PublicPlayer[]>([]);
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    if (!user) return;
    let cancel = false;
    const tick = () => {
      listThreads()
        .then((rows) => {
          if (!cancel) setThreads(rows);
        })
        .catch((err) => {
          if (!cancel) setError(errText(err));
        });
    };
    tick();
    const id = window.setInterval(tick, 4000);
    return () => {
      cancel = true;
      window.clearInterval(id);
    };
  }, [user?.id]);

  useEffect(() => {
    const q = query.trim();
    if (q.length < 2) {
      setFound([]);
      return;
    }
    let cancel = false;
    setSearching(true);
    const id = window.setTimeout(() => {
      searchPlayers({ data: { q } })
        .then((rows) => {
          if (!cancel) setFound(rows);
        })
        .catch((err) => {
          if (!cancel) setError(errText(err));
        })
        .finally(() => {
          if (!cancel) setSearching(false);
        });
    }, 250);
    return () => {
      cancel = true;
      window.clearTimeout(id);
    };
  }, [query]);

  if (isPending) return <p className="text-muted">Loading chat…</p>;
  if (!user) return <RedirectToSignIn />;

  return (
    <div className="space-y-3">
      <h1 className="font-display text-3xl font-extrabold">Chat</h1>
      <p className="text-sm text-muted">Private messages stay between the two accounts in the conversation. Other players cannot open them.</p>
      <input
        value={query}
        onChange={(event) => setQuery(event.target.value)}
        placeholder="Search username or player ID"
        className="min-h-11 w-full rounded-xl border border-line bg-panel px-3 outline-none"
      />
      {searching ? <p className="text-xs text-muted">Searching…</p> : null}
      {found.length ? (
        <ul className="space-y-2">
          {found.map((player) => (
            <li key={player.userId}>
              <Link to="/chat/$username" params={{ username: player.username }} className="flex items-center gap-3 rounded-2xl border border-line bg-panel p-3">
                <Avatar name={player.displayName} hue={player.avatarHue} online={player.online} />
                <span className="min-w-0">
                  <span className="block font-semibold">{player.displayName}</span>
                  <span className="block truncate text-xs text-muted">@{player.username}</span>
                </span>
              </Link>
            </li>
          ))}
        </ul>
      ) : null}
      {error ? <p className="text-sm text-pink-2">{error}</p> : null}
      {!threads.length ? (
        <p className="rounded-2xl border border-line bg-panel p-4 text-sm text-muted">No conversations yet. Search a player above to start one.</p>
      ) : null}
      <ul className="space-y-2">
        {threads.map((thread) => (
          <li key={thread.player.userId}>
            <Link to="/chat/$username" params={{ username: thread.player.username }} className="flex items-center gap-3 rounded-2xl border border-line bg-panel p-3">
              <Avatar name={thread.player.displayName} hue={thread.player.avatarHue} online={thread.player.online} />
              <span className="min-w-0 flex-1">
                <span className="flex items-center justify-between gap-2">
                  <span className="font-semibold">{thread.player.displayName}</span>
                  <span className="text-xs text-muted">{ago(thread.createdAt)}</span>
                </span>
                <span className="block truncate text-sm text-muted">@{thread.player.username} · {thread.body}</span>
              </span>
              {thread.unread ? <span className="rounded-full bg-pink px-2 text-xs font-bold text-ink">{thread.unread}</span> : null}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
