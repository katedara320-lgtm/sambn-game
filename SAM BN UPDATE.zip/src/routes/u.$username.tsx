import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { listMatches, sendFriendRequest } from "@/lib/sambn/api";
import { gameBySlug } from "@/lib/sambn/catalog";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { Avatar, ago, errText } from "@/components/ui";

export const Route = createFileRoute("/u/$username")({ component: PublicProfile });

function PublicProfile() {
  const { username } = Route.useParams();
  const { user, isPending } = useCurrentUserState();
  const [data, setData] = useState<Awaited<ReturnType<typeof listMatches>> | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!user) return;
    listMatches({ data: { username } })
      .then(setData)
      .catch((err) => setError(errText(err)));
  }, [user?.id, username]);

  if (isPending) return <p className="text-muted">Loading player…</p>;
  if (!user) return <RedirectToSignIn />;
  if (!data) return <p className="text-muted">{error || "Loading player…"}</p>;
  const profile = data.profile;

  return (
    <div className="mx-auto max-w-2xl space-y-4">
      <div className="flex items-center gap-4 rounded-3xl border border-line bg-panel p-4">
        <Avatar name={profile.displayName} hue={profile.avatarHue} online={Date.now() - new Date(profile.lastSeen).getTime() < 90_000} size="lg" />
        <div>
          <h1 className="font-display text-3xl font-extrabold">{profile.displayName}</h1>
          <p className="text-sm text-muted">@{profile.username}</p>
          <p className="text-sm">{profile.bio || "No bio yet."}</p>
          <p className="text-sm text-gold">Level {profile.level} · {profile.wins} wins</p>
        </div>
      </div>
      {data.relation === "self" ? (
        <Link to="/profile" className="text-sm text-pink">
          Edit your profile
        </Link>
      ) : null}
      {data.relation === "none" ? (
        <button
          type="button"
          className="min-h-11 rounded-xl bg-pink px-4 font-bold text-ink"
          onClick={() => {
            void sendFriendRequest({ data: { username: profile.username } })
              .then(() => setError("Request sent."))
              .catch((err) => setError(errText(err)));
          }}
        >
          Add friend
        </button>
      ) : null}
      {data.relation === "friends" ? (
        <Link to="/chat/$username" params={{ username: profile.username }} className="inline-flex min-h-11 items-center rounded-xl bg-pink px-4 font-bold text-ink">
          Message
        </Link>
      ) : null}
      {error ? <p className="text-sm text-muted">{error}</p> : null}
      <h2 className="font-display text-xl font-bold">Recent matches</h2>
      <ul className="space-y-2">
        {data.matches.map((match) => (
          <li key={match.id} className="rounded-xl border border-line bg-panel px-3 py-2 text-sm">
            {gameBySlug(match.gameSlug)?.name ?? match.gameSlug} · {match.result} · {match.detail} · {ago(match.playedAt)}
          </li>
        ))}
        {!data.matches.length ? <li className="text-sm text-muted">No matches yet.</li> : null}
      </ul>
    </div>
  );
}
