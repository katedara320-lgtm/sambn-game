import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { Gamepad2 } from "lucide-react";
import { GROK_PROVIDERS, authClient, authEnabled, signIn } from "@/lib/auth/client";
import { Field } from "@/components/ui";

export const Route = createFileRoute("/login")({
  validateSearch: (search: Record<string, unknown>) => ({
    redirect: safeRedirect(search.redirect),
  }),
  component: LoginPage,
});

function safeRedirect(value: unknown) {
  if (typeof value !== "string") return "/";
  if (!value.startsWith("/") || value.startsWith("//")) return "/";
  return value;
}

function LoginPage() {
  const { redirect } = Route.useSearch();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    setError("");
    setPending(true);
    try {
      if (mode === "up") {
        const result = await authClient.signUp.email({ email, password, name, callbackURL: redirect });
        if (result.error) throw new Error(result.error.message ?? "Could not create the account.");
      } else {
        const result = await authClient.signIn.email({ email, password, callbackURL: redirect });
        if (result.error) throw new Error(result.error.message ?? "Could not sign in.");
      }
      window.location.assign(redirect);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not sign in.");
      setPending(false);
    }
  }

  return (
    <main className="grid min-h-dvh place-items-center bg-ink px-4 py-10 text-fg">
      <div className="w-full max-w-md space-y-6">
        <Link to="/" className="flex items-center gap-3">
          <span className="grid h-12 w-12 place-items-center rounded-2xl bg-pink text-ink">
            <Gamepad2 className="h-6 w-6" />
          </span>
          <span>
            <span className="block font-display text-2xl font-extrabold">
              SAM <span className="text-pink">BN</span>
            </span>
            <span className="text-xs font-semibold uppercase tracking-widest text-gold">Africa's Finest</span>
          </span>
        </Link>
        <div className="rounded-3xl border border-line bg-panel p-5">
          <div className="grid grid-cols-2 gap-2">
            <button type="button" onClick={() => setMode("in")} className={`min-h-11 rounded-xl ${mode === "in" ? "bg-pink text-ink" : "bg-ink"}`}>
              Sign in
            </button>
            <button type="button" onClick={() => setMode("up")} className={`min-h-11 rounded-xl ${mode === "up" ? "bg-pink text-ink" : "bg-ink"}`}>
              Create account
            </button>
          </div>
          {authEnabled ? (
            <form onSubmit={(event) => void onSubmit(event)} className="mt-4 space-y-3">
              {mode === "up" ? <Field label="Display name" value={name} onChange={setName} placeholder="KingBlaze" /> : null}
              <Field label="Email" type="email" value={email} onChange={setEmail} placeholder="you@email.com" />
              <Field label="Password" type="password" value={password} onChange={setPassword} placeholder="At least 8 characters" />
              {error ? <p className="text-sm text-pink-2">{error}</p> : null}
              <button type="submit" disabled={pending} className="min-h-11 w-full rounded-xl bg-pink font-bold text-ink disabled:opacity-50">
                {pending ? "Please wait…" : mode === "up" ? "Create account" : "Sign in with email"}
              </button>
            </form>
          ) : (
            <p className="mt-4 text-sm text-muted">Sign-in is turned off.</p>
          )}
          <div className="my-4 h-px bg-line" />
          <div className="space-y-2">
            {GROK_PROVIDERS.map((provider) => (
              <button
                key={provider.providerId}
                type="button"
                className="min-h-11 w-full rounded-xl border border-line bg-ink font-semibold"
                onClick={() => signIn(provider.providerId, { callbackURL: redirect })}
              >
                Continue with {provider.label}
              </button>
            ))}
          </div>
          <p className="mt-4 text-xs leading-relaxed text-muted">
            Google, X, and email are the live sign-in methods. Phone number sign-in is not available, so it is not offered here.
          </p>
        </div>
      </div>
    </main>
  );
}
