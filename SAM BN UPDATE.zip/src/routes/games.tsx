import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { GAMES } from "@/lib/sambn/catalog";
import { joinRoom } from "@/lib/sambn/api";
import { HostGame } from "@/components/host-game";
import { OpenRooms } from "@/components/open-rooms";
import { GameCard, errText } from "@/components/ui";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/games")({
  validateSearch: (search: Record<string, unknown>) => ({
    q: typeof search.q === "string" ? search.q : "",
  }),
  component: GamesPage,
});

function GamesPage() {
  const { q } = Route.useSearch();
  const { user, isPending } = useCurrentUserState();
  const navigate = useNavigate();
  const [panel, setPanel] = useState<"host" | "join" | "online" | "">("");
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const query = q.trim().toLowerCase();
  const games = GAMES.filter((game) => !query || game.name.toLowerCase().includes(query) || game.tag.toLowerCase().includes(query));

  return (
    <div className="space-y-4">
      <div>
        <h1 className="font-display text-3xl font-extrabold">Games</h1>
        <p className="text-sm text-muted">Host a room, join a public one, or enter a private code. Matches open in landscape.</p>
      </div>
      <div className="grid grid-cols-3 gap-2">
        <button type="button" onClick={() => setPanel("online")} className={`min-h-12 rounded-xl text-sm font-bold ${panel === "online" ? "bg-pink text-ink" : "border border-line bg-panel"}`}>
          Play online
        </button>
        <button type="button" onClick={() => setPanel("host")} className={`min-h-12 rounded-xl font-bold ${panel === "host" ? "bg-pink text-ink" : "border border-line bg-panel"}`}>
          Host game
        </button>
        <button type="button" onClick={() => setPanel("join")} className={`min-h-12 rounded-xl font-bold ${panel === "join" ? "bg-pink text-ink" : "border border-line bg-panel"}`}>
          Join game
        </button>
      </div>
      {panel === "online" ? (
        <div className="space-y-2 rounded-3xl border border-line bg-panel p-4">
          <p className="font-display text-xl font-extrabold">Public rooms</p>
          <OpenRooms />
        </div>
      ) : null}
      {panel === "host" ? <HostGame /> : null}
      {panel === "join" ? (
        <form
          className="space-y-2 rounded-3xl border border-line bg-panel p-4"
          onSubmit={(event) => {
            event.preventDefault();
            if (isPending) return;
            if (!user) {
              void navigate({ to: "/login", search: { redirect: "/games" } });
              return;
            }
            const next = code.trim();
            if (!next) {
              setError("Enter a room code.");
              return;
            }
            setError("");
            void joinRoom({ data: { code: next } })
              .then((res) => navigate({ to: "/room/$code", params: { code: res.code } }))
              .catch((err) => setError(errText(err)));
          }}
        >
          <p className="font-display text-xl font-extrabold">Join with a code</p>
          <div className="flex gap-2">
            <input
              value={code}
              onChange={(event) => setCode(event.target.value.toUpperCase())}
              placeholder="Room code"
              className="min-h-11 flex-1 rounded-xl border border-line bg-ink px-3 uppercase outline-none ring-pink focus:ring-2"
            />
            <button type="submit" className="min-h-11 rounded-xl bg-pink px-4 font-bold text-ink">
              Join
            </button>
          </div>
          {error ? <p className="text-sm text-pink-2">{error}</p> : null}
        </form>
      ) : null}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
        {games.map((game) => (
          <GameCard key={game.slug} game={game} />
        ))}
      </div>
    </div>
  );
}
