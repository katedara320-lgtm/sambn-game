import { chromium } from "playwright";

const browser = await chromium.launch({ args: ["--no-sandbox", "--disable-dev-shm-usage"] });

async function shoot(file, width, height, out) {
  const page = await browser.newPage({
    viewport: { width, height },
    deviceScaleFactor: 2,
  });
  await page.goto(`file:///workspace/.grok/${file}`, { waitUntil: "load" });
  await page.evaluate(() => document.fonts.ready);
  const box = await page.locator("#lockup").boundingBox();
  console.log(file, "lockup", box, "frame", width, height);
  if (box) {
    const right = box.x + box.width;
    const bottom = box.y + box.height;
    console.log(file, "edges", {
      left: Math.round(box.x),
      top: Math.round(box.y),
      right: Math.round(right),
      bottom: Math.round(bottom),
      rightHalf: right > width / 2,
      bottomFifth: bottom > height * 0.8,
    });
  }
  await page.screenshot({ path: out, type: "png" });
  await page.close();
}

await shoot("og-card.html", 1200, 630, "/workspace/.grok/og-raw.png");
await shoot("x-banner.html", 1200, 264, "/workspace/.grok/x-banner-raw.png");

const page = await browser.newPage({ viewport: { width: 280, height: 100 }, deviceScaleFactor: 4 });
await page.goto("file:///workspace/.grok/favicon-preview.html", { waitUntil: "load" });
await page.screenshot({ path: "/workspace/.grok/favicon-preview.png", type: "png" });
await page.close();
await browser.close();
